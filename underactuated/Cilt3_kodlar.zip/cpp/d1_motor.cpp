// d1_motor.cpp — DC motor + dişli modeli: kararlı hal ve basamak yanıtı (Python d1_motor.py ile aynı sayılar)
#include <cmath>
#include <cstdio>

struct Motor {                       // motor + dişli parametreleri (örnek değerler, MG996R datasheet'ine uydurulmuş)
    double V = 4.8, R = 2.4, L = 1e-3, k = 0.004, Jm = 2e-7, N = 195.0, eta = 0.59;
    double stall_torque_out() const { return N * eta * k * V / R; }
    double no_load_speed_out() const { return V / k / N; }
};

int main() {
    Motor m;
    double ts = m.stall_torque_out(), w0 = m.no_load_speed_out();
    std::printf("çıkış: durma torku %.3f N·m (%.2f kgf·cm), yüksüz hız %.3f rad/s, 60° için %.3f s\n",
                ts, ts / 9.81 * 100, w0, M_PI / 3 / w0);
    std::printf("en büyük mekanik güç %.3f W, durmada ısı %.2f W\n", ts * w0 / 4, m.V * m.V / m.R);

    const double Jload = 0.004, Jt = m.Jm + Jload / (m.N * m.N * m.eta);
    double i = 0, w = 0, i_max = 0, t63 = -1;
    const double dt = 1e-5; const int n = 20000;                       // 0.2 s
    for (int s = 0; s < n; ++s) {
        i += dt * (m.V - m.R * i - m.k * w) / m.L;                     // elektriksel denklem
        w += dt * (m.k * i) / Jt;                                      // mekanik denklem
        if (i > i_max) i_max = i;
        if (t63 < 0 && w >= 0.632 * m.V / m.k) t63 = s * dt;
    }
    std::printf("basamak: tepe akım %.2f A, 0.2 s sonra hız %.0f rad/s, %%63'e ulaşma %.1f ms\n", i_max, w, t63 * 1e3);
    return 0;
}
