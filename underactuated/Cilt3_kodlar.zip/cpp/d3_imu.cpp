// d3_imu.cpp — tamamlayıcı (complementary) filtre: mikrodenetleyicide nasıl yazılır
#include <cmath>
#include <cstdio>
#include <random>

class ComplementaryFilter {
public:
    explicit ComplementaryFilter(double alpha) : alpha_(alpha) {}
    // gyro_rate [rad/s], acc_angle [rad], dt [s]  ->  güncel eğim kestirimi [rad]
    double update(double gyro_rate, double acc_angle, double dt) {
        angle_ = alpha_ * (angle_ + gyro_rate * dt) + (1.0 - alpha_) * acc_angle;
        return angle_;
    }
private:
    double alpha_;
    double angle_ = 0.0;
};

int main() {
    std::mt19937 gen(0); std::normal_distribution<double> n01(0.0, 1.0);
    const double dt = 0.01, T = 60.0, bias = 0.01, deg = M_PI / 180;
    ComplementaryFilter cf(0.98);
    double gyro_int = 0, se_cf = 0, se_acc = 0; int cnt = 0;
    double ang = 0, ang_prev = 0;
    for (int k = 1; k < (int)(T / dt); ++k) {
        double t = k * dt;
        ang = 10 * deg * std::sin(2 * M_PI * 0.2 * t);
        double rate = (ang - ang_prev) / dt; ang_prev = ang;              // gerçek açısal hız (fark ile)
        double gyro = rate + bias + 0.005 * n01(gen);
        double acc = ang + 3 * deg * n01(gen);
        gyro_int += gyro * dt;
        double est = cf.update(gyro, acc, dt);
        if (k > 100) { se_cf += (est - ang) * (est - ang); se_acc += (acc - ang) * (acc - ang); ++cnt; }
    }
    std::printf("60 s: jiroskop integrali hatası %.2f°, ivmeölçer RMS %.2f°, tamamlayıcı filtre RMS %.2f°\n",
                (gyro_int - ang) / deg, std::sqrt(se_acc / cnt) / deg, std::sqrt(se_cf / cnt) / deg);
    return 0;
}
