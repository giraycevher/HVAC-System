// d2_servo.cpp — hobi servo modeli (Python d2_servo.py ile aynı): 50 Hz komut, ölü bölge, gerilim doyması
#include <algorithm>
#include <cmath>
#include <cstdio>

struct ServoModel {
    double Vs = 4.8, R = 2.4, k = 0.004, N = 195.0, eta = 0.59, Kp = 60.0;
    double DB = 0.9 * M_PI / 180.0, J = 195.0 * 195.0 * 2e-7 + 0.004;
    double th = 0, w = 0;
    // bir zaman adımı; i_out: o anki akım
    void step(double cmd, double tau_grav, double dt, double& i_out, bool& saturated) {
        double e = cmd - th;
        double V = (std::abs(e) < DB / 2) ? 0.0 : std::clamp(Kp * e, -Vs, Vs);
        saturated = std::abs(V) >= Vs;
        i_out = (V - k * N * w) / R;
        double tau = N * eta * k * i_out - tau_grav * std::sin(th) - 0.002 * w;
        w += dt * tau / J; th += dt * w;
    }
};

int main() {
    struct Case { double amp_deg, f, tg; };
    std::printf("genlik frekans  yük | RMS hata  max hata  max akım  doyma%%\n");
    for (Case c : {Case{30, 0.5, 0.0}, Case{30, 0.5, 0.6}, Case{30, 1.0, 0.6}, Case{30, 2.0, 0.0}, Case{30, 2.0, 0.6}, Case{5, 2.0, 0.6}}) {
        ServoModel s; const double dt = 1e-4; const int n = 40000, frame = 200;
        double cmd = 0, se2 = 0, emax = 0, imax = 0; int cnt = 0, nsat = 0;
        const double A = c.amp_deg * M_PI / 180;
        for (int k = 0; k < n; ++k) {
            double t = k * dt;
            if (k % frame == 0) cmd = A * std::sin(2 * M_PI * c.f * t);   // 20 ms'de bir yeni komut
            double i; bool sat; s.step(cmd, c.tg, dt, i, sat);
            imax = std::max(imax, std::abs(i)); nsat += sat;
            if (t > 1.0) { double e = A * std::sin(2 * M_PI * c.f * t) - s.th; se2 += e * e; emax = std::max(emax, std::abs(e)); ++cnt; }
        }
        std::printf("%5.0f° %5.1fHz %5.2f | %7.2f° %8.2f° %8.2fA %6.1f\n", c.amp_deg, c.f, c.tg,
                    std::sqrt(se2 / cnt) * 180 / M_PI, emax * 180 / M_PI, imax, 100.0 * nsat / n);
    }
    return 0;
}
