// d4_leg_sketch.cpp — 2 servolu masaüstü bacak (P2) için Arduino taslağı.
// Gerçek kartta: #include "arduino_mock.hpp" satırını ve en alttaki main()'i SİL, #include <Servo.h> ekle.
#include "arduino_mock.hpp"

// ---------- Bacak geometrisi ve kalibrasyon (kendi ölçümlerinle değiştir) ----------
const float L1 = 0.10f, L2 = 0.10f;           // uyluk ve baldır [m] (masaüstü bacak)
const float US_PER_RAD = 1000.0f / 3.14159f;   // 1000 µs <-> 180° (datasheet; Cilt 1 Bölüm 1'deki gibi kalibre et)
const int   US_CENTER[2] = {1500, 1500};       // eklem açısı 0 iken darbe genişliği (kalibrasyonla bulunur)
const int   SIGN[2]      = {+1, -1};           // servonun montaj yönüne göre işaret
const float Q_MIN[2] = {-1.2f, 0.10f}, Q_MAX[2] = {1.2f, 2.40f};   // eklem limitleri [rad]
const unsigned long PERIOD_US = 10000;         // 100 Hz kontrol döngüsü

Servo hip, knee;
unsigned long next_us = 0, max_late_us = 0;
float q_prev[2] = {0, 0}, max_rate = 0;

// Düzlemsel 2-uzuv IK (Cilt 1 konvansiyonu: x = L1 sin q1 + L2 sin(q1+q2), z = -L1 cos q1 - L2 cos(q1+q2))
bool ik(float x, float z, float q[2]) {
    float D = (x * x + z * z - L1 * L1 - L2 * L2) / (2 * L1 * L2);
    if (D < -1.0f || D > 1.0f) return false;                   // ulaşılamaz: komutu değiştirme
    q[1] = acosf(D);                                           // diz öne bükük (q2 > 0)
    q[0] = atan2f(x, -z) - atan2f(L2 * sinf(q[1]), L1 + L2 * cosf(q[1]));
    return true;
}

// Ayak yörüngesi: 4 cm genişlik, 2 cm adım yüksekliği, 1 s periyot (yarım elips + düz itme)
void foot_traj(float t, float& x, float& z) {
    const float z0 = -0.16f, A = 0.02f, H = 0.02f, T = 1.0f;
    float s = fmodf(t, T) / T;
    if (s < 0.5f) { float p = s / 0.5f; x = -A + 2 * A * p; z = z0; }                        // yerde: geriye it
    else { float p = (s - 0.5f) / 0.5f; x = A * cosf(3.14159f * p); z = z0 + H * sinf(3.14159f * p); }   // havada: öne taşı
    x = -x;                                                                                   // ileri yürüme yönü
}

int rad_to_us(int j, float q) { return (int)(US_CENTER[j] + SIGN[j] * q * US_PER_RAD + 0.5f); }

void setup() {
    Serial.begin(115200);
    hip.attach(9); knee.attach(10);
    next_us = micros();
}

void loop() {
    unsigned long now = micros();
    if ((long)(now - next_us) < 0) return;                    // daha zamanı gelmedi (taşmaya dayanıklı karşılaştırma)
    if (now - next_us > max_late_us) max_late_us = now - next_us;
    next_us += PERIOD_US;                                     // sabit frekans: bir sonraki tetik zamanı
    float t = now * 1e-6f, x, z, q[2];
    foot_traj(t, x, z);
    if (!ik(x, z, q)) return;
    for (int j = 0; j < 2; ++j) q[j] = constrain(q[j], Q_MIN[j], Q_MAX[j]);
    for (int j = 0; j < 2; ++j) {
        float rate = fabsf(q[j] - q_prev[j]) / (PERIOD_US * 1e-6f);
        if (t > 0.05f && rate > max_rate) max_rate = rate;
        q_prev[j] = q[j];
    }
    hip.writeMicroseconds(rad_to_us(0, q[0]));
    knee.writeMicroseconds(rad_to_us(1, q[1]));
}

// ---------- Sadece bilgisayarda: sahte saatle 3 s çalıştır ----------
int main() {
    setup();
    for (int k = 0; k < 300000; ++k) {                        // 10 µs adımlarla 3 s
        mock::now_us += 10;
        if (k % 1237 == 0) mock::now_us += 400;                // ara sıra gecikme (başka iş, kesme) taklidi
        loop();
        if (k == 50000 || k == 120000 || k == 170000)
            Serial.printf("t=%.2f s  kalça=%d µs  diz=%d µs\n", mock::now_us * 1e-6, hip.last_us, knee.last_us);
    }
    Serial.printf("3 s'de servo yazma sayısı: %d (beklenen ~300), en büyük gecikme %lu µs\n", hip.n_writes, max_late_us);
    Serial.printf("en büyük istenen eklem hızı %.2f rad/s (MG996R yüksüz ~6.2 rad/s)\n", max_rate);
    return 0;
}
