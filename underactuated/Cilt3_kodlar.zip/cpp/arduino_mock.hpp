// arduino_mock.hpp — Arduino fonksiyonlarının masaüstü (bilgisayar) taklitleri. Gerçek kartta bu dosya KULLANILMAZ:
// Arduino IDE kendi millis(), micros(), Servo ve Serial'ini sağlar. Amaç: aynı .ino mantığını bilgisayarda test etmek.
#pragma once
#include <cmath>
#include <cstdio>

namespace mock { inline unsigned long now_us = 0; }          // sahte saat (simülasyonda ilerletilir)
inline unsigned long micros() { return mock::now_us; }
inline unsigned long millis() { return mock::now_us / 1000; }
inline float constrain(float x, float lo, float hi) { return x < lo ? lo : (x > hi ? hi : x); }

class Servo {                                                // Arduino Servo kütüphanesinin taklidi
public:
    void attach(int pin) { pin_ = pin; }
    void writeMicroseconds(int us) { last_us = us; ++n_writes; }
    int pin_ = -1, last_us = 1500, n_writes = 0;
};

struct SerialMock {
    void begin(long baud) { std::printf("[Serial %ld baud]\n", baud); }
    template <typename... A> void printf(const char* f, A... a) { std::printf(f, a...); }
};
inline SerialMock Serial;
