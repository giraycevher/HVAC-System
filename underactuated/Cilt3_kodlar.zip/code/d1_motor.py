import numpy as np

# Örnek fırçalı DC motor + dişli. Değerler MG996R datasheet'ini (4.8 V: 9.4 kgf·cm, 0.17 s/60°) tutturacak
# şekilde SEÇİLDİ; servonun gerçek iç parametreleri değildir (üretici vermiyor).
V, R, L = 4.8, 2.4, 1e-3          # gerilim [V], sargı direnci [Ω], endüktans [H]
k = 0.004                         # tork sabiti = zıt EMK sabiti [N·m/A] = [V·s/rad] (SI'da eşit)
Jm, bm = 2e-7, 0.0                # rotor ataleti [kg·m²], viskoz sürtünme
N, eta = 195.0, 0.59              # dişli oranı, dişli verimi

# (1) Kararlı hal: tork-hız doğrusu (motor milinde ve çıkış milinde)
tau_s_m = k*V/R; w0_m = V/k                                   # durma torku, yüksüz hız (motor)
tau_s = N*eta*tau_s_m; w0 = w0_m/N                            # çıkışta
print(f"motor mili:  durma torku {tau_s_m*1e3:.2f} mN·m, yüksüz hız {w0_m:.0f} rad/s ({w0_m*60/2/np.pi:.0f} rpm), durma akımı {V/R:.2f} A")
print(f"çıkış mili:  durma torku {tau_s:.3f} N·m = {tau_s/9.81*100:.2f} kgf·cm (datasheet 9.4), yüksüz hız {w0:.3f} rad/s -> 60° için {np.pi/3/w0:.3f} s (datasheet 0.17)")
P_max = tau_s*w0/4
print(f"en büyük mekanik güç (τ = τ_s/2, ω = ω0/2'de): {P_max:.3f} W;  durmada elektrik gücü V²/R = {V*V/R:.2f} W (tamamı ısı)")
for frac in [0.1, 0.25, 0.5, 0.75]:
    tau = frac*tau_s; w = w0*(1 - frac); i = tau/(N*eta*k); Pin = V*i; Pout = tau*w
    print(f"  yük = %{frac*100:3.0f} durma torku: hız {w:.2f} rad/s, akım {i:.3f} A, verim {Pout/Pin*100:5.1f} %, ısı {i*i*R:.2f} W")

# (2) Zaman sabitleri ve basamak yanıtı (yüksüz, motor tarafı): L di/dt = V - R i - k ω ;  Jt dω/dt = k i - (yük)
Jload = 0.004                                                  # çıkışa bağlı uyluk ataleti (Cilt 1 Bölüm 6) [kg·m²]
Jt = Jm + Jload/(N*N*eta)                                      # motora yansıyan toplam atalet (verim yaklaşımıyla)
print(f"\nyansıyan atalet: rotor {Jm:.1e}, yük/N²η {Jload/(N*N*eta):.2e} kg·m²  ->  çıkıştan görülen rotor ataleti N²Jm = {N*N*Jm:.4f} kg·m² (uyluğun {N*N*Jm/Jload:.1f} katı!)")
tau_e = L/R; tau_mech = Jt*R/(k*k)
print(f"elektriksel zaman sabiti L/R = {tau_e*1e3:.2f} ms, mekanik zaman sabiti J R/k² = {tau_mech*1e3:.1f} ms")
dt = 1e-5; T = 0.2; n = int(T/dt); i = 0.0; w = 0.0; I = np.zeros(n); W = np.zeros(n)
for s in range(n):                                             # yarı-örtük Euler, küçük adım (L/R çok küçük!)
    i += dt*(V - R*i - k*w)/L; w += dt*(k*i - bm*w)/Jt; I[s] = i; W[s] = w
t63 = np.argmax(W >= 0.632*w0_m)*dt
print(f"basamak yanıtı: tepe akım {I.max():.2f} A (t={np.argmax(I)*dt*1e3:.2f} ms), 0.2 s sonra hız {W[-1]:.0f} rad/s (yüksüz {w0_m:.0f}), %63'e ulaşma {t63*1e3:.1f} ms")

# %% plot
from figstyle import plt, save
fig, ax = plt.subplots(1, 2, figsize=(8.0, 3.0))
tt = np.linspace(0, 1, 50); taus = tt*tau_s; ws = w0*(1 - tt); ii = taus/(N*eta*k)
ax[0].plot(taus, ws, label="hız [rad/s]"); ax[0].plot(taus, taus*ws, label="çıkış gücü [W]"); ax[0].plot(taus, ii, label="akım [A]")
ax[0].plot(taus, (taus*ws)/(V*ii + 1e-12), "--", label="verim")
ax[0].set_xlabel("çıkış torku [N·m]"); ax[0].set_title("Tork-hız eğrisi (4.8 V)"); ax[0].legend(fontsize=7)
t = np.arange(n)*dt*1e3; a2 = ax[1].twinx()
ax[1].plot(t, W, "C0"); a2.plot(t, I, "C1"); ax[1].set_xlabel("t [ms]"); ax[1].set_ylabel("motor hızı [rad/s]", color="C0"); a2.set_ylabel("akım [A]", color="C1"); a2.grid(False)
ax[1].set_title("Basamak yanıtı (uyluk bağlı)")
save("d1_motor")
