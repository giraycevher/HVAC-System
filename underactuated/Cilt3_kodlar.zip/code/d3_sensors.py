import numpy as np
rng = np.random.default_rng(0)

# (1) Enkoder ile hız: 12-bit (4096 sayım/tur) manyetik enkoder, 1 kHz döngü
CPR, dt = 4096, 1e-3; q = 2*np.pi/CPR
t = np.arange(0, 2.0, dt); w_true = 0.5*np.sin(2*np.pi*1.0*t)                 # gerçek hız: ±0.5 rad/s, 1 Hz
th_true = np.cumsum(w_true)*dt; counts = np.floor(th_true/q)                     # enkoder tam sayı sayım verir
w_raw = np.diff(counts, prepend=counts[0])*q/dt                                  # 1 ms'lik fark
w_10 = np.zeros_like(t); w_10[10:] = (counts[10:] - counts[:-10])*q/(10*dt)      # 10 ms pencereli fark
alpha = dt/(0.01 + dt); w_lp = np.zeros_like(t)                                   # 1. derece alçak geçiren (τ = 10 ms)
for k in range(1, len(t)): w_lp[k] = w_lp[k-1] + alpha*(w_raw[k] - w_lp[k-1])
rms = lambda e: np.sqrt(np.mean(e[100:]**2))
print(f"enkoder çözünürlüğü {np.rad2deg(q)*60:.2f} yay-dakika; 1 ms'de hız çözünürlüğü q/dt = {q/dt:.3f} rad/s (ölçülen hızın 3 katı!)")
print(f"hız RMS hatası: ham fark {rms(w_raw - w_true):.3f}, 10 ms pencere {rms(w_10 - w_true):.3f}, alçak geçiren τ=10 ms {rms(w_lp - w_true):.3f} rad/s")
print(f"bedel: 1. derece filtre düşük frekanslarda yaklaşık τ = 10 ms gecikme ekler (1 Hz'de faz gecikmesi {np.rad2deg(np.arctan(2*np.pi*1.0*0.01)):.1f}°)")

# (2) Potansiyometre + 10-bit ADC (servo içindeki geri bildirim)
lsb = 180/1023; print(f"\n10-bit ADC, 0-180°: 1 LSB = {lsb:.3f}°; ±1 LSB gürültüyle 1 ms'de türev gürültüsü ~ {np.deg2rad(lsb)/1e-3:.2f} rad/s")

# (3) IMU: jiroskop (bias + gürültü) ve ivmeölçer (gürültü + titreşim) ile eğim açısı, tamamlayıcı filtre
dt2, T = 0.01, 60.0; t2 = np.arange(0, T, dt2)
ang = np.deg2rad(10)*np.sin(2*np.pi*0.2*t2)                                       # gerçek gövde eğimi (pitch)
rate = np.gradient(ang, dt2)
gyro = rate + 0.01 + 0.005*rng.standard_normal(len(t2))                          # 0.01 rad/s sabit bias
acc_ang = ang + np.deg2rad(3)*rng.standard_normal(len(t2))                        # ivmeölçerden eğim: gürültülü (adım darbeleri)
g_only = np.cumsum(gyro)*dt2
a = 0.98; cf = np.zeros_like(t2)
for k in range(1, len(t2)): cf[k] = a*(cf[k-1] + gyro[k]*dt2) + (1 - a)*acc_ang[k]
d = lambda x: np.rad2deg(x)
print(f"\nIMU, 60 s: sadece jiroskop integrali son hata {d(g_only[-1] - ang[-1]):.2f}° (bias × 60 s = {d(0.01*60):.1f}°)")
print(f"  sadece ivmeölçer RMS hata {d(rms(acc_ang - ang)):.2f}°;  tamamlayıcı filtre (α=0.98, τ={a*dt2/(1-a):.2f} s) RMS hata {d(rms(cf - ang)):.2f}°, son 10 s ortalama hata {d(np.mean((cf - ang)[-1000:])):.2f}°")
print(f"  bias'ın filtrede bıraktığı kalıcı hata (teori): bias·τ = {d(0.01*a*dt2/(1 - a)):.2f}°")

# %% plot
from figstyle import plt, save
fig, ax = plt.subplots(1, 2, figsize=(8.0, 3.0))
s = slice(200, 700)
ax[0].plot(t[s], w_raw[s], c="0.75", lw=0.6, label="ham fark (1 ms)"); ax[0].plot(t[s], w_lp[s], "C1", label="alçak geçiren"); ax[0].plot(t[s], w_true[s], "k--", lw=1, label="gerçek")
ax[0].set_xlabel("t [s]"); ax[0].set_ylabel("rad/s"); ax[0].set_title("Enkoderden hız"); ax[0].legend(fontsize=7)
ax[1].plot(t2, d(g_only), label="sadece jiroskop"); ax[1].plot(t2, d(acc_ang), c="0.8", lw=0.4, label="sadece ivmeölçer"); ax[1].plot(t2, d(cf), "C2", label="tamamlayıcı"); ax[1].plot(t2, d(ang), "k--", lw=0.8, label="gerçek")
ax[1].set_xlim(0, 60); ax[1].set_xlabel("t [s]"); ax[1].set_ylabel("eğim [°]"); ax[1].set_title("IMU ile eğim"); ax[1].legend(fontsize=6)
save("d3_sensors")
