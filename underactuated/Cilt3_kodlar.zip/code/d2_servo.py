import numpy as np

# Hobi pozisyon servosu modeli (çıkış mili tarafında). Motor/dişli değerleri d1_motor.py ile aynı (örnek).
Vs, R, k, Jm, N, eta = 4.8, 2.4, 0.004, 2e-7, 195.0, 0.59
Kp = 60.0                        # iç kontrolcü: V = Kp * hata [V/rad] (gerçek servoda bilinmez, örnek değer)
DB = np.deg2rad(0.9)             # ölü bölge: 5 µs datasheet × 0.18°/µs (1000-2000 µs <-> 0-180°)
FRAME = 0.020                    # PWM periyodu 20 ms: hedef açı sadece 50 Hz'de güncellenir
J_link = 0.004                   # bağlı uzvun ataleti [kg·m²]
Jeff = N*N*Jm + J_link           # çıkıştan görülen toplam atalet

def simulate(amp_deg, freq, tau_grav, T=4.0, dt=1e-4):
    """Sinüs hedefi takibi. tau_grav: uzvun yerçekimi torku katsayısı [N·m] (τ_yük = tau_grav·sin θ)"""
    th, w, cmd = 0.0, 0.0, 0.0; n = int(T/dt); err = []; imax = 0.0; sat = 0
    for s in range(n):
        t = s*dt
        if s % int(FRAME/dt) == 0:                        # yeni PWM darbesi geldi
            cmd = np.deg2rad(amp_deg)*np.sin(2*np.pi*freq*t)
        e = cmd - th
        V = 0.0 if abs(e) < DB/2 else np.clip(Kp*e, -Vs, Vs)
        sat += abs(V) >= Vs
        i = (V - k*N*w)/R; imax = max(imax, abs(i))       # endüktans ihmal (L/R = 0.4 ms << diğerleri)
        tau = N*eta*k*i - tau_grav*np.sin(th) - 0.002*w   # motor torku - yerçekimi - küçük sürtünme
        w += dt*tau/Jeff; th += dt*w
        if t > 1.0: err.append(np.deg2rad(amp_deg)*np.sin(2*np.pi*freq*t) - th)   # ilk 1 s geçici rejim
    err = np.array(err)
    return np.rad2deg(np.sqrt(np.mean(err**2))), np.rad2deg(np.abs(err).max()), imax, sat/n

print(f"Jeff = N²Jm + J_uzuv = {N*N*Jm:.4f} + {J_link} = {Jeff:.4f} kg·m²;  ölü bölge ±{np.rad2deg(DB)/2:.2f}°")
print(f"{'genlik':>7} {'frekans':>8} {'yük [N·m]':>10} | {'RMS hata':>9} {'max hata':>9} {'max akım':>9} {'doyma %':>8}")
for amp, f, tg in [(30, 0.5, 0.0), (30, 0.5, 0.6), (30, 1.0, 0.6), (30, 2.0, 0.0), (30, 2.0, 0.6), (5, 2.0, 0.6), (30, 0.5, 1.0)]:
    rms, mx, im, sat = simulate(amp, f, tg)
    print(f"{amp:6d}° {f:7.1f}Hz {tg:10.2f} | {rms:8.2f}° {mx:8.2f}° {im:8.2f}A {100*sat:7.1f}")
print(f"(hedefin tepe hızı: 30° @ 2 Hz -> {np.deg2rad(30)*2*np.pi*2:.2f} rad/s; servonun yüksüz hızı {Vs/(k*N):.2f} rad/s)")

# Sadece ölü bölge: 0.5° adımlık küçük komutlar
th_final = []
for step_deg in [0.3, 0.5, 1.0, 2.0]:
    th, w = 0.0, 0.0; cmd = np.deg2rad(step_deg)
    for s in range(20000):
        e = cmd - th; V = 0.0 if abs(e) < DB/2 else np.clip(Kp*e, -Vs, Vs)
        i = (V - k*N*w)/R; w += 1e-4*(N*eta*k*i - 0.002*w)/Jeff; th += 1e-4*w
    th_final.append(np.rad2deg(th))
print("küçük adım komutları [°] -> 2 s sonraki açı [°]:", [f"{a}->{b:.2f}" for a, b in zip([0.3, 0.5, 1.0, 2.0], th_final)])

# %% plot
from figstyle import plt, save
fig, ax = plt.subplots(1, 1, figsize=(7.0, 3.0))
for f, tg, c in [(0.5, 0.6, "C0"), (2.0, 0.6, "C1")]:
    th, w, cmd = 0.0, 0.0, 0.0; dt = 1e-4; T = []; C = []; X = []
    for s in range(int(3.0/dt)):
        t = s*dt
        if s % 200 == 0: cmd = np.deg2rad(30)*np.sin(2*np.pi*f*t)
        e = cmd - th; V = 0.0 if abs(e) < DB/2 else np.clip(Kp*e, -Vs, Vs); i = (V - k*N*w)/R
        w += dt*(N*eta*k*i - tg*np.sin(th) - 0.002*w)/Jeff; th += dt*w
        if s % 20 == 0: T.append(t); C.append(np.rad2deg(cmd)); X.append(np.rad2deg(th))
    ax.plot(T, C, c=c, lw=0.8, ls="--"); ax.plot(T, X, c=c, lw=1.4, label=f"{f} Hz (kesikli: komut)")
ax.set_xlabel("t [s]"); ax.set_ylabel("açı [°]"); ax.set_title("Servo modeli: 30° sinüs takibi, 0.6 N·m yerçekimi yükü"); ax.legend(fontsize=7)
save("d2_servo")
