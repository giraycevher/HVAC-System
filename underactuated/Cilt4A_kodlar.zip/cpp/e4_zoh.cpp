// e4_zoh.cpp — sıfır dereceli tutucu ile ayrıklaştırma (Taylor serisiyle matris üsteli) ve kararlılık kontrolü
#include <Eigen/Dense>
#include <cmath>
#include <cstdio>
using Mat3 = Eigen::Matrix3d;

Mat3 expm_taylor(const Mat3& M, int terms = 30) {     // küçük, iyi ölçekli matrisler için yeterli
    Mat3 E = Mat3::Identity(), term = Mat3::Identity();
    for (int k = 1; k < terms; ++k) { term = term * M / k; E += term; }
    return E;
}

int main() {
    const double J = 0.0116, b = 0.01;
    Eigen::Matrix2d A; A << 0, 1, 0, -b / J;
    Eigen::Vector2d B(0, 1 / J);
    Eigen::RowVector2d K(3.77, 0.338);                   // Python'daki kutup yerleştirme sonucu (yuvarlanmış)
    for (double dt : {0.001, 0.01, 0.02, 0.05, 0.08}) {
        Mat3 M = Mat3::Zero(); M.topLeftCorner<2, 2>() = A * dt; M.topRightCorner<2, 1>() = B * dt;
        Mat3 E = expm_taylor(M);
        Eigen::Matrix2d Ad = E.topLeftCorner<2, 2>(); Eigen::Vector2d Bd = E.topRightCorner<2, 1>();
        Eigen::Matrix2d Acl = Ad - Bd * K;
        Eigen::Vector2cd ev = Acl.eigenvalues();
        double r = std::max(std::abs(ev(0)), std::abs(ev(1)));
        std::printf("dt=%4.0f ms: en büyük |λ| = %.4f -> %s\n", dt * 1000, r, r < 1 ? "kararlı" : "KARARSIZ");
    }
    return 0;
}
