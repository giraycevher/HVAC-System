// e2_pid.cpp — gerçek zamanlı koda konacak biçimde PID sınıfı (Python e2_pid.py ile aynı algoritma)
#include <algorithm>
#include <cmath>
#include <cstdio>

class Pid {
public:
    enum class AntiWindup { None, Clamp, BackCalc };
    Pid(double kp, double ki, double kd, double dt, double u_max, double tf = 0.01,
        AntiWindup aw = AntiWindup::None, double kb = 0.0)
        : kp_(kp), ki_(ki), kd_(kd), dt_(dt), u_max_(u_max), a_(tf / (tf + dt)), aw_(aw), kb_(kb) {}

    double update(double r, double y) {
        const double e = r - y;
        if (first_) { y_prev_ = y; first_ = false; }
        const double d_raw = -(y - y_prev_) / dt_;          // türev ölçümden: hedef basamağında "tekme" yok
        y_prev_ = y;
        d_ = a_ * d_ + (1.0 - a_) * d_raw;                   // 1. derece filtre
        const double u_unsat = kp_ * e + i_ + kd_ * d_;
        const double u = std::clamp(u_unsat, -u_max_, u_max_);
        switch (aw_) {
            case AntiWindup::Clamp:
                if (!(u != u_unsat && (e > 0) == (u_unsat > 0))) i_ += ki_ * e * dt_;
                break;
            case AntiWindup::BackCalc: i_ += (ki_ * e + kb_ * (u - u_unsat)) * dt_; break;
            case AntiWindup::None: i_ += ki_ * e * dt_; break;
        }
        return u;
    }
    void reset() { i_ = d_ = 0.0; first_ = true; }
private:
    double kp_, ki_, kd_, dt_, u_max_, a_;
    AntiWindup aw_; double kb_;
    double i_ = 0.0, d_ = 0.0, y_prev_ = 0.0; bool first_ = true;
};

int main() {
    const double J = 0.0116, b = 0.01, mgl = 0.6, dt = 0.001, r = 1.2;
    struct Case { const char* name; Pid pid; };
    Case cases[] = {{"PD", Pid(8, 0, 0.4, dt, 1.0)},
                    {"PID, anti-windup yok", Pid(8, 20, 0.4, dt, 1.0)},
                    {"PID, kırpma", Pid(8, 20, 0.4, dt, 1.0, 0.01, Pid::AntiWindup::Clamp)},
                    {"PID, geri hesaplama", Pid(8, 20, 0.4, dt, 1.0, 0.01, Pid::AntiWindup::BackCalc, 20.0)}};
    for (auto& c : cases) {
        double th = 0, w = 0, ymax = 0; int last_out = 0;
        for (int k = 0; k < 3000; ++k) {
            double u = c.pid.update(r, th);
            w += dt * (u - b * w - mgl * std::sin(th)) / J; th += dt * w;
            ymax = std::max(ymax, th);
            if (std::abs(th - r) > 0.02 * r) last_out = k + 1;
        }
        std::printf("%-22s aşım %6.1f%%, son hata %.4f rad, yerleşme %.2f s\n", c.name, (ymax - r) / r * 100, std::abs(th - r), last_out * dt);
    }
    return 0;
}
