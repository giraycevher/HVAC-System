import numpy as np
from scipy.optimize import brentq

# Açık çevrim L(jω) = C(jω) P(jω);  eklem P = 1/(J s² + b s),  PD: C = Kp + Kd s/(τ_f s + 1);  gecikme e^{-sτ}
J, b, tf = 0.0116, 0.01, 0.005
P = lambda s: 1.0/(J*s*s + b*s)
C = lambda s, Kp, Kd: Kp + Kd*s/(tf*s + 1)
def margins(Kp, Kd, delay=0.0):
    L = lambda w: C(1j*w, Kp, Kd)*P(1j*w)*np.exp(-1j*w*delay)
    wc = brentq(lambda w: abs(L(w)) - 1, 1e-2, 1e4)                       # kazanç kesişimi |L| = 1
    pm = 180 + np.degrees(np.unwrap(np.angle(L(np.logspace(-2, np.log10(wc), 5000))))[-1])   # faz SARILMADAN (gecikme -180°'yi aşabilir)
    ws = np.logspace(-1, 4, 20000); ang = np.unwrap(np.angle(L(ws)))
    idx = np.where(ang <= -np.pi)[0]                                      # faz -180°'yi geçtiği yer
    gm = -20*np.log10(abs(L(ws[idx[0]]))) if len(idx) else np.inf
    return wc, pm, gm, np.radians(pm)/wc
print(f"{'Kp':>5} {'Kd':>5} {'gecikme':>8} | ω_c [rad/s]  faz payı  kazanç payı   gecikme payı")
for Kp, Kd, d in [(2, 0.15, 0), (8, 0.3, 0), (8, 0.3, 0.010), (8, 0.3, 0.020), (30, 0.6, 0), (30, 0.6, 0.020)]:
    wc, pm, gm, dm = margins(Kp, Kd, d)
    gms = "∞" if not np.isfinite(gm) else f"{gm:5.1f} dB"
    print(f"{Kp:5.0f} {Kd:5.2f} {d*1000:6.0f} ms | {wc:9.2f}  {pm:7.1f}°  {gms:>10}   " + (f"{dm*1000:7.1f} ms" if pm > 0 else "KARARSIZ (faz payı < 0)"))
print("kural: gecikme τ, kesişim frekansında faz payından ω_c·τ (radyan) yer: 20 ms gecikme, ω_c = 30 rad/s'de 34° demek")

# %% plot
from figstyle import plt, save
ws = np.logspace(-0.5, 3.5, 800); fig, ax = plt.subplots(2, 1, figsize=(6.4, 4.4), sharex=True)
for Kp, Kd, d, c in [(8, 0.3, 0, "C0"), (8, 0.3, 0.02, "C1"), (30, 0.6, 0.02, "C3")]:
    L = C(1j*ws, Kp, Kd)*P(1j*ws)*np.exp(-1j*ws*d)
    ax[0].semilogx(ws, 20*np.log10(abs(L)), c=c, label=f"Kp={Kp}, Kd={Kd}, gecikme {d*1000:.0f} ms")
    ax[1].semilogx(ws, np.degrees(np.unwrap(np.angle(L))), c=c)
ax[0].axhline(0, c="k", lw=0.6); ax[1].axhline(-180, c="k", lw=0.6); ax[1].set_ylim(-400, -60)
ax[0].set_ylabel("|L| [dB]"); ax[1].set_ylabel("∠L [°]"); ax[1].set_xlabel("ω [rad/s]"); ax[0].legend(fontsize=7); ax[0].set_title("Açık çevrim Bode diyagramı")
save("e3_freq")
