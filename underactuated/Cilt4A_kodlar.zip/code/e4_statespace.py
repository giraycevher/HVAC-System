import numpy as np
from scipy.linalg import expm
np.set_printoptions(precision=5, suppress=True)

# Eklem: x = [θ, θ̇], ẋ = A x + B u
J, b = 0.0116, 0.01
A = np.array([[0, 1], [0, -b/J]]); B = np.array([[0], [1/J]])

# (1) Kontrol edilebilirlik ve kutup yerleştirme (Ackermann, 2x2)
Co = np.hstack([B, A@B]); print("kontrol edilebilirlik matrisi rank =", np.linalg.matrix_rank(Co))
def acker(A, B, poles):
    a = np.real(np.poly(poles))                                   # istenen karakteristik polinom katsayıları
    phi = A@A + a[1]*A + a[2]*np.eye(2)
    return np.array([[0, 1]])@np.linalg.inv(np.hstack([B, A@B]))@phi
K = acker(A, B, [-15 + 10j, -15 - 10j])
print("istenen kutuplar -15±10j -> K =", K, " kapalı çevrim özdeğerleri:", np.linalg.eigvals(A - B@K))

# (2) Ayrıklaştırma (sıfır dereceli tutucu): A_d = e^{AΔt}, B_d = ∫ e^{Aτ} dτ B  -> blok üstel matris hilesi
def zoh(A, B, dt):
    M = expm(np.block([[A, B], [np.zeros((1, 3))]])*dt); return M[:2, :2], M[:2, 2:]
for dt in [0.001, 0.01, 0.02, 0.05, 0.08]:
    Ad, Bd = zoh(A, B, dt); ev = np.linalg.eigvals(Ad - Bd@K)
    print(f"Δt = {dt*1000:4.0f} ms: sürekli tasarımlı K ayrık uygulanınca |λ| = {np.abs(ev).round(4)} -> {'kararlı' if np.abs(ev).max() < 1 else 'KARARSIZ'}"
          f"  (beklenen e^(-15Δt) = {np.exp(-15*dt):.4f})")

# (3) Gözlemci: sadece θ ölçülüyor, θ̇ kestiriliyor. Luenberger: x̂' = A x̂ + B u + L (y - C x̂)
C = np.array([[1.0, 0.0]]); L = acker(A.T, C.T, [-60, -70]).T                  # dualite: (A', C') ile tasarla
print("gözlemci kazancı L =", L.ravel(), " gözlemci özdeğerleri:", np.linalg.eigvals(A - L@C).real)
dt = 0.001; Ad, Bd = zoh(A, B, dt); x = np.array([0.3, 0.0]); xh = np.zeros(2); errs = []
for k in range(500):
    u = -(K@xh)[0]; y = x[0]
    xh = xh + dt*(A@xh + B[:, 0]*u + L[:, 0]*(y - xh[0]))
    x = Ad@x + Bd[:, 0]*u; errs.append(np.abs(x - xh))
errs = np.array(errs)
print(f"gözlemcili kontrol: θ̇ kestirim hatasının tepesi {errs[:, 1].max():.2f} rad/s (t={errs[:, 1].argmax()*dt*1000:.0f} ms); 0.1 s sonra hata {errs[100]}, 0.2 s sonra {errs[200]}; 0.5 s sonra θ = {x[0]:.5f} rad")
