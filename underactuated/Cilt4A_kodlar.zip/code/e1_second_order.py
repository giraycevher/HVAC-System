import numpy as np
from scipy.signal import lti, step

# İkinci dereceden sistem: ẍ + 2ζω_n ẋ + ω_n² x = ω_n² u   (birim basamak)
# Örnek: PD kontrollü bir eklem  J θ̈ = Kp(θd - θ) - Kd θ̇  ->  ω_n = sqrt(Kp/J), ζ = Kd / (2 sqrt(Kp J))
J = 0.0116                                    # Cilt 3: servo+uyluk etkin ataleti [kg·m²]
print(f"{'Kp':>6} {'Kd':>6} | {'ω_n':>6} {'ζ':>5} | aşım formül/sim | yükselme(10-90%) | yerleşme(%2) formül 4/(ζω_n) / sim")
for Kp, Kd in [(2.0, 0.05), (2.0, 0.15), (2.0, 0.3), (8.0, 0.3)]:
    wn = np.sqrt(Kp/J); z = Kd/(2*np.sqrt(Kp*J))
    sys = lti([wn**2], [1, 2*z*wn, wn**2]); t, y = step(sys, T=np.linspace(0, 2, 20001))
    Mp = np.exp(-np.pi*z/np.sqrt(1 - z*z))*100 if z < 1 else 0.0
    os_sim = max(0, (y.max() - 1)*100)
    tr = t[np.argmax(y >= 0.9)] - t[np.argmax(y >= 0.1)]
    out = np.where(np.abs(y - 1) > 0.02)[0]; ts = t[out[-1] + 1] if len(out) else 0
    print(f"{Kp:6.1f} {Kd:6.2f} | {wn:6.2f} {z:5.2f} | {Mp:5.1f}% / {os_sim:5.1f}% | {tr*1000:7.1f} ms       | {4/(z*wn)*1000:7.1f} ms / {ts*1000:7.1f} ms")
