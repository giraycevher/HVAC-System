import numpy as np

# Cilt 1 Bölüm 6'daki 2-uzuvlu bacak (kalça sabit; havadaki salınım bacağı). Model: M(q) q̈ + C q̇ + g = τ
g0 = 9.81; L = np.array([0.2, 0.2]); ms = np.array([0.30, 0.20]); lc = L/2; Is = ms*L**2/12
def M(q):
    c2 = np.cos(q[1]); m11 = Is[0] + Is[1] + ms[0]*lc[0]**2 + ms[1]*(L[0]**2 + lc[1]**2 + 2*L[0]*lc[1]*c2)
    m12 = Is[1] + ms[1]*(lc[1]**2 + L[0]*lc[1]*c2); return np.array([[m11, m12], [m12, Is[1] + ms[1]*lc[1]**2]])
def h(q, qd):                                         # C q̇ + g
    hh = -ms[1]*L[0]*lc[1]*np.sin(q[1])
    C = np.array([[hh*qd[1], hh*(qd[0] + qd[1])], [-hh*qd[0], 0.0]])
    g = np.array([ms[0]*g0*lc[0]*np.sin(q[0]) + ms[1]*g0*(L[0]*np.sin(q[0]) + lc[1]*np.sin(q[0] + q[1])), ms[1]*g0*lc[1]*np.sin(q[0] + q[1])])
    return C@qd + g, g

# Hedef: salınım bacağı yörüngesi (kalça ±0.5 rad, diz 0.3..1.3 rad), 1.25 Hz
f = 1.25; w = 2*np.pi*f
def ref(t):
    qd = np.array([0.5*np.sin(w*t), 0.8 - 0.5*np.cos(w*t)])
    qdd = np.array([0.5*w*np.cos(w*t), 0.5*w*np.sin(w*t)]); qddd = np.array([-0.5*w*w*np.sin(w*t), 0.5*w*w*np.cos(w*t)])
    return qd, qdd, qddd
Kp, Kd = np.diag([6.0, 6.0]), np.diag([0.2, 0.2])         # aynı PD kazançları (tork birimi: N·m/rad)
wn = 15.0; Kp_ct, Kd_ct = wn**2*np.eye(2), 2*wn*np.eye(2)    # computed torque: hata dinamiği ë + 2ζω_n ė + ω_n² e = 0

def run(mode, mass_err=1.0, T=4.0, dt=1e-4):
    q = np.array([0.0, 0.3]); qd = np.zeros(2); E = []; tau_max = 0
    for k in range(int(T/dt)):
        t = k*dt; r, rd, rdd = ref(t); e = r - q; ed = rd - qd
        Mh = M(q)*mass_err; hh_, g_ = h(q, qd); hh_ = hh_*mass_err; g_ = g_*mass_err     # kontrolcünün MODELİ (hatalı olabilir)
        if mode == "PD": tau = Kp@e + Kd@ed
        elif mode == "PD+g": tau = Kp@e + Kd@ed + g_
        else: tau = Mh@(rdd + Kd_ct@ed + Kp_ct@e) + hh_                                    # hesaplanmış tork (ters dinamik)
        tau_max = max(tau_max, np.abs(tau).max())
        qdd = np.linalg.solve(M(q), tau - h(q, qd)[0])                                       # GERÇEK sistem
        qd = qd + dt*qdd; q = q + dt*qd
        if t > 2.0: E.append(e)
    E = np.array(E); return np.degrees(np.sqrt(np.mean(E**2, axis=0))), tau_max
print(f"{'kontrolcü':>28} | RMS hata kalça, diz [°] | max |τ| [N·m]")
for mode, me in [("PD", 1.0), ("PD+g", 1.0), ("CT", 1.0), ("CT", 1.2), ("CT", 0.7)]:
    rms, tm = run(mode, me)
    name = {"PD": "PD", "PD+g": "PD + yerçekimi kompanzasyonu", "CT": f"hesaplanmış tork (model×{me})"}[mode]
    print(f"{name:>28} | {rms[0]:6.3f}, {rms[1]:6.3f}            | {tm:.3f}")

# Sabit duruş tutma (statik): hedef q = (0.6, 1.0) rad, 3 s
for mode in ["PD", "PD+g"]:
    q = np.array([0.0, 0.3]); qd = np.zeros(2); target = np.array([0.6, 1.0])
    for k in range(30000):
        e = target - q; tau = Kp@e - Kd@qd + (h(q, np.zeros(2))[1] if mode == "PD+g" else 0)
        qd = qd + 1e-4*np.linalg.solve(M(q), tau - h(q, qd)[0]); q = q + 1e-4*qd
    print(f"statik tutma, {mode:>5}: kalıcı hata {np.degrees(target - q).round(3)} derece")
