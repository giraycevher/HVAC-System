import numpy as np

# Dikey tek bacak: gövde kütlesi m, kütlesiz bacak (boy l0 = 0.30 m), 10 cm'den düşüyor.
# Temas sırasında aktüatör bir "sanal yay-sönüm" uygular: F = k (l0 - l) - c l̇  (empedans kontrolü), F ∈ [0, F_max]
m, g, l0, F_max = 2.0, 9.81, 0.30, 120.0
def drop(k, c, h=0.10, dt=1e-5, T=1.0):
    z = l0 + h; v = 0.0; Fpk = 0.0; zmin = z; contact_t = None; t = 0.0
    for i in range(int(T/dt)):
        if z < l0:                                   # ayak yerde: bacak boyu l = z
            F = np.clip(k*(l0 - z) - c*v, 0, F_max)
            if contact_t is None: contact_t = t
        else: F = 0.0
        a = F/m - g; v += a*dt; z += v*dt; t += dt
        Fpk = max(Fpk, F); zmin = min(zmin, z)
    return Fpk, l0 - zmin, z
print(f"{'k [N/m]':>8} {'c [N·s/m]':>10} | tepe kuvvet   (ağırlığın katı) | max sıkışma | 1 s sonra yükseklik")
for k, c in [(20000, 400), (5000, 150), (1500, 60), (800, 40)]:
    Fpk, comp, zend = drop(k, c)
    print(f"{k:8.0f} {c:10.0f} | {Fpk:8.1f} N    ({Fpk/(m*g):5.1f}×)          | {comp*100:6.2f} cm  | {zend*100:6.2f} cm (statik denge: {(l0 - m*g/k)*100:.2f} cm)")
print(f"aktüatör kuvvet sınırı {F_max} N = ağırlığın {F_max/(m*g):.1f} katı; sert 'konum kontrolü' bu sınıra dayanıyor")
