import numpy as np

# Tork kontrollü bir eklem: J θ̈ = u - b θ̇ - m g l_c sin θ,  |u| <= U_MAX  (tork doyması)
J, b, mgl, U_MAX = 0.0116, 0.01, 0.6, 1.0
dt, T = 0.001, 3.0

class PID:
    """Ayrık PID: türev ÖLÇÜMDEN (türev tekmesi yok), 1. derece türev filtresi, iki anti-windup seçeneği."""
    def __init__(self, kp, ki, kd, dt, u_max, tf=0.01, aw="none", kb=None):
        self.kp, self.ki, self.kd, self.dt, self.u_max, self.aw = kp, ki, kd, dt, u_max, aw
        self.a = tf/(tf + dt)                       # türev filtresi katsayısı (zaman sabiti tf)
        self.kb = kb if kb is not None else 1.0/max(kp, 1e-9)*ki   # back-calculation kazancı
        self.i = 0.0; self.d = 0.0; self.y_prev = None
    def update(self, r, y):
        e = r - y
        if self.y_prev is None: self.y_prev = y
        d_raw = -(y - self.y_prev)/self.dt; self.y_prev = y              # -dy/dt (r sabitken = de/dt)
        self.d = self.a*self.d + (1 - self.a)*d_raw
        u_unsat = self.kp*e + self.i + self.kd*self.d
        u = float(np.clip(u_unsat, -self.u_max, self.u_max))
        if self.aw == "clamp":                                           # doymadaysa ve hata doymayı büyütüyorsa integrali durdur
            if not (u != u_unsat and np.sign(e) == np.sign(u_unsat)): self.i += self.ki*e*self.dt
        elif self.aw == "back":                                          # geri hesaplama: doyma farkı integrali geri çeker
            self.i += (self.ki*e + self.kb*(u - u_unsat))*self.dt
        else:
            self.i += self.ki*e*self.dt
        return u

def run(ctrl, r=1.2, noise=0.0, seed=0):
    rng = np.random.default_rng(seed); th = w = 0.0; Y = []; U = []
    for k in range(int(T/dt)):
        y = th + noise*rng.standard_normal()
        u = ctrl.update(r, y); w += dt*(u - b*w - mgl*np.sin(th))/J; th += dt*w; Y.append(th); U.append(u)
    Y = np.array(Y); U = np.array(U)
    out = np.where(np.abs(Y - r) > 0.02*r)[0]; ts = (out[-1] + 1)*dt if len(out) else 0
    return Y, U, (Y.max() - r)/r*100, abs(Y[-1] - r), ts

print("hedef 1.2 rad (yerçekimi torku sin(1.2)·0.6 = %.3f N·m), tork sınırı ±%.1f N·m" % (mgl*np.sin(1.2), U_MAX))
cases = [("PD (Kp=8, Kd=0.4)", PID(8, 0, 0.4, dt, U_MAX)),
         ("PID, anti-windup YOK", PID(8, 20, 0.4, dt, U_MAX)),
         ("PID, kırpma (clamp)", PID(8, 20, 0.4, dt, U_MAX, aw="clamp")),
         ("PID, geri hesaplama", PID(8, 20, 0.4, dt, U_MAX, aw="back", kb=20.0))]
res = {}
for name, c in cases:
    Y, U, os_, ess, ts = run(c); res[name] = (Y, U)
    print(f"  {name:>22}: aşım {os_:6.1f}%, 3 s sonra hata {ess:.4f} rad, yerleşme (%2) {ts:.2f} s, doymada geçen süre {np.mean(np.abs(U) >= U_MAX)*T:.2f} s")

# Ölçüm gürültüsü ve türev filtresi
for tf in [0.0, 0.005, 0.02]:
    c = PID(8, 20, 0.4, dt, U_MAX, tf=tf, aw="clamp"); Y, U, *_ = run(c, noise=0.002)
    print(f"gürültü σ=0.002 rad, türev filtresi τ_f={tf*1000:4.0f} ms: tork RMS dalgalanması (son 1 s) {np.std(U[-1000:]):.3f} N·m")

# %% plot
from figstyle import plt, save
t = np.arange(int(T/dt))*dt; fig, ax = plt.subplots(1, 2, figsize=(8.0, 3.0))
for name, (Y, U) in res.items(): ax[0].plot(t, Y, label=name, lw=1.2); ax[1].plot(t, U, lw=1)
ax[0].axhline(1.2, c="k", ls="--", lw=0.8); ax[0].set_xlabel("t [s]"); ax[0].set_ylabel("θ [rad]"); ax[0].legend(fontsize=6); ax[0].set_title("Basamak yanıtı")
ax[1].set_xlabel("t [s]"); ax[1].set_ylabel("u [N·m]"); ax[1].set_title("Kontrol torku (±1 N·m doyma)")
save("e2_pid")
