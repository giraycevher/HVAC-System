"""y7_python.py — robotik için iyi Python alışkanlıkları: dataclass, tip ipuçları, vektörleştirme, tuzaklar."""
from __future__ import annotations
from dataclasses import dataclass, field
import time
import numpy as np

@dataclass(frozen=True)                       # frozen: yanlışlıkla değiştirilemez parametre kümesi
class LegParams:
    l1: float = 0.20
    l2: float = 0.20

@dataclass
class Robot:
    name: str
    joint_names: list[str] = field(default_factory=list)   # DOĞRU: her nesneye yeni liste

def forward_loop(p: LegParams, q: np.ndarray) -> np.ndarray:
    out = np.empty((len(q), 2))
    for i, (q1, q2) in enumerate(q):          # Python döngüsü: her eleman için yorumlayıcı maliyeti
        out[i] = (p.l1 * np.sin(q1) + p.l2 * np.sin(q1 + q2), -p.l1 * np.cos(q1) - p.l2 * np.cos(q1 + q2))
    return out

def forward_vec(p: LegParams, q: np.ndarray) -> np.ndarray:
    q1, q2 = q[:, 0], q[:, 1]                 # vektörleştirilmiş: tüm dizi C'de tek seferde
    return np.c_[p.l1 * np.sin(q1) + p.l2 * np.sin(q1 + q2), -p.l1 * np.cos(q1) - p.l2 * np.cos(q1 + q2)]

p = LegParams()
q = np.random.default_rng(0).uniform([-0.8, 0.1], [0.8, 2.0], (100_000, 2))
t0 = time.perf_counter(); a = forward_loop(p, q); t1 = time.perf_counter(); b = forward_vec(p, q); t2 = time.perf_counter()
print(f"100 000 FK: döngü {1000 * (t1 - t0):.0f} ms, vektörleştirilmiş {1000 * (t2 - t1):.1f} ms "
      f"(~{(t1 - t0) / (t2 - t1):.0f} kat), fark {np.abs(a - b).max():.1e}")

# Tuzak 1: değiştirilebilir varsayılan argüman
def add_joint_bad(name, joints=[]):           # liste fonksiyon TANIMLANIRKEN bir kez oluşturulur!
    joints.append(name); return joints
print("tuzak 1:", add_joint_bad("diz"), add_joint_bad("kalca"), "<- ikinci çağrı ilkinin listesini görüyor")
r1, r2 = Robot("SB-1"), Robot("SB-2"); r1.joint_names.append("diz")
print("dataclass default_factory:", r1.joint_names, r2.joint_names)

# Tuzak 2: kayan nokta eşitliği
x = 0.1 + 0.2
print("tuzak 2: 0.1 + 0.2 == 0.3 ?", x == 0.3, "| np.isclose:", np.isclose(x, 0.3))

# Tuzak 3: NumPy görünümü (view) ile kopya
a = np.zeros(4); v = a[1:3]; v[:] = 7
print("tuzak 3: dilim bir görünüm, orijinal değişti:", a, "| güvenli: a[1:3].copy()")

# Tuzak 4: dondurulmuş parametre değiştirilemez
try:
    p.l1 = 0.3
except Exception as e:
    print("tuzak 4 (iyi anlamda): frozen dataclass ->", type(e).__name__)
