"""y8_mjcf.py — SB-1'in MuJoCo (MJCF) modelini Python'dan ÜRETİR: kütle/atalet Cilt 1 formülleriyle hesaplanır,
XML tek kaynaktan (parametrelerden) çıkar. Elle 300 satır XML yazmak yerine kodla üretmek hataları azaltır.
NOT: Bu ortamda MuJoCo kurulu olmadığı için model burada simüle EDİLMEDİ; sadece XML geçerliliği, kütle
toplamı ve atalet değerleri kontrol edildi. Kendi bilgisayarında:  python -m mujoco.viewer --mjcf=sb1.xml"""
import xml.etree.ElementTree as ET
from xml.dom import minidom

def box_inertia(m, a, b, c):
    """Kütle merkezinden geçen eksenlere göre katı kutu (a, b, c kenarları x, y, z): Cilt 1 Bölüm 6."""
    return (m * (b * b + c * c) / 12, m * (a * a + c * c) / 12, m * (a * a + b * b) / 12)

# Parametreler: Cilt 6 Bölüm 4'teki tork sonucuna göre HAFİF tasarım (toplam ~1.2 kg)
P = dict(torso=(0.40, (0.10, 0.14, 0.12)),   # kütle [kg], kutu boyutları [m] (gövde + Arduino + pil)
         hip=(0.06, (0.04, 0.04, 0.04)),     # kalça yaw/roll arası bağlantı parçası (servo dahil)
         thigh=(0.15, (0.04, 0.04, 0.20)),
         shank=(0.12, (0.04, 0.04, 0.20)),
         foot=(0.05, (0.08, 0.05, 0.01)))
SERVO_TAU = 1.08                              # MG996R durma torku, 6 V (datasheet: 11 kgf·cm)
KP = 8.0                                      # konum servo kazancı [N·m/rad] (Cilt 3'ün servo modeline göre ayarlanmalı)

def f3(v): return " ".join(f"{x:.6g}" for x in v)

def body(parent, name, pos, part, com, joint=None):
    b = ET.SubElement(parent, "body", name=name, pos=f3(pos))
    m, (a, bb, c) = P[part]
    ET.SubElement(b, "inertial", pos=f3(com), mass=f"{m:.4g}", diaginertia=f3(box_inertia(m, a, bb, c)))
    if joint:
        jn, axis, rng = joint
        ET.SubElement(b, "joint", name=jn, axis=axis, range=f3(rng))
    ET.SubElement(b, "geom", type="box", size=f3((a / 2, bb / 2, c / 2)), pos=f3(com))
    return b

root = ET.Element("mujoco", model="sb1")
ET.SubElement(root, "compiler", angle="radian")
ET.SubElement(root, "option", timestep="0.001")
d = ET.SubElement(root, "default")
ET.SubElement(d, "joint", damping="0.05", armature="0.002", frictionloss="0.02")
ET.SubElement(d, "geom", contype="1", conaffinity="1", friction="0.8 0.02 0.001", rgba="0.4 0.6 0.8 1")
ET.SubElement(d, "position", kp=f"{KP}", forcelimited="true", forcerange=f"{-SERVO_TAU} {SERVO_TAU}")
wb = ET.SubElement(root, "worldbody")
ET.SubElement(wb, "light", pos="0 0 2", dir="0 0 -1")
ET.SubElement(wb, "geom", name="floor", type="plane", size="3 3 0.1", rgba="0.85 0.85 0.85 1")
torso = body(wb, "torso", (0, 0, 0.51), "torso", (0, 0, 0.03))
ET.SubElement(torso, "freejoint", name="root")
ET.SubElement(torso, "site", name="imu", pos="0 0 0.03")
joints = []
for side, y in (("sol", 0.05), ("sag", -0.05)):
    h = body(torso, f"{side}_kalca_yaw", (0, y, -0.04), "hip", (0, 0, -0.02), (f"{side}_kalca_yaw", "0 0 1", (-0.5, 0.5)))
    r = body(h, f"{side}_kalca_roll", (0, 0, -0.04), "hip", (0, 0, 0), (f"{side}_kalca_roll", "1 0 0", (-0.4, 0.4)))
    t = body(r, f"{side}_uyluk", (0, 0, 0), "thigh", (0, 0, -0.10), (f"{side}_kalca_pitch", "0 1 0", (-1.5, 1.0)))
    s = body(t, f"{side}_baldir", (0, 0, -0.20), "shank", (0, 0, -0.10), (f"{side}_diz", "0 1 0", (0.0, 2.3)))
    f = body(s, f"{side}_ayak", (0, 0, -0.20), "foot", (0.01, 0, -0.015), (f"{side}_bilek_pitch", "0 1 0", (-1.0, 1.0)))
    joints += [f"{side}_kalca_yaw", f"{side}_kalca_roll", f"{side}_kalca_pitch", f"{side}_diz", f"{side}_bilek_pitch"]
act = ET.SubElement(root, "actuator")
for j in joints:
    ET.SubElement(act, "position", name=j, joint=j)
sens = ET.SubElement(root, "sensor")
ET.SubElement(sens, "gyro", site="imu"); ET.SubElement(sens, "accelerometer", site="imu")

xml = minidom.parseString(ET.tostring(root)).toprettyxml(indent="  ")
open("sb1.xml", "w").write(xml)
ET.fromstring(xml)                            # yeniden ayrıştır: biçim hatası varsa burada patlar
total = P["torso"][0] + 2 * (2 * P["hip"][0] + P["thigh"][0] + P["shank"][0] + P["foot"][0])
print(f"sb1.xml yazıldı: {len(xml.splitlines())} satır, {len(joints)} eklem/aktüatör, toplam kütle {total:.2f} kg")
print("uyluk ataleti (Ixx, Iyy, Izz) [kg·m²]:", f3(box_inertia(*((P['thigh'][0],) + P['thigh'][1]))))
print(f"tek ayak üstünde tüm ağırlık {total * 9.81:.1f} N; diz torku sınırı {SERVO_TAU} N·m için "
      f"diz-ayak yatay mesafesi ≤ {100 * SERVO_TAU / (total * 9.81):.1f} cm (Cilt 6 Bölüm 4)")
print("\n".join(xml.splitlines()[:14]) + "\n  ...")
