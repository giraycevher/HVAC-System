#include "sb1/leg.hpp"
#include <cmath>

namespace sb1 {

Vec2 forward(const LegParams& p, double q1, double q2) {
    return {p.l1 * std::sin(q1) + p.l2 * std::sin(q1 + q2), -p.l1 * std::cos(q1) - p.l2 * std::cos(q1 + q2)};
}

std::optional<Vec2> inverse(const LegParams& p, const Vec2& f) {
    const double d2 = f[0] * f[0] + f[1] * f[1];
    const double c2 = (d2 - p.l1 * p.l1 - p.l2 * p.l2) / (2 * p.l1 * p.l2);
    if (c2 < -1.0 || c2 > 1.0) return std::nullopt;            // erişim dışı
    const double q2 = std::acos(c2);                             // diz pozitif büküm
    const double q1 = std::atan2(f[0], -f[1]) - std::atan2(p.l2 * std::sin(q2), p.l1 + p.l2 * std::cos(q2));
    return Vec2{q1, q2};
}

}  // namespace sb1
