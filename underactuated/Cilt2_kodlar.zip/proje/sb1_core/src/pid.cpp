#include "sb1/pid.hpp"
#include <algorithm>

namespace sb1 {

double Pid::update(double ref, double y, double dt) {
    const double e = ref - y;
    const double dy = first_ ? 0.0 : (y - y_prev_) / dt;      // türev ölçümden: hedef basamağında tekme yok
    first_ = false; y_prev_ = y;
    const double u_free = kp_ * e + i_ - kd_ * dy;
    const double u = std::clamp(u_free, -u_max_, u_max_);
    const bool saturating = (u != u_free) && (e * u_free > 0);  // doyma ve hata onu büyütüyor
    if (!saturating) i_ += ki_ * e * dt;
    return u;
}

}  // namespace sb1
