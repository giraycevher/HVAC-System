#include <gtest/gtest.h>
#include <cmath>
#include "sb1/leg.hpp"

TEST(Leg, ForwardStraightDown) {
    auto f = sb1::forward({}, 0.0, 0.0);
    EXPECT_NEAR(f[0], 0.0, 1e-12);
    EXPECT_NEAR(f[1], -0.40, 1e-12);
}

TEST(Leg, InverseRoundTrip) {                       // IK(FK(q)) == q, birçok noktada
    sb1::LegParams p;
    for (double q1 = -0.8; q1 <= 0.8; q1 += 0.2)
        for (double q2 = 0.1; q2 <= 2.0; q2 += 0.3) {
            auto q = sb1::inverse(p, sb1::forward(p, q1, q2));
            ASSERT_TRUE(q.has_value());
            EXPECT_NEAR((*q)[0], q1, 1e-9);
            EXPECT_NEAR((*q)[1], q2, 1e-9);
        }
}

TEST(Leg, UnreachableReturnsNullopt) {
    EXPECT_FALSE(sb1::inverse({}, {0.0, -0.45}).has_value());
}
