#include <gtest/gtest.h>
#include "sb1/pid.hpp"

TEST(Pid, TwoStepTrace) {                           // Cilt 4A, E2.5 ile aynı sayılar (kd = 0)
    sb1::Pid pid(2.0, 1.0, 0.0, 100.0);
    EXPECT_DOUBLE_EQ(pid.update(1.0, 0.0, 0.1), 2.0);
    EXPECT_DOUBLE_EQ(pid.update(1.0, 0.5, 0.1), 1.1);
}

TEST(Pid, OutputSaturates) {
    sb1::Pid pid(10.0, 0.0, 0.0, 1.0);
    EXPECT_DOUBLE_EQ(pid.update(1.0, 0.0, 0.01), 1.0);
    EXPECT_DOUBLE_EQ(pid.update(-1.0, 0.0, 0.01), -1.0);
}

TEST(Pid, NoWindupWhileSaturated) {                 // 1 s doymada kalmak integrali şişirmemeli
    sb1::Pid pid(1.0, 5.0, 0.0, 0.5);
    for (int k = 0; k < 1000; ++k) pid.update(10.0, 0.0, 0.001);
    EXPECT_LT(pid.update(0.0, 0.0, 0.001), 0.5);   // hedef 0 olunca çıkış hemen doymadan çıkmalı
}

TEST(Pid, NoDerivativeKickOnSetpointStep) {
    sb1::Pid pid(0.0, 0.0, 0.4, 1000.0);
    pid.update(0.0, 0.0, 0.001);
    EXPECT_DOUBLE_EQ(pid.update(1.0, 0.0, 0.001), 0.0);   // ölçüm değişmedi -> türev katkısı 0
}
