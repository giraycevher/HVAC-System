#include <cstdio>
#include "sb1/leg.hpp"

int main() {
    sb1::LegParams p;
    for (double z : {-0.30, -0.35, -0.39, -0.45}) {
        auto q = sb1::inverse(p, {0.03, z});
        if (q) std::printf("ayak (0.03, %.2f): q1 = %6.2f°, q2 = %6.2f°\n", z, (*q)[0] * 57.2958, (*q)[1] * 57.2958);
        else   std::printf("ayak (0.03, %.2f): ulaşılamaz\n", z);
    }
}
