#pragma once

namespace sb1 {

class Pid {
public:
    Pid(double kp, double ki, double kd, double u_max) : kp_(kp), ki_(ki), kd_(kd), u_max_(u_max) {}
    double update(double ref, double y, double dt);   // türev ölçümden; kırpmalı anti-windup
    void reset() { i_ = 0; y_prev_ = 0; first_ = true; }
private:
    double kp_, ki_, kd_, u_max_;
    double i_ = 0, y_prev_ = 0;
    bool first_ = true;
};

}  // namespace sb1
