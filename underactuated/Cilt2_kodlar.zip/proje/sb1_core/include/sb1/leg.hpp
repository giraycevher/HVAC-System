#pragma once
#include <array>
#include <optional>

namespace sb1 {

// Düzlemsel 2-uzuvlu bacak (Cilt 1): kalçaya göre ayak konumu, x ileri, z yukarı
struct LegParams { double l1 = 0.20, l2 = 0.20; };
using Vec2 = std::array<double, 2>;

Vec2 forward(const LegParams& p, double q1, double q2);
// Ters kinematik: ulaşılamazsa boş döner (istisna atmaz; gerçek zamanlı kod için uygun)
std::optional<Vec2> inverse(const LegParams& p, const Vec2& foot);

}  // namespace sb1
