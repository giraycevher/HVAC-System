"""SB-1 bacak kinematiği (Python sürümü), pytest ile test edilir."""
import numpy as np

def forward(q1: float, q2: float, l1: float = 0.2, l2: float = 0.2) -> tuple[float, float]:
    return (l1 * np.sin(q1) + l2 * np.sin(q1 + q2), -l1 * np.cos(q1) - l2 * np.cos(q1 + q2))

def inverse(x: float, z: float, l1: float = 0.2, l2: float = 0.2) -> tuple[float, float] | None:
    c2 = (x * x + z * z - l1 * l1 - l2 * l2) / (2 * l1 * l2)
    if not -1.0 <= c2 <= 1.0:
        return None
    q2 = np.arccos(c2)
    q1 = np.arctan2(x, -z) - np.arctan2(l2 * np.sin(q2), l1 + l2 * np.cos(q2))
    return q1, q2
