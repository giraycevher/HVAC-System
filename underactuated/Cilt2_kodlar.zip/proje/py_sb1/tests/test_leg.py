import numpy as np
import pytest
from leg import forward, inverse

def test_straight_down():
    assert forward(0.0, 0.0) == pytest.approx((0.0, -0.4))

@pytest.mark.parametrize("q1", np.linspace(-0.8, 0.8, 5))
@pytest.mark.parametrize("q2", np.linspace(0.1, 2.0, 5))
def test_round_trip(q1, q2):
    assert inverse(*forward(q1, q2)) == pytest.approx((q1, q2), abs=1e-9)

def test_unreachable():
    assert inverse(0.0, -0.45) is None
