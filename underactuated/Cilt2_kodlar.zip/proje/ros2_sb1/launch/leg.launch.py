# leg.launch.py — DİKKAT: bu ortamda çalıştırılmadı.
from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    return LaunchDescription([
        Node(package="sb1_ros", executable="leg_ik_node", name="leg_ik",
             parameters=[{"l1": 0.20, "l2": 0.20}], output="screen"),
    ])
