// leg_ik_node.cpp — ROS 2 (rclcpp) düğümü: hedef ayak konumunu dinler, IK ile eklem komutu yayınlar.
// DİKKAT: Bu dosya bu ortamda DERLENMEDİ (ROS 2 kurulu değil). Humble/Jazzy rclcpp API'sine göre yazıldı.
#include <chrono>
#include <memory>
#include <geometry_msgs/msg/point.hpp>
#include <rclcpp/rclcpp.hpp>
#include <sensor_msgs/msg/joint_state.hpp>
#include "sb1/leg.hpp"                                  // Bölüm 6'daki sb1_core kütüphanesi

using namespace std::chrono_literals;

class LegIkNode : public rclcpp::Node {
public:
    LegIkNode() : Node("leg_ik") {
        params_.l1 = declare_parameter("l1", 0.20);     // ros2 run ... --ros-args -p l1:=0.21
        params_.l2 = declare_parameter("l2", 0.20);
        pub_ = create_publisher<sensor_msgs::msg::JointState>("joint_command", 10);
        sub_ = create_subscription<geometry_msgs::msg::Point>(
            "foot_target", 10, [this](geometry_msgs::msg::Point::SharedPtr msg) { target_ = *msg; });
        timer_ = create_wall_timer(10ms, [this] { tick(); });   // 100 Hz
    }

private:
    void tick() {
        auto q = sb1::inverse(params_, {target_.x, target_.z});
        if (!q) { RCLCPP_WARN_THROTTLE(get_logger(), *get_clock(), 1000, "hedef erişim dışında"); return; }
        sensor_msgs::msg::JointState js;
        js.header.stamp = now();
        js.name = {"sol_kalca_pitch", "sol_diz"};
        js.position = {(*q)[0], (*q)[1]};
        pub_->publish(js);
    }
    sb1::LegParams params_;
    geometry_msgs::msg::Point target_{};
    rclcpp::Publisher<sensor_msgs::msg::JointState>::SharedPtr pub_;
    rclcpp::Subscription<geometry_msgs::msg::Point>::SharedPtr sub_;
    rclcpp::TimerBase::SharedPtr timer_;
};

int main(int argc, char** argv) {
    rclcpp::init(argc, argv);
    rclcpp::spin(std::make_shared<LegIkNode>());
    rclcpp::shutdown();
    return 0;
}
