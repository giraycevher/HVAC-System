// y2_raii.cpp — C'den C++'a: RAII, akıllı işaretçiler, taşıma (move) semantiği
#include <cstdio>
#include <memory>
#include <utility>
#include <vector>

// Bir donanım kaynağını temsil eden sınıf (ör. seri port). Kurucu açar, yıkıcı KAPATIR: RAII.
class SerialPort {
public:
    explicit SerialPort(const char* name) : name_(name) { std::printf("  [aç]    %s\n", name_); }
    ~SerialPort() { if (name_) std::printf("  [kapat] %s\n", name_); }
    SerialPort(const SerialPort&) = delete;                 // kopyalanamaz: aynı portu iki nesne kapatmasın
    SerialPort& operator=(const SerialPort&) = delete;
    SerialPort(SerialPort&& o) noexcept : name_(std::exchange(o.name_, nullptr)) {}   // taşınabilir: sahiplik devri
    void write(int v) const { std::printf("  %s <- %d\n", name_, v); }
private:
    const char* name_;
};

void erken_cikis(bool hata) {
    SerialPort p("/dev/ttyUSB0");
    p.write(90);
    if (hata) { std::printf("  hata! erken return\n"); return; }   // C'de burada close() unutulurdu
    p.write(45);
}                                                                    // her yoldan çıkışta yıkıcı çağrılır

struct Servo { int id; explicit Servo(int i) : id(i) {} ~Servo() { std::printf("  servo %d silindi\n", id); } };

int main() {
    std::printf("1) RAII, normal ve erken çıkış:\n");
    erken_cikis(false);
    erken_cikis(true);

    std::printf("2) unique_ptr: tek sahip, otomatik delete\n");
    {
        auto s = std::make_unique<Servo>(1);
        std::unique_ptr<Servo> t = std::move(s);                     // sahiplik t'ye geçti
        std::printf("  s boş mu? %s, t->id = %d\n", s ? "hayır" : "evet", t->id);
    }                                                                 // t kapsamdan çıkınca servo 1 silinir

    std::printf("3) shared_ptr: paylaşılan sahiplik, sayaç\n");
    std::shared_ptr<Servo> a = std::make_shared<Servo>(2);
    {
        std::shared_ptr<Servo> b = a;
        std::printf("  sayaç = %ld\n", a.use_count());
    }
    std::printf("  sayaç = %ld\n", a.use_count());
    a.reset();                                                        // son sahip bıraktı: silinir

    std::printf("4) vector içinde taşınabilir kaynaklar\n");
    std::vector<SerialPort> ports;
    ports.reserve(2);                                                 // yeniden boyutlanırken taşıma olmasın
    ports.emplace_back("/dev/ttyACM0");
    ports.push_back(SerialPort("/dev/ttyACM1"));                      // geçici nesne taşınır (kopya YOK)
    std::printf("  main bitiyor\n");
    return 0;                                                         // vektör yok olur, portlar kapanır
}
