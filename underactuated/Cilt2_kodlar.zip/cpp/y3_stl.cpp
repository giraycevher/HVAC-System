// y3_stl.cpp — şablonlar, STL kapları ve algoritmaları, lambda'lar: robotik veri işleme örnekleri
#include <algorithm>
#include <array>
#include <cstdio>
#include <map>
#include <numeric>
#include <string>
#include <vector>

// Sabit boyutlu halka tampon (ring buffer): gerçek zamanlı kodda bellek ayırmadan son N örneği tutar
template <typename T, std::size_t N>
class RingBuffer {
public:
    void push(const T& v) { data_[head_] = v; head_ = (head_ + 1) % N; if (size_ < N) ++size_; }
    std::size_t size() const { return size_; }
    T median() const {                                       // medyan filtresi: tek aykırı ölçümü yok eder
        std::array<T, N> tmp = data_;
        auto mid = tmp.begin() + size_ / 2;
        std::nth_element(tmp.begin(), mid, tmp.begin() + size_);
        return *mid;
    }
    T mean() const { return std::accumulate(data_.begin(), data_.begin() + size_, T{}) / T(size_); }
private:
    std::array<T, N> data_{};
    std::size_t head_ = 0, size_ = 0;
};

// Genel (generic) kırpma fonksiyonu: her sayısal tür için derleyici ayrı sürüm üretir
template <typename T>
constexpr T clamp_to(T v, T lo, T hi) { return v < lo ? lo : (v > hi ? hi : v); }

struct Joint { std::string name; double pos, limit_lo, limit_hi; };

int main() {
    // 1) Gürültülü bir potansiyometre okuması, arada bir sıçrama (ör. kablo teması)
    std::vector<double> raw = {1.00, 1.01, 0.99, 1.02, 3.50, 1.00, 0.98, 1.01, 1.00, -2.0, 1.02};
    RingBuffer<double, 5> rb;
    std::printf("ham    ortalama  medyan\n");
    for (double r : raw) { rb.push(r); std::printf("%5.2f   %6.3f   %6.3f\n", r, rb.mean(), rb.median()); }

    // 2) Lambda ile sıralama ve arama: eklem sınırı ihlali
    std::vector<Joint> joints = {{"sol_kalca", 0.4, -1.0, 1.0}, {"sol_diz", 2.6, 0.0, 2.4},
                                 {"sag_kalca", -1.2, -1.0, 1.0}, {"sag_diz", 1.1, 0.0, 2.4}};
    auto ihlal = [](const Joint& j) { return j.pos < j.limit_lo || j.pos > j.limit_hi; };
    std::printf("sınır ihlali olan eklem sayısı: %ld\n", std::count_if(joints.begin(), joints.end(), ihlal));
    for (auto& j : joints) if (ihlal(j)) {
        double old = j.pos; j.pos = clamp_to(j.pos, j.limit_lo, j.limit_hi);
        std::printf("  %-10s %5.2f -> %5.2f\n", j.name.c_str(), old, j.pos);
    }
    std::sort(joints.begin(), joints.end(), [](const Joint& a, const Joint& b) { return a.pos > b.pos; });
    std::printf("konuma göre azalan: ");
    for (const auto& j : joints) std::printf("%s ", j.name.c_str());
    std::printf("\n");

    // 3) map: isimden indise (ROS'taki joint_states mesajı isim listesiyle gelir)
    std::map<std::string, int> index;
    for (int i = 0; i < int(joints.size()); ++i) index[joints[i].name] = i;
    std::printf("sag_diz indisi = %d\n", index.at("sag_diz"));
    std::printf("clamp_to<int>(300, 0, 180) = %d\n", clamp_to(300, 0, 180));
    return 0;
}
