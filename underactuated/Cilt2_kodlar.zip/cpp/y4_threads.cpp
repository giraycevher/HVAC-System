// y4_threads.cpp — iş parçacıkları: veri yarışı, mutex, atomic, üretici-tüketici
#include <atomic>
#include <chrono>
#include <condition_variable>
#include <cstdio>
#include <mutex>
#include <queue>
#include <thread>
#include <vector>

int main() {
    const int N = 200000;
    // 1) Veri yarışı: iki iş parçacığı korumasız aynı sayaca yazıyor -> TANIMSIZ DAVRANIŞ
    long racy = 0;
    {
        auto f = [&] { for (int i = 0; i < N; ++i) { long t = racy; std::this_thread::yield(); racy = t + 1; if (i > 2000) break; } };
        std::thread t1(f), t2(f); t1.join(); t2.join();
    }
    std::printf("korumasız sayaç: %ld (beklenen %d) -> güncellemeler kayboldu\n", racy, 2 * 2002);

    // 2) mutex ile
    long safe = 0; std::mutex m;
    {
        auto f = [&] { for (int i = 0; i < N; ++i) { std::lock_guard<std::mutex> lk(m); ++safe; } };   // RAII kilit
        std::thread t1(f), t2(f); t1.join(); t2.join();
    }
    std::printf("mutex ile: %ld (beklenen %d)\n", safe, 2 * N);

    // 3) atomic ile (tek bir değişken için kilitsiz)
    std::atomic<long> at{0};
    {
        auto f = [&] { for (int i = 0; i < N; ++i) at.fetch_add(1, std::memory_order_relaxed); };
        std::thread t1(f), t2(f); t1.join(); t2.join();
    }
    std::printf("atomic ile: %ld\n", at.load());

    // 4) Üretici-tüketici: sensör iş parçacığı ölçüm üretir, kontrol iş parçacığı tüketir
    std::queue<int> q; std::mutex qm; std::condition_variable cv; bool done = false;
    std::thread producer([&] {
        for (int k = 0; k < 5; ++k) {
            std::this_thread::sleep_for(std::chrono::milliseconds(2));
            { std::lock_guard<std::mutex> lk(qm); q.push(100 + k); }
            cv.notify_one();
        }
        { std::lock_guard<std::mutex> lk(qm); done = true; }
        cv.notify_one();
    });
    std::vector<int> got;
    std::thread consumer([&] {
        std::unique_lock<std::mutex> lk(qm);
        while (true) {
            cv.wait(lk, [&] { return !q.empty() || done; });           // sahte uyanmalara karşı koşullu bekle
            while (!q.empty()) { got.push_back(q.front()); q.pop(); }
            if (done) break;
        }
    });
    producer.join(); consumer.join();
    std::printf("tüketici aldı:");
    for (int v : got) std::printf(" %d", v);
    std::printf("\n");
    return 0;
}
