// y5_rtloop.cpp — 1 kHz kontrol döngüsü: sleep_for (kayan) ve sleep_until (sabit tempolu) karşılaştırması
#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstdio>
#include <thread>
#include <vector>
using Clock = std::chrono::steady_clock;
using namespace std::chrono_literals;

volatile double sink = 0;
void control_work() { double s = 0; for (int i = 0; i < 20000; ++i) s += std::sin(i * 1e-3); sink = s; }  // ~"iş"

void report(const char* name, const std::vector<double>& per, double total_ms) {
    std::vector<double> d(per); std::sort(d.begin(), d.end());
    double mean = 0; for (double x : d) mean += x; mean /= d.size();
    std::printf("%-28s ort. periyot %.3f ms | p50 %.3f | p99 %.3f | max %.3f ms | 1000 döngü %.1f ms (ideal 1000)\n",
                name, mean, d[d.size() / 2], d[size_t(d.size() * 0.99)], d.back(), total_ms);
}

int main() {
    const int N = 1000;
    for (int mode = 0; mode < 2; ++mode) {
        std::vector<double> per; per.reserve(N);              // ölçüm vektörü önceden ayrılır: döngüde malloc yok
        auto t0 = Clock::now(), prev = t0, next = t0;
        for (int k = 0; k < N; ++k) {
            control_work();
            if (mode == 0) std::this_thread::sleep_for(1ms);   // iş süresi + 1 ms -> periyot kayar
            else { next += 1ms; std::this_thread::sleep_until(next); }   // mutlak zamana kadar bekle
            auto now = Clock::now();
            per.push_back(std::chrono::duration<double, std::milli>(now - prev).count()); prev = now;
        }
        double total = std::chrono::duration<double, std::milli>(Clock::now() - t0).count();
        report(mode == 0 ? "sleep_for(1ms)" : "sleep_until(t0 + k*1ms)", per, total);
    }
    auto a = Clock::now(); control_work(); auto b = Clock::now();
    std::printf("tek bir control_work() süresi: %.3f ms\n", std::chrono::duration<double, std::milli>(b - a).count());
    return 0;
}
