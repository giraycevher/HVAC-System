// p7_kf.cpp — boyutları derleme zamanında sabit, şablonlu (template) Kalman filtresi
// + bacaklı gövde hız kestirimi (IMU tahmini, bacak kinematiği ölçümü, Mahalanobis kapısı)
#include <Eigen/Dense>
#include <cmath>
#include <cstdio>
#include <random>

template <int NX, int NU, int NZ>
class KalmanFilter {
public:
    using VecX = Eigen::Matrix<double, NX, 1>;
    using VecU = Eigen::Matrix<double, NU, 1>;
    using VecZ = Eigen::Matrix<double, NZ, 1>;
    using MatX = Eigen::Matrix<double, NX, NX>;
    using MatXU = Eigen::Matrix<double, NX, NU>;
    using MatZX = Eigen::Matrix<double, NZ, NX>;
    using MatZ = Eigen::Matrix<double, NZ, NZ>;

    KalmanFilter(const MatX& F, const MatXU& G, const MatX& Q) : F_(F), G_(G), Q_(Q) {}
    void init(const VecX& x0, const MatX& P0) { x_ = x0; P_ = P0; }

    void predict(const VecU& u) { x_ = F_ * x_ + G_ * u; P_ = F_ * P_ * F_.transpose() + Q_; }

    // gate > 0 ise: Mahalanobis² > gate olan ölçümü reddet; kabul edildiyse true döner
    bool update(const VecZ& z, const MatZX& H, const MatZ& R, double gate = -1) {
        const VecZ inn = z - H * x_;
        const MatZ S = H * P_ * H.transpose() + R;
        const double d2 = inn.dot(S.ldlt().solve(inn));
        if (gate > 0 && d2 > gate) return false;
        const Eigen::Matrix<double, NX, NZ> K = P_ * H.transpose() * S.inverse();
        x_ += K * inn;
        const MatX IKH = MatX::Identity() - K * H;
        P_ = IKH * P_ * IKH.transpose() + K * R * K.transpose();   // Joseph biçimi: sayısal olarak simetrik ve pozitif kalır
        return true;
    }
    const VecX& x() const { return x_; }
    const MatX& P() const { return P_; }

private:
    MatX F_; MatXU G_; MatX Q_;
    VecX x_ = VecX::Zero(); MatX P_ = MatX::Identity();
};

int main() {
    const double dt = 0.0025, T = 20.0, b_true = 0.15; const int n = int(T / dt);
    std::mt19937 g(7); std::normal_distribution<double> na(0, 0.05), nv(0, 0.04);
    Eigen::Matrix3d F; F << 1, dt, -0.5 * dt * dt, 0, 1, -dt, 0, 0, 1;
    Eigen::Vector3d G(0.5 * dt * dt, dt, 0);
    Eigen::Matrix3d Q = Eigen::Vector3d(1e-8, std::pow(0.05 * dt, 2), std::pow(1e-3 * dt, 2)).asDiagonal();
    Eigen::RowVector3d H(0, 1, 0);
    Eigen::Matrix<double, 1, 1> R; R << 0.04 * 0.04;

    for (double gate : {-1.0, 9.0}) {
        KalmanFilter<3, 1, 1> kf(F, G, Q);
        kf.init(Eigen::Vector3d::Zero(), Eigen::Vector3d(1e-4, 1e-2, 0.1).asDiagonal());
        g.seed(7);
        double p = 0, se = 0, slip_err = 0; int rej = 0, nslip = 0;
        for (int k = 0; k < n; ++k) {
            const double t = k * dt, v = 0.3 + 0.08 * std::sin(2 * M_PI * 1.5 * t);
            const double a = 0.08 * 2 * M_PI * 1.5 * std::cos(2 * M_PI * 1.5 * t);
            p += v * dt;
            const bool slip = t > 8 && t < 9.5, contact = std::fmod(t, 1 / 1.5) >= 0.03;
            Eigen::Matrix<double, 1, 1> u; u << a + b_true + na(g);
            kf.predict(u);
            Eigen::Matrix<double, 1, 1> z; z << v + nv(g) + (slip ? 0.35 : 0.0);
            if (contact && !kf.update(z, H, R, gate)) ++rej;
            se += std::pow(kf.x()[1] - v, 2);
            if (slip) { slip_err += std::abs(kf.x()[1] - v); ++nslip; }
            if (k == n - 1)
                std::printf("%s: konum hatası %.3f m, hız RMS %.3f m/s, kayma sırasında hız hatası %.3f m/s, sapma %.4f, reddedilen %d\n",
                            gate > 0 ? "KF + 3σ kapı" : "KF (kapısız)", std::abs(kf.x()[0] - p), std::sqrt(se / n), slip_err / nslip, kf.x()[2], rej);
        }
    }
    return 0;
}
