// p6_posegraph.cpp — 2B poz grafiği, Gauss-Newton, SEYREK H ve Eigen::SimplicialLDLT
#include <Eigen/Dense>
#include <Eigen/Sparse>
#include <chrono>
#include <cmath>
#include <cstdio>
#include <random>
#include <vector>
using Vec3 = Eigen::Vector3d;
using Mat3 = Eigen::Matrix3d;

double wrap(double a) { return std::remainder(a, 2 * M_PI); }
Mat3 v2t(const Vec3& p) { Mat3 T; T << std::cos(p[2]), -std::sin(p[2]), p[0], std::sin(p[2]), std::cos(p[2]), p[1], 0, 0, 1; return T; }
Vec3 t2v(const Mat3& T) { return {T(0, 2), T(1, 2), std::atan2(T(1, 0), T(0, 0))}; }
Vec3 between(const Vec3& a, const Vec3& b) { return t2v(v2t(a).inverse() * v2t(b)); }

struct Edge { int i, j; Vec3 z; Mat3 Om; };

// hata e = Z^{-1} (Xi^{-1} Xj) ve Jacobianlar A = de/dxi, B = de/dxj
void err_jac(const Vec3& xi, const Vec3& xj, const Vec3& z, Vec3& e, Mat3& A, Mat3& B) {
    Eigen::Matrix2d Ri = v2t(xi).topLeftCorner<2, 2>(), Rz = v2t(z).topLeftCorner<2, 2>();
    Eigen::Vector2d dt = xj.head<2>() - xi.head<2>();
    e.head<2>() = Rz.transpose() * (Ri.transpose() * dt - z.head<2>());
    e[2] = wrap(xj[2] - xi[2] - z[2]);
    Eigen::Matrix2d dRiT; dRiT << -std::sin(xi[2]), std::cos(xi[2]), -std::cos(xi[2]), -std::sin(xi[2]);
    A.setZero(); B.setZero();
    A.topLeftCorner<2, 2>() = -Rz.transpose() * Ri.transpose(); A.block<2, 1>(0, 2) = Rz.transpose() * dRiT * dt; A(2, 2) = -1;
    B.topLeftCorner<2, 2>() = Rz.transpose() * Ri.transpose(); B(2, 2) = 1;
}

int main() {
    std::mt19937 g(6); std::normal_distribution<double> N01(0, 1);
    // gerçek yörünge: kare koridor, `laps` tur
    for (int laps : {3, 30}) {
        std::vector<Vec3> truth{Vec3::Zero()};
        for (int l = 0; l < laps; ++l) for (int s = 0; s < 4; ++s) for (int k = 0; k < 10; ++k)
            truth.push_back(t2v(v2t(truth.back()) * v2t(Vec3(0.4, 0, k < 9 ? 0 : M_PI / 2))));
        const int n = truth.size();
        const Vec3 so(0.02, 0.02, 1.5 * M_PI / 180), sl(0.05, 0.05, 2.0 * M_PI / 180);
        auto noisy = [&](const Vec3& v, const Vec3& s) { return Vec3(v[0] + s[0] * N01(g), v[1] + s[1] * N01(g), v[2] + s[2] * N01(g)); };
        std::vector<Edge> E;
        for (int i = 0; i + 1 < n; ++i) E.push_back({i, i + 1, noisy(between(truth[i], truth[i + 1]), so), so.cwiseAbs2().cwiseInverse().asDiagonal()});
        const int nodo = E.size();
        for (int i = 0; i < n; i += 5) for (int j = i + 40; j < n; j += 40)
            E.push_back({i, j, noisy(between(truth[i], truth[j]), sl), sl.cwiseAbs2().cwiseInverse().asDiagonal()});

        std::vector<Vec3> x{Vec3::Zero()};                       // ölü hesap başlangıcı
        for (int k = 0; k < nodo; ++k) x.push_back(t2v(v2t(x.back()) * v2t(E[k].z)));
        auto ate = [&]() { double s = 0; for (int i = 0; i < n; ++i) s += (x[i].head<2>() - truth[i].head<2>()).squaredNorm(); return std::sqrt(s / n); };
        const double ate0 = ate();

        auto t0 = std::chrono::steady_clock::now();
        int it = 0; double chi2 = 0;
        for (; it < 10; ++it) {
            std::vector<Eigen::Triplet<double>> trip; Eigen::VectorXd b = Eigen::VectorXd::Zero(3 * n);
            chi2 = 0;
            for (const Edge& ed : E) {
                Vec3 e; Mat3 A, B; err_jac(x[ed.i], x[ed.j], ed.z, e, A, B);
                chi2 += e.dot(ed.Om * e);
                const Mat3 blocks[4] = {A.transpose() * ed.Om * A, A.transpose() * ed.Om * B, B.transpose() * ed.Om * A, B.transpose() * ed.Om * B};
                const int rows[4] = {ed.i, ed.i, ed.j, ed.j}, cols[4] = {ed.i, ed.j, ed.i, ed.j};
                for (int q = 0; q < 4; ++q) for (int r = 0; r < 3; ++r) for (int c = 0; c < 3; ++c)
                    trip.emplace_back(3 * rows[q] + r, 3 * cols[q] + c, blocks[q](r, c));   // aynı (r,c) toplanır
                b.segment<3>(3 * ed.i) += A.transpose() * ed.Om * e; b.segment<3>(3 * ed.j) += B.transpose() * ed.Om * e;
            }
            for (int r = 0; r < 3; ++r) trip.emplace_back(r, r, 1e6);                     // ilk pozu sabitle
            Eigen::SparseMatrix<double> H(3 * n, 3 * n); H.setFromTriplets(trip.begin(), trip.end());
            Eigen::SimplicialLDLT<Eigen::SparseMatrix<double>> ldlt(H);
            Eigen::VectorXd dx = ldlt.solve(-b);
            for (int i = 0; i < n; ++i) { x[i] += dx.segment<3>(3 * i); x[i][2] = wrap(x[i][2]); }
            if (dx.cwiseAbs().maxCoeff() < 1e-6) { ++it; break; }
        }
        double ms = std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - t0).count();
        std::printf("%2d tur: %4d düğüm, %4zu kenar | ATE ölü hesap %.3f m -> GN %.3f m | %d iterasyon, son χ² %.1f (beklenen ~%zu) | %.1f ms\n",
                    laps, n, E.size(), ate0, ate(), it, chi2, 3 * E.size() - 3 * (n - 1), ms);
    }
    return 0;
}
