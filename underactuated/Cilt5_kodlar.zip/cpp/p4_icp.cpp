// p4_icp.cpp — Kabsch (SVD) ve nokta-nokta ICP, Eigen ile. 2B oda taraması.
#include <Eigen/Dense>
#include <cmath>
#include <cstdio>
#include <random>
#include <vector>
using Mat2 = Eigen::Matrix2d;
using Vec2 = Eigen::Vector2d;
using Cloud = Eigen::Matrix<double, Eigen::Dynamic, 2>;   // her satır bir nokta

struct Pose2 { Mat2 R = Mat2::Identity(); Vec2 t = Vec2::Zero(); };

Pose2 kabsch(const Cloud& P, const Cloud& Q) {
    const Eigen::RowVector2d cp = P.colwise().mean(), cq = Q.colwise().mean();
    const Mat2 H = (P.rowwise() - cp).transpose() * (Q.rowwise() - cq);
    Eigen::JacobiSVD<Mat2> svd(H, Eigen::ComputeFullU | Eigen::ComputeFullV);
    Mat2 D = Mat2::Identity();
    D(1, 1) = (svd.matrixV() * svd.matrixU().transpose()).determinant() < 0 ? -1.0 : 1.0;   // yansıma yok
    Pose2 T;
    T.R = svd.matrixV() * D * svd.matrixU().transpose();
    T.t = cq.transpose() - T.R * cp.transpose();
    return T;
}

Mat2 rot(double a) { Mat2 R; R << std::cos(a), -std::sin(a), std::sin(a), std::cos(a); return R; }

Cloud room(int n, std::mt19937& g) {
    std::uniform_real_distribution<double> U(0, 4), A(0, 2 * M_PI);
    Cloud C(n + n / 4, 2);
    for (int i = 0; i < n; ++i) {
        double s = U(g);
        if (s < 1)      C.row(i) << s * 4, 0;
        else if (s < 2) C.row(i) << 4, (s - 1) * 3;
        else if (s < 3) C.row(i) << (3 - s) * 4, 3;
        else            C.row(i) << 0, (4 - s) * 3;
    }
    for (int i = 0; i < n / 4; ++i) { double a = A(g); C.row(n + i) << 2.5 + 0.2 * std::cos(a), 1.2 + 0.2 * std::sin(a); }
    return C;
}

// ICP: her iterasyonda en yakın komşuyu bul, uzak eşleşmeleri at, Kabsch ile adımı çöz, birleştir
Pose2 icp(const Cloud& S, const Cloud& M, int& iters_used, double& rms, double reject = 0.5) {
    Pose2 T; double prev = 1e9;
    for (int it = 0; it < 40; ++it) {
        Cloud Sw = (S * T.R.transpose()).rowwise() + T.t.transpose();
        std::vector<int> src, dst; double sum = 0;
        for (int i = 0; i < Sw.rows(); ++i) {
            Eigen::Index j; double d2 = (M.rowwise() - Sw.row(i)).rowwise().squaredNorm().minCoeff(&j);
            if (d2 < reject * reject) { src.push_back(i); dst.push_back(int(j)); sum += d2; }
        }
        Cloud A(src.size(), 2), B(src.size(), 2);
        for (size_t k = 0; k < src.size(); ++k) { A.row(k) = Sw.row(src[k]); B.row(k) = M.row(dst[k]); }
        Pose2 d = kabsch(A, B);
        T.R = d.R * T.R; T.t = d.R * T.t + d.t;
        rms = std::sqrt(sum / src.size()); iters_used = it + 1;
        if (std::abs(prev - rms) < 1e-6) break;
        prev = rms;
    }
    return T;
}

int main() {
    Cloud P3(3, 2); P3 << 0, 0, 1, 0, 0, 1;
    Cloud Q3 = (P3 * rot(M_PI / 2).transpose()).rowwise() + Eigen::RowVector2d(1, 2);
    Pose2 T3 = kabsch(P3, Q3);
    std::printf("Kabsch 3 nokta: açı = %.4f°, t = (%.4f, %.4f)\n", std::atan2(T3.R(1, 0), T3.R(0, 0)) * 180 / M_PI, T3.t(0), T3.t(1));

    std::mt19937 g(4); std::normal_distribution<double> N(0, 0.01);
    Cloud M = room(400, g);
    const double ang = 0.15; const Vec2 tt(0.30, -0.20);
    for (double da : {0.0, 0.6, 1.0}) {
        Cloud S(M.rows() / 2, 2);
        for (int i = 0; i < S.rows(); ++i) S.row(i) = (rot(ang + da).transpose() * (M.row(2 * i).transpose() - tt)).transpose() + Eigen::RowVector2d(N(g), N(g));
        int it; double rms;
        Pose2 T = icp(S, M, it, rms, 1.0);
        double a = std::atan2(T.R(1, 0), T.R(0, 0));
        std::printf("gerçek dönme %5.1f°: ICP %2d iterasyon, açı %7.3f°, t = (%.4f, %.4f), RMS %.4f m\n",
                    (ang + da) * 180 / M_PI, it, a * 180 / M_PI, T.t(0), T.t(1), rms);
    }
    return 0;
}
