import numpy as np
rng = np.random.default_rng(1)

# İğne deliği (pinhole) kamera: x_piksel ~ K [R | t] X_dünya
# SB-1'in başına takılı ucuz bir 640x480 kamera düşünelim.
fx, fy, cx, cy = 500.0, 500.0, 320.0, 240.0
K = np.array([[fx, 0, cx], [0, fy, cy], [0, 0, 1.0]])

def rotz(a):
    c, s = np.cos(a), np.sin(a); return np.array([[c, -s, 0], [s, c, 0], [0, 0, 1]])
def rotx(a):
    c, s = np.cos(a), np.sin(a); return np.array([[1, 0, 0], [0, c, -s], [0, s, c]])

def project(K, R, t, X, k1=0.0):
    """X: (N,3) dünya noktaları -> (N,2) piksel. k1: radyal bozulma katsayısı."""
    Xc = X @ R.T + t                       # kamera çerçevesi
    xn = Xc[:, :2] / Xc[:, 2:3]            # normalize görüntü düzlemi (z=1)
    r2 = (xn**2).sum(1, keepdims=True)
    xd = xn * (1 + k1 * r2)                # basit radyal bozulma
    return xd @ K[:2, :2].T + K[:2, 2]

# 1) Tek nokta, elle kontrol edilebilir
R0, t0 = np.eye(3), np.zeros(3)
print("nokta (0.2, -0.1, 2.0) m ->", project(K, R0, t0, np.array([[0.2, -0.1, 2.0]]))[0], "piksel")
print("aynı nokta, k1=-0.2 bozulma ->", project(K, R0, t0, np.array([[0.2, -0.1, 2.0]]), k1=-0.2)[0].round(2), "(merkeze yakın: etki küçük)")
print("köşe noktası (0.5, 0.4, 2.0): bozulmasız", project(K, R0, t0, np.array([[0.5, 0.4, 2.0]]))[0].round(2),
      " k1=-0.2:", project(K, R0, t0, np.array([[0.5, 0.4, 2.0]]), k1=-0.2)[0].round(2))
print("1 piksel, 2 m'de kaç mm? ", 2.0 / fx * 1000, "mm")

# 2) DLT ile kamera kalibrasyonu (P = K[R|t], 3x4) : bilinen 3B noktalar + gözlenen pikseller
Rt = rotx(-0.3) @ rotz(0.2); tt = np.array([0.1, -0.05, 1.5])
Xw = np.c_[rng.uniform(-0.5, 0.5, 30), rng.uniform(-0.5, 0.5, 30), rng.uniform(0.0, 0.6, 30)]
uv = project(K, Rt, tt, Xw) + rng.normal(0, 0.5, (30, 2))   # 0.5 piksel gürültü

def dlt_P(X, uv):
    A = []
    for (x, y, z), (u, v) in zip(X, uv):
        Xh = [x, y, z, 1]
        A.append([*Xh, 0, 0, 0, 0, *(-u * np.array(Xh))])
        A.append([0, 0, 0, 0, *Xh, *(-v * np.array(Xh))])
    _, _, Vt = np.linalg.svd(np.array(A))
    return Vt[-1].reshape(3, 4)            # en küçük tekil değere ait vektör

def rq3(M):
    """M = K R (K üst üçgen, R dönme) ayrışımı."""
    P = np.flipud(np.eye(3))
    Q, Rm = np.linalg.qr((P @ M).T)
    Kh = P @ Rm.T @ P; Rh = P @ Q.T
    S = np.diag(np.sign(np.diag(Kh))); Kh = Kh @ S; Rh = S @ Rh
    return Kh / Kh[2, 2], Rh

P = dlt_P(Xw, uv)
Kest, Rest = rq3(P[:, :3])
if np.linalg.det(Rest) < 0: Rest = -Rest; P = -P
test = np.c_[Xw, np.ones(30)] @ P.T; test = test[:, :2] / test[:, 2:]
print("DLT ile tahmin edilen K:\n", Kest.round(1))
print("dönme hatası (derece):", np.degrees(np.arccos(np.clip((np.trace(Rest.T @ Rt) - 1) / 2, -1, 1))).round(3))
print("yeniden izdüşüm hatası RMS:", np.sqrt(((test - uv)**2).sum(1).mean()).round(3), "piksel")

# 3) Gürültü arttıkça K tahmini nasıl bozuluyor?
for s in [0.1, 0.5, 2.0, 5.0]:
    errs = []
    for k in range(50):
        uvn = project(K, Rt, tt, Xw) + rng.normal(0, s, (30, 2))
        Ke, _ = rq3(dlt_P(Xw, uvn)[:, :3]); errs.append(abs(Ke[0, 0] - fx))
    print(f"gürültü σ={s:3.1f} px -> |fx hata| ortalama {np.mean(errs):6.2f} px")

# %% plot
from figstyle import plt, save
fig, ax = plt.subplots(1, 2, figsize=(6.4, 3.0))
g = np.linspace(-1, 1, 11)
for k1, col, lab in [(0.0, "#0B6E99", "bozulmasız"), (-0.25, "#D1495B", "k1=-0.25 (fıçı)")]:
    for v in g:
        L = np.c_[np.full(50, v), np.linspace(-1, 1, 50), np.full(50, 2.0)]
        L[:, :2] *= 0.9
        p = project(K, R0, t0, L, k1); ax[0].plot(p[:, 0], p[:, 1], color=col, lw=0.7)
        p = project(K, R0, t0, L[:, [1, 0, 2]], k1); ax[0].plot(p[:, 0], p[:, 1], color=col, lw=0.7, label=lab if v == g[0] else None)
ax[0].set_xlim(0, 640); ax[0].set_ylim(480, 0); ax[0].set_aspect("equal"); ax[0].legend(fontsize=7, loc="lower right"); ax[0].set_title("ızgara görüntüsü")
ax[1].scatter(uv[:, 0], uv[:, 1], s=10, label="ölçülen"); ax[1].scatter(test[:, 0], test[:, 1], s=20, facecolors="none", edgecolors="#D1495B", label="DLT izdüşümü")
ax[1].set_xlim(0, 640); ax[1].set_ylim(480, 0); ax[1].set_aspect("equal"); ax[1].legend(fontsize=7); ax[1].set_title("kalibrasyon")
save("p1_camera")
