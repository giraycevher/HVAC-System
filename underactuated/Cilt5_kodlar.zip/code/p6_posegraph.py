import numpy as np
rng = np.random.default_rng(6)

# 2B poz grafiği: düğüm = robot pozu (x, y, θ); kenar = iki poz arasında ölçülen göreli hareket.
# Odometri kenarları ardışık pozları bağlar; döngü kapatma kenarları "burayı daha önce gördüm" der.
def wrap(a): return (a + np.pi) % (2 * np.pi) - np.pi
def v2t(p):
    c, s = np.cos(p[2]), np.sin(p[2]); return np.array([[c, -s, p[0]], [s, c, p[1]], [0, 0, 1]])
def t2v(T): return np.array([T[0, 2], T[1, 2], np.arctan2(T[1, 0], T[0, 0])])
def between(a, b): return t2v(np.linalg.inv(v2t(a)) @ v2t(b))      # a'dan bakınca b

# Gerçek yörünge: 3 tur kare koridor (4 m x 4 m), her kenar 10 adım
truth = [np.zeros(3)]
for lap in range(3):
    for side in range(4):
        for k in range(10):
            p = truth[-1]; step = np.array([0.4, 0, 0]) if k < 9 else np.array([0.4, 0, np.pi / 2])
            truth.append(t2v(v2t(p) @ v2t(step)))
truth = np.array(truth); N = len(truth)

sig_o = np.array([0.02, 0.02, np.radians(1.5)])        # odometri kenarı gürültüsü
sig_l = np.array([0.05, 0.05, np.radians(2.0)])        # döngü kapatma (ör. tarama eşleştirme) gürültüsü
edges = []
for i in range(N - 1):
    edges.append((i, i + 1, between(truth[i], truth[i + 1]) + rng.normal(0, sig_o), np.diag(1 / sig_o**2)))
odo_edges = len(edges)
for i in range(N):                                     # aynı köşeye 40 adım sonra geri gelindi -> döngü kenarı
    for j in range(i + 40, N, 40):
        if i % 5 == 0: edges.append((i, j, between(truth[i], truth[j]) + rng.normal(0, sig_l), np.diag(1 / sig_l**2)))
print("düğüm:", N, " odometri kenarı:", odo_edges, " döngü kapatma kenarı:", len(edges) - odo_edges)

# Başlangıç tahmini: odometriyi uç uca ekle (ölü hesap)
x0 = [np.zeros(3)]
for (i, j, z, _) in edges[:odo_edges]: x0.append(t2v(v2t(x0[-1]) @ v2t(z)))
x0 = np.array(x0)

def error_and_jac(xi, xj, z):
    Ri = v2t(xi)[:2, :2]; dt = xj[:2] - xi[:2]
    e = np.r_[Ri.T @ dt - z[:2], wrap(xj[2] - xi[2] - z[2])]
    # z'nin kendi dönmesini de hesaba katmak için hatayı z çerçevesine al
    Rz = v2t(z)[:2, :2]; e[:2] = Rz.T @ e[:2]
    dRiT = np.array([[-np.sin(xi[2]), np.cos(xi[2])], [-np.cos(xi[2]), -np.sin(xi[2])]])
    A = np.zeros((3, 3)); B = np.zeros((3, 3))
    A[:2, :2] = -Rz.T @ Ri.T; A[:2, 2] = Rz.T @ dRiT @ dt; A[2, 2] = -1
    B[:2, :2] = Rz.T @ Ri.T; B[2, 2] = 1
    return e, A, B

def chi2(x): return sum(e @ Om @ e for (i, j, z, Om) in edges for e in [error_and_jac(x[i], x[j], z)[0]])

def gauss_newton(x, iters=10):
    x = x.copy(); hist = [chi2(x)]
    for it in range(iters):
        H = np.zeros((3 * N, 3 * N)); b = np.zeros(3 * N)
        for (i, j, z, Om) in edges:
            e, A, B = error_and_jac(x[i], x[j], z)
            si, sj = slice(3 * i, 3 * i + 3), slice(3 * j, 3 * j + 3)
            H[si, si] += A.T @ Om @ A; H[si, sj] += A.T @ Om @ B
            H[sj, si] += B.T @ Om @ A; H[sj, sj] += B.T @ Om @ B
            b[si] += A.T @ Om @ e; b[sj] += B.T @ Om @ e
        H[:3, :3] += np.eye(3) * 1e6                    # ilk pozu sabitle (gauge özgürlüğü)
        dx = np.linalg.solve(H, -b)
        x += dx.reshape(-1, 3); x[:, 2] = wrap(x[:, 2])
        hist.append(chi2(x))
        if np.abs(dx).max() < 1e-6: break
    return x, hist, H

def ate(x): return np.sqrt((np.linalg.norm(x[:, :2] - truth[:, :2], axis=1)**2).mean())
x, hist, H = gauss_newton(x0)
print("χ² iterasyonlarla:", [f"{h:.1f}" for h in hist])
print(f"beklenen χ² ≈ ölçüm - bilinmeyen = {3 * len(edges)} - {3 * (N - 1)} = {3 * len(edges) - 3 * (N - 1)} (gürültü modeli doğruysa)")
print(f"yörünge hatası (ATE RMS): ölü hesap {ate(x0):.3f} m  ->  optimize {ate(x):.3f} m")
print(f"son poz hatası: ölü hesap {np.linalg.norm(x0[-1, :2] - truth[-1, :2]):.3f} m -> {np.linalg.norm(x[-1, :2] - truth[-1, :2]):.3f} m")
print(f"H matrisi {H.shape[0]}x{H.shape[1]}, sıfır olmayan oranı {np.count_nonzero(H) / H.size * 100:.1f}%  (seyreklik: büyük grafiklerde seyrek Cholesky)")

# %% plot
from figstyle import plt, save
fig, ax = plt.subplots(1, 2, figsize=(6.4, 3.0))
ax[0].plot(truth[:, 0], truth[:, 1], "k-", lw=1, label="gerçek"); ax[0].plot(x0[:, 0], x0[:, 1], "--", label="ölü hesap")
ax[0].plot(x[:, 0], x[:, 1], label="GN sonrası"); ax[0].set_aspect("equal"); ax[0].legend(fontsize=7)
ax[1].spy(np.abs(H) > 1e-9, markersize=0.6); ax[1].set_title("H seyreklik deseni", fontsize=9)
save("p6_posegraph")
