import numpy as np
rng = np.random.default_rng(3)

# İki görüntüden 3B: robot 20 cm yürüyüp biraz dönüyor; aynı noktaları iki karede görüyor.
K = np.array([[500, 0, 320], [0, 500, 240], [0, 0, 1.0]]); Ki = np.linalg.inv(K)
def roty(a):
    c, s = np.cos(a), np.sin(a); return np.array([[c, 0, s], [0, 1, 0], [-s, 0, c]])
def skew(v): return np.array([[0, -v[2], v[1]], [v[2], 0, -v[0]], [-v[1], v[0], 0]])

R = roty(0.1); t = np.array([-0.2, 0.0, 0.02])        # kamera 2 = R X1 + t
X = np.c_[rng.uniform(-1, 1, 40), rng.uniform(-0.6, 0.6, 40), rng.uniform(2, 5, 40)]
def proj(Xc): x = Xc @ K.T; return x[:, :2] / x[:, 2:]
u1 = proj(X) + rng.normal(0, 0.5, (40, 2)); u2 = proj(X @ R.T + t) + rng.normal(0, 0.5, (40, 2))
n1 = np.c_[u1, np.ones(40)] @ Ki.T; n2 = np.c_[u2, np.ones(40)] @ Ki.T   # normalize koordinatlar

E_true = skew(t) @ R
a0 = X[0] / X[0, 2]; X2 = R @ X[0] + t; b0 = X2 / X2[2]       # gürültüsüz normalize koordinatlar
print("epipolar kısıt  x2ᵀ E x1 (gürültüsüz) =", f"{b0 @ E_true @ a0:.1e}", "  (gürültülü ort. |.|:",
      f"{np.abs(np.einsum('ij,jk,ik->i', n2, E_true, n1)).mean():.1e})")

def eight_point(a, b):
    A = np.array([np.kron(bi, ai) for ai, bi in zip(a, b)])  # b^T E a = 0 -> vec(E) satırı
    _, _, Vt = np.linalg.svd(A); E = Vt[-1].reshape(3, 3)
    U, S, Vt = np.linalg.svd(E)                              # E'nin iki eşit, bir sıfır tekil değeri olmalı
    return U @ np.diag([1, 1, 0]) @ Vt

def hartley(p):
    c = p[:, :2].mean(0); d = np.sqrt(((p[:, :2] - c)**2).sum(1)).mean(); s = np.sqrt(2) / d
    T = np.array([[s, 0, -s * c[0]], [0, s, -s * c[1]], [0, 0, 1]]); return p @ T.T, T
def eight_point_norm(a, b):
    an, T1 = hartley(a); bn, T2 = hartley(b)
    E = T2.T @ eight_point(an, bn) @ T1                      # normalize uzayda çöz, geri dönüştür
    U, _, Vt = np.linalg.svd(E); return U @ np.diag([1, 1, 0]) @ Vt

def triangulate(P1, P2, a, b):
    A = np.array([a[0] * P1[2] - P1[0], a[1] * P1[2] - P1[1], b[0] * P2[2] - P2[0], b[1] * P2[2] - P2[1]])
    _, _, Vt = np.linalg.svd(A); Xh = Vt[-1]; return Xh[:3] / Xh[3]

def decompose(E, a, b):
    U, _, Vt = np.linalg.svd(E)
    if np.linalg.det(U) < 0: U = -U
    if np.linalg.det(Vt) < 0: Vt = -Vt
    W = np.array([[0, -1, 0], [1, 0, 0], [0, 0, 1]])
    best = None
    for Rc in [U @ W @ Vt, U @ W.T @ Vt]:
        for tc in [U[:, 2], -U[:, 2]]:
            P1 = np.c_[np.eye(3), np.zeros(3)]; P2 = np.c_[Rc, tc]
            Xs = np.array([triangulate(P1, P2, ai, bi) for ai, bi in zip(a, b)])
            front = ((Xs[:, 2] > 0) & ((Xs @ Rc.T + tc)[:, 2] > 0)).sum()   # iki kameranın da önünde mi?
            if best is None or front > best[0]: best = (front, Rc, tc, Xs)
    return best

print("öteleme yönü hatası (30 deneme medyanı, derece):")
for sig in [0.1, 0.5, 1.0]:
    res = []
    for f in (eight_point, eight_point_norm):
        es = []
        for k in range(30):
            a = np.c_[proj(X) + rng.normal(0, sig, (40, 2)), np.ones(40)] @ Ki.T
            b = np.c_[proj(X @ R.T + t) + rng.normal(0, sig, (40, 2)), np.ones(40)] @ Ki.T
            _, _, tc, _ = decompose(f(a, b), a, b); es.append(np.degrees(np.arccos(abs(tc @ t) / np.linalg.norm(t))))
        res.append(np.median(es))
    print(f"  gürültü {sig:.1f} px:  ham 8-nokta {res[0]:6.2f}°   Hartley normalizasyonlu {res[1]:6.2f}°")

E = eight_point_norm(n1, n2)
front, Re, te, Xs = decompose(E, n1, n2)
ang = np.degrees(np.arccos(np.clip((np.trace(Re.T @ R) - 1) / 2, -1, 1)))
print("4 adaydan seçilen: iki kameranın önünde kalan nokta sayısı", front, "/ 40")
print(f"dönme hatası {ang:.3f}°;  öteleme yönü hatası {np.degrees(np.arccos(abs(te @ t) / np.linalg.norm(t))):.3f}°")
print("|t| tahmini:", np.linalg.norm(te).round(3), " (gerçek 0.201) -> tek kamerayla ölçek BİLİNEMEZ")
scale = np.linalg.norm(t) / np.linalg.norm(te)   # ölçeği dışarıdan (ör. bacak odometrisi) aldığımızı varsayalım
print("ölçek bacak odometrisinden alınınca 3B nokta hatası (medyan):",
      np.median(np.linalg.norm(Xs * scale - X, axis=1)).round(3), "m")
d = X[:, 2]; err = np.linalg.norm(Xs * scale - X, axis=1)
for lo, hi in [(2, 3), (3, 4), (4, 5)]:
    m = (d >= lo) & (d < hi); print(f"  derinlik {lo}-{hi} m: medyan hata {np.median(err[m]):.3f} m")
P1 = np.c_[np.eye(3), np.zeros(3)]; P2 = np.c_[R, t]                  # poz BİLİNSEYDİ (kalibre stereo gibi)
Xk = np.array([triangulate(P1, P2, ai, bi) for ai, bi in zip(n1, n2)]); ek = np.abs(Xk[:, 2] - X[:, 2])
m = (d >= 3.5) & (d < 4.5)
print("poz biliniyorsa, derinlik 3.5-4.5 m'de derinlik hatası RMS:", np.sqrt((ek[m]**2).mean()).round(3), "m")
print("derinlik belirsizliği formülü  σ_z ≈ z² σ_px / (f b):  z=4 m, b=0.2 m, σ=0.5 px ->", round(16 * 0.5 / (500 * 0.2), 3), "m")

# %% plot
from figstyle import plt, save
fig, ax = plt.subplots(figsize=(6.4, 3.0))
ax.scatter(X[:, 0], X[:, 2], s=12, label="gerçek")
ax.scatter(Xs[:, 0] * scale, Xs[:, 2] * scale, s=24, facecolors="none", edgecolors="#D1495B", label="üçgenlenmiş")
ax.plot([0, -(R.T @ t)[0]], [0, -(R.T @ t)[2]], "k-", marker="s", ms=4, label="kamera 1 → 2")
ax.set_xlabel("x [m]"); ax.set_ylabel("z (derinlik) [m]"); ax.set_aspect("equal"); ax.legend(fontsize=7); ax.set_title("üstten görünüş")
save("p3_epipolar")
