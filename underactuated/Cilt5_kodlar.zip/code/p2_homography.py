import numpy as np
rng = np.random.default_rng(2)

# Homografi: düzlemsel bir sahnenin (zemin, duvar, AprilTag) iki görüntüsü arasında x' ~ H x  (3x3, 8 serbestlik)
def normalize(p):
    """Hartley normalizasyonu: merkezi 0'a, ortalama uzaklığı sqrt(2)'ye taşı."""
    c = p.mean(0); d = np.sqrt(((p - c)**2).sum(1)).mean()
    s = np.sqrt(2) / d
    T = np.array([[s, 0, -s * c[0]], [0, s, -s * c[1]], [0, 0, 1]])
    return (np.c_[p, np.ones(len(p))] @ T.T)[:, :2], T

def dlt_H(p, q, norm=True):
    if norm:
        pn, T1 = normalize(p); qn, T2 = normalize(q)
    else:
        pn, qn, T1, T2 = p, q, np.eye(3), np.eye(3)
    A = []
    for (x, y), (u, v) in zip(pn, qn):
        A.append([-x, -y, -1, 0, 0, 0, u * x, u * y, u])
        A.append([0, 0, 0, -x, -y, -1, v * x, v * y, v])
    _, _, Vt = np.linalg.svd(np.array(A))
    Hn = Vt[-1].reshape(3, 3)
    H = np.linalg.inv(T2) @ Hn @ T1
    return H / H[2, 2]

def apply(H, p):
    q = np.c_[p, np.ones(len(p))] @ H.T
    return q[:, :2] / q[:, 2:]

H_true = np.array([[1.10, 0.05, 30.0], [-0.08, 0.95, 12.0], [2e-4, -1e-4, 1.0]])

# 1) En az 4 nokta: tam çözüm
p4 = np.array([[100, 100], [500, 120], [480, 400], [120, 380.0]])
H4 = dlt_H(p4, apply(H_true, p4))
print("4 noktadan H (gerçekle fark, en büyük):", np.abs(H4 - H_true).max().round(8))

# 2) Normalizasyonun önemi: 50 nokta, 1 piksel gürültü
p = rng.uniform([0, 0], [640, 480], (50, 2)); q = apply(H_true, p) + rng.normal(0, 1.0, (50, 2))
pt = rng.uniform([0, 0], [640, 480], (200, 2))
for nm in [False, True]:
    H = dlt_H(p, q, nm)
    e = np.sqrt(((apply(H, pt) - apply(H_true, pt))**2).sum(1)).mean()
    print(f"normalizasyon={'evet' if nm else 'hayır'}: test noktalarında ortalama hata {e:.3f} px")

# 3) RANSAC: eşleşmelerin %40'ı yanlış (özellik eşleştirmede olağan)
N = 100; out = int(0.4 * N)
p = rng.uniform([0, 0], [640, 480], (N, 2)); q = apply(H_true, p) + rng.normal(0, 1.0, (N, 2))
q[:out] = rng.uniform([0, 0], [640, 480], (out, 2))        # aykırı (outlier) eşleşmeler
H_naive = dlt_H(p, q)
def ransac_H(p, q, thr=3.0, iters=200):
    best = np.zeros(len(p), bool)
    for _ in range(iters):
        idx = rng.choice(len(p), 4, replace=False)
        try: H = dlt_H(p[idx], q[idx])
        except np.linalg.LinAlgError: continue
        inl = np.sqrt(((apply(H, p) - q)**2).sum(1)) < thr
        if inl.sum() > best.sum(): best = inl
    H = dlt_H(p[best], q[best])                            # tüm iç noktalarla yeniden kestir
    inl = np.sqrt(((apply(H, p) - q)**2).sum(1)) < thr      # iç noktaları bu daha iyi H ile yeniden seç
    return dlt_H(p[inl], q[inl]), inl
H_r, inl = ransac_H(p, q)
for nm, H in [("hepsiyle DLT", H_naive), ("RANSAC", H_r)]:
    e = np.sqrt(((apply(H, pt) - apply(H_true, pt))**2).sum(1)).mean()
    print(f"{nm:13s}: ortalama hata {e:9.3f} px")
print("RANSAC iç nokta sayısı:", inl.sum(), "/", N, " gerçek iç noktalardan bulunan:", inl[out:].sum(), "/", N - out)

# Kaç iterasyon gerekir? w = iç oran, s = örnek boyutu, p = başarı olasılığı
for w in [0.9, 0.6, 0.3]:
    for s in [4, 8]:
        k = np.log(1 - 0.99) / np.log(1 - w**s)
        print(f"iç oran {w:.1f}, örnek {s}: %99 için {int(np.ceil(k)):6d} iterasyon")

# %% plot
from figstyle import plt, save
fig, ax = plt.subplots(figsize=(6.4, 3.0))
ax.scatter(q[inl, 0], q[inl, 1], s=8, label="iç (inlier)"); ax.scatter(q[~inl, 0], q[~inl, 1], s=8, marker="x", label="aykırı")
sq = np.array([[50, 50], [590, 50], [590, 430], [50, 430], [50, 50.0]])
for H, lab, ls in [(H_true, "gerçek H", "-"), (H_naive, "hepsiyle DLT", "--"), (H_r, "RANSAC", ":")]:
    w = apply(H, sq); ax.plot(w[:, 0], w[:, 1], ls, label=lab)
ax.set_xlim(-60, 760); ax.set_ylim(560, -40); ax.set_aspect("equal"); ax.legend(fontsize=7, loc="upper left", bbox_to_anchor=(1, 1)); ax.set_title("görüntü çerçevesinin H ile dönüşümü")
save("p2_homography")
