import numpy as np
rng = np.random.default_rng(4)

# Kabsch: eşleşmesi BİLİNEN iki nokta kümesi arasındaki en iyi R, t (SVD ile kapalı form)
def kabsch(P, Q):
    """Q ≈ R P + t en küçük kareler. P, Q: (N, d)."""
    cp, cq = P.mean(0), Q.mean(0)
    Hm = (P - cp).T @ (Q - cq)
    U, _, Vt = np.linalg.svd(Hm)
    D = np.eye(P.shape[1]); D[-1, -1] = np.sign(np.linalg.det(Vt.T @ U.T))   # yansımayı engelle
    R = Vt.T @ D @ U.T
    return R, cq - R @ cp

def rot2(a): c, s = np.cos(a), np.sin(a); return np.array([[c, -s], [s, c]])

# Elle kontrol: 3 nokta, 90° dönme + (1, 2) öteleme
P3 = np.array([[0, 0], [1, 0], [0, 1.0]]); Q3 = P3 @ rot2(np.pi / 2).T + [1, 2]
R3, t3 = kabsch(P3, Q3)
print("Kabsch 3 nokta: açı =", np.degrees(np.arctan2(R3[1, 0], R3[0, 0])).round(6), "°, t =", t3.round(6))

# ICP: eşleşme BİLİNMİYOR. Bir oda taraması (lidar/derinlik kamerasından 2B kesit)
def room(n):
    s = rng.uniform(0, 4, n); pts = []
    for si in s:                                     # 4x3 m dikdörtgen oda + bir kolon
        if si < 1:   pts.append([si * 4, 0])
        elif si < 2: pts.append([4, (si - 1) * 3])
        elif si < 3: pts.append([(3 - si) * 4, 3])
        else:        pts.append([0, (4 - si) * 3])
    pts = np.array(pts)
    a = rng.uniform(0, 2 * np.pi, n // 4); col = np.c_[2.5 + 0.2 * np.cos(a), 1.2 + 0.2 * np.sin(a)]
    return np.r_[pts, col]

M = room(400)                                         # harita (referans tarama)
ang_true, t_true = 0.15, np.array([0.30, -0.20])     # robot hareket etti
S = (M[::2] - t_true) @ rot2(ang_true) + rng.normal(0, 0.01, (len(M[::2]), 2))   # yeni tarama, robot çerçevesinde

def icp(S, M, R=np.eye(2), t=np.zeros(2), iters=40, reject=0.5):
    hist = []
    for k in range(iters):
        Sw = S @ R.T + t
        d2 = ((Sw[:, None, :] - M[None, :, :])**2).sum(2)      # kaba kuvvet en yakın komşu (k-d ağacı daha hızlı)
        j = d2.argmin(1); dist = np.sqrt(d2[np.arange(len(S)), j])
        ok = dist < reject                                     # uzak eşleşmeleri at
        dR, dt = kabsch(Sw[ok], M[j[ok]])
        R, t = dR @ R, dR @ t + dt
        hist.append(np.sqrt((dist[ok]**2).mean()))
        if k > 2 and abs(hist[-2] - hist[-1]) < 1e-6: break
    return R, t, hist

R, t, hist = icp(S, M)
a = np.arctan2(R[1, 0], R[0, 0])
print(f"ICP: {len(hist)} iterasyon, açı {np.degrees(a):.3f}° (gerçek {np.degrees(ang_true):.3f}°), t = {t.round(4)} (gerçek {t_true})")
print("RMS eşleşme mesafesi: ilk", hist[0].round(4), "son", hist[-1].round(4), "m")

print("başlangıç tahmini kötüleşince (gerçek açı 0.15 rad'ın üzerine eklenen hata):")
for da in [0.0, 0.3, 0.6, 1.0, 1.5]:
    St = (M[::2] - t_true) @ rot2(ang_true + da) + rng.normal(0, 0.01, (len(M[::2]), 2))
    R, t, h = icp(St, M, reject=1.0)
    err = np.degrees(abs(np.arctan2(R[1, 0], R[0, 0]) - ang_true - da))
    print(f"  {np.degrees(ang_true + da):5.1f}° dönme: bulunan açının hatası {err:7.2f}°  -> {'YAKINSADI' if err < 1 else 'yerel minimum'}")

# %% plot
from figstyle import plt, save
R, t, hist = icp(S, M)
fig, ax = plt.subplots(1, 2, figsize=(6.4, 2.8))
ax[0].scatter(M[:, 0], M[:, 1], s=2, label="harita"); ax[0].scatter(S[:, 0], S[:, 1], s=2, label="yeni tarama (ham)")
Sw = S @ R.T + t; ax[0].scatter(Sw[:, 0], Sw[:, 1], s=2, label="ICP sonrası"); ax[0].set_aspect("equal"); ax[0].legend(fontsize=7, markerscale=4)
ax[1].semilogy(hist, "o-", ms=3); ax[1].set_xlabel("iterasyon"); ax[1].set_ylabel("RMS mesafe [m]")
save("p4_icp")
