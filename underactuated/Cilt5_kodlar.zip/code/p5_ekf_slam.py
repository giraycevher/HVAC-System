import numpy as np
rng = np.random.default_rng(5)

# 2B EKF-SLAM: durum = [x, y, θ, l1x, l1y, ..., lnx, lny]. Ölçüm: işaretlere uzaklık + yön (range-bearing).
# İşaret eşleştirmesi biliniyor (AprilTag gibi kimlikli işaretler).
# Yörünge (0, 3) merkezli ~3 m yarıçaplı bir daire. İşaretler dairenin sadece bir yarısında: öbür yarıda robot "kör".
ang = np.radians([-90, -60, -30, 0, 30, 60, 90, -75]); rad = np.array([2.2, 3.8, 2.2, 3.8, 2.2, 3.8, 2.2, 3.9])
L = np.c_[rad * np.cos(ang), 3 + rad * np.sin(ang)]
nL = len(L); dt = 0.1
sig_v, sig_w = 0.05, 0.08           # odometri gürültüsü (hız m/s, açısal hız rad/s; her adım)
sig_r, sig_b = 0.05, np.radians(2)  # ölçüm gürültüsü
R_max = 1.6                         # sensör menzili

def wrap(a): return (a + np.pi) % (2 * np.pi) - np.pi
def motion(x, v, w):
    return np.array([x[0] + v * dt * np.cos(x[2]), x[1] + v * dt * np.sin(x[2]), wrap(x[2] + w * dt)])

# Gerçek yörünge: yaklaşık bir daire, sonra ilk bölgeye geri dönüş (döngü kapatma)
T = 620; u = [(0.35, 0.115)] * T
xt = np.array([0.0, 0.0, 0.0]); truth = [xt]
for v, w in u: xt = motion(xt, v, w); truth.append(xt)
truth = np.array(truth)

n = 3 + 2 * nL
mu = np.zeros(n); P = np.zeros((n, n)); P[3:, 3:] = np.eye(2 * nL) * 1e6   # işaretler başta "bilinmiyor"
seen = np.zeros(nL, bool)
Q = np.diag([sig_v**2, sig_w**2]); Rm = np.diag([sig_r**2, sig_b**2])
dr = np.zeros(3); dr_hist = [dr.copy()]; mu_hist = [mu[:3].copy()]; Pxx = [0.0]; land_unc = []

for k, (v, w) in enumerate(u):
    vn, wn = v + rng.normal(0, sig_v), w + rng.normal(0, sig_w)        # ölçülen odometri
    dr = motion(dr, vn, wn); dr_hist.append(dr.copy())
    # --- tahmin (predict): sadece robot durumu hareket eder
    th = mu[2]
    Fx = np.array([[1, 0, -vn * dt * np.sin(th)], [0, 1, vn * dt * np.cos(th)], [0, 0, 1]])
    Fu = np.array([[dt * np.cos(th), 0], [dt * np.sin(th), 0], [0, dt]])
    mu[:3] = motion(mu[:3], vn, wn)
    P[:3, :3] = Fx @ P[:3, :3] @ Fx.T + Fu @ Q @ Fu.T
    P[:3, 3:] = Fx @ P[:3, 3:]; P[3:, :3] = P[:3, 3:].T
    # --- güncelleme (update): menzildeki her işaret için
    x = truth[k + 1]
    for i in range(nL):
        d = L[i] - x[:2]; r = np.hypot(*d)
        if r > R_max: continue
        z = np.array([r + rng.normal(0, sig_r), wrap(np.arctan2(d[1], d[0]) - x[2] + rng.normal(0, sig_b))])
        j = 3 + 2 * i
        if not seen[i]:                                                   # ilk görüş: işareti başlat
            mu[j:j + 2] = mu[:2] + z[0] * np.array([np.cos(z[1] + mu[2]), np.sin(z[1] + mu[2])]); seen[i] = True
        dx = mu[j:j + 2] - mu[:2]; q = dx @ dx; sq = np.sqrt(q)
        zh = np.array([sq, wrap(np.arctan2(dx[1], dx[0]) - mu[2])])
        H = np.zeros((2, n))
        H[:, :3] = np.array([[-dx[0] / sq, -dx[1] / sq, 0], [dx[1] / q, -dx[0] / q, -1]])
        H[:, j:j + 2] = np.array([[dx[0] / sq, dx[1] / sq], [-dx[1] / q, dx[0] / q]])
        S = H @ P @ H.T + Rm; Kg = P @ H.T @ np.linalg.inv(S)
        inn = z - zh; inn[1] = wrap(inn[1])
        mu = mu + Kg @ inn; mu[2] = wrap(mu[2])
        P = (np.eye(n) - Kg @ H) @ P; P = 0.5 * (P + P.T)
    mu_hist.append(mu[:3].copy()); Pxx.append(np.sqrt(P[0, 0] + P[1, 1]))

dr_hist, mu_hist, Pxx = np.array(dr_hist), np.array(mu_hist), np.array(Pxx)
e_dr = np.linalg.norm(dr_hist[:, :2] - truth[:, :2], axis=1); e_sl = np.linalg.norm(mu_hist[:, :2] - truth[:, :2], axis=1)
vis = np.zeros(T + 1, int)
for k in range(T + 1):
    vis[k] = (np.linalg.norm(L - truth[k, :2], axis=1) < R_max).sum()
print("işaret görmeyen adım aralığı:", np.where(vis == 0)[0].min(), "-", np.where(vis == 0)[0].max())
for k in [100, 200, 300, 400, 470, 520, 600]:
    print(f"adım {k:3d}: konum hatası  ölü hesap {e_dr[k]:5.3f} m   EKF-SLAM {e_sl[k]:5.3f} m   (EKF 1σ {Pxx[k]:.3f} m)")
le = np.linalg.norm(mu[3:].reshape(-1, 2) - L, axis=1)
print("işaret hataları [m]:", le[seen].round(3), " görülen:", seen.sum(), "/", nL)
print("durum boyutu", n, "-> kovaryans", n, "x", n, "; her güncelleme O(n²): 1000 işarette ~", (3 + 2000)**2 // 10**6, "milyon eleman")
# NEES tutarlılık kontrolü: hata, iddia edilen kovaryansla uyumlu mu? (2 serbestlik için ~2 beklenir)
print("son adımda konum için NEES:", float((mu[:2] - truth[-1, :2]) @ np.linalg.inv(P[:2, :2]) @ (mu[:2] - truth[-1, :2])).__round__(2))

# %% plot
from figstyle import plt, save
fig, ax = plt.subplots(1, 2, figsize=(6.4, 3.0))
ax[0].plot(truth[:, 0], truth[:, 1], "k-", lw=1, label="gerçek"); ax[0].plot(dr_hist[:, 0], dr_hist[:, 1], "--", label="ölü hesap")
ax[0].plot(mu_hist[:, 0], mu_hist[:, 1], label="EKF-SLAM"); ax[0].scatter(L[:, 0], L[:, 1], marker="*", s=60, c="k", label="işaret")
ax[0].scatter(mu[3::2], mu[4::2], marker="x", s=30, c="#D1495B"); ax[0].set_aspect("equal"); ax[0].legend(fontsize=6, loc="center")
ax[1].plot(e_dr, "--", label="ölü hesap hatası"); ax[1].plot(e_sl, label="EKF-SLAM hatası"); ax[1].plot(Pxx, ":", label="EKF 1σ")
ax[1].set_xlabel("adım (0.1 s)"); ax[1].set_ylabel("m"); ax[1].legend(fontsize=7)
save("p5_ekf_slam")
