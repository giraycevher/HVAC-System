import numpy as np
rng = np.random.default_rng(7)

# Bacaklı robot gövde durum kestirimi (yatay eksen, sadeleştirilmiş):
#   durum x = [p, v, b]  (konum, hız, ivmeölçer sapması)
#   giriş:  ivmeölçer a_ölç = a + b + gürültü  (400 Hz)
#   ölçüm:  ayak yerdeyken bacak kinematiğinden gövde hızı  v_bacak = -J(q) q̇  (+ gürültü)
dt = 0.0025; T = 20.0; n = int(T / dt); t = np.arange(n) * dt
v_true = 0.3 + 0.08 * np.sin(2 * np.pi * 1.5 * t)          # adım frekansında dalgalanan yürüme hızı
a_true = np.gradient(v_true, dt); p_true = np.cumsum(v_true) * dt
b_true = 0.15                                                # m/s² ivmeölçer sapması (ucuz IMU için tipik büyüklük)
a_meas = a_true + b_true + rng.normal(0, 0.05, n)
v_leg = v_true + rng.normal(0, 0.04, n)                      # bacak odometrisi hızı
slip = (t > 8) & (t < 9.5)                                   # ayak kayıyor: kinematik "yanlış" hız söylüyor
v_leg[slip] += 0.35
contact = np.ones(n, bool); contact[(t % (1 / 1.5)) < 0.03] = False   # adım değişiminde kısa çift-havada belirsizlik

F = np.array([[1, dt, -0.5 * dt**2], [0, 1, -dt], [0, 0, 1]]); G = np.array([0.5 * dt**2, dt, 0])
Q = np.diag([1e-8, (0.05 * dt)**2, (1e-3 * dt)**2]); Hm = np.array([[0, 1.0, 0]]); Rv = 0.04**2

def run(use_leg=True, gate=None):
    x = np.zeros(3); P = np.diag([1e-4, 1e-2, 0.1]); out = np.zeros((n, 3)); rej = 0
    for k in range(n):
        x = F @ x + G * a_meas[k]; P = F @ P @ F.T + Q          # IMU ile tahmin
        if use_leg and contact[k]:
            S = Hm @ P @ Hm.T + Rv; inn = v_leg[k] - x[1]
            if gate is not None and inn**2 / S[0, 0] > gate:     # Mahalanobis kapısı: tutarsız ölçümü reddet
                rej += 1; out[k] = x; continue
            Kg = (P @ Hm.T / S).ravel(); x = x + Kg * inn; P = (np.eye(3) - np.outer(Kg, Hm)) @ P
        out[k] = x
    return out, rej

imu, _ = run(use_leg=False)
vl = v_leg.copy()
for k in range(1, n):
    if not contact[k]: vl[k] = vl[k - 1]                     # temas yoksa son ölçülen hızı tut
leg_only = np.cumsum(vl) * dt
kf, _ = run()
kfg, rej = run(gate=9.0)                                      # 3σ kapı
def rep(name, pe, ve=None):
    s = f"{name:28s} 20 s sonra konum hatası {abs(pe[-1] - p_true[-1]):6.3f} m"
    if ve is not None: s += f",  hız RMS hatası {np.sqrt(((ve - v_true)**2).mean()):.3f} m/s"
    print(s)
rep("sadece IMU (çift integral)", imu[:, 0], imu[:, 1])
rep("sadece bacak odometrisi", leg_only)
rep("KF (IMU + bacak)", kf[:, 0], kf[:, 1])
rep("KF + kayma kapısı (3σ)", kfg[:, 0], kfg[:, 1])
print("kestirilen ivmeölçer sapması:", kf[-1, 2].round(4), "(gerçek", b_true, ")")
m = slip
print(f"kayma sırasında hız hatası (ort.): KF {np.abs(kf[m, 1] - v_true[m]).mean():.3f}  kapılı KF {np.abs(kfg[m, 1] - v_true[m]).mean():.3f} m/s;  reddedilen ölçüm {rej}")
print("Not: konumu düzelten bir ölçüm yok -> konum hatası zamanla büyür (gözlemlenemez); kamera/lidar gerekir.")

# %% plot
from figstyle import plt, save
fig, ax = plt.subplots(1, 2, figsize=(6.4, 3.0))
sl = (t > 6) & (t < 11)
ax[0].plot(t[sl], v_true[sl], "k", lw=1, label="gerçek"); ax[0].plot(t[sl], kf[sl, 1], label="KF"); ax[0].plot(t[sl], kfg[sl, 1], label="KF + kapı")
ax[0].axvspan(8, 9.5, color="#EDAE49", alpha=0.2, label="kayma"); ax[0].set_xlabel("t [s]"); ax[0].set_ylabel("v [m/s]"); ax[0].legend(fontsize=7)
for y, lab in [(imu[:, 0], "IMU"), (leg_only, "bacak"), (kf[:, 0], "KF"), (kfg[:, 0], "KF+kapı")]:
    ax[1].plot(t, y - p_true, label=lab)
ax[1].set_ylim(-1, 1.5); ax[1].set_xlabel("t [s]"); ax[1].set_ylabel("konum hatası [m]"); ax[1].legend(fontsize=7)
save("p7_legged_est")
