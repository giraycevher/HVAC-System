// c02_rot.cpp — dönme gösterimleri ve yönelim integrasyonu (Python c02_rot.py ile aynı sayılar)
#include "robkit.hpp"
#include <cstdio>
#include <iostream>
using namespace rk;

double ang_err(const Mat3& Ra, const Mat3& Rt) { return log_so3(Ra.transpose() * Rt).norm(); }
double orth_err(const Mat3& Ra) { return (Ra.transpose() * Ra - Mat3::Identity()).cwiseAbs().maxCoeff(); }

int main() {
    Eigen::IOFormat F(5, 0, " ", "\n", "[", "]");
    Mat3 R = rpy_to_R(0.1, 0.2, 0.3);
    std::cout << "R =\n" << R.format(F) << "\n";
    Vec4 q = R_to_quat(R); Vec3 w = log_so3(R);
    std::printf("kuaterniyon [w x y z] = [%.5f %.5f %.5f %.5f]\n", q(0), q(1), q(2), q(3));
    std::printf("eksen-açı: açı = %.5f rad\n", w.norm());
    std::printf("geri dönüşüm hataları: quat->R %.1e, exp(log R) %.1e\n",
                (quat_to_R(q) - R).cwiseAbs().maxCoeff(), (exp_so3(w) - R).cwiseAbs().maxCoeff());

    // Eigen'in kendi tipleriyle çapraz kontrol: Quaterniond (w,x,y,z) kurucusu, ama coeffs() sırası (x,y,z,w)!
    Eigen::Quaterniond qe(R);
    std::printf("Eigen::Quaterniond: w=%.5f x=%.5f y=%.5f z=%.5f  |  coeffs() = [%.5f %.5f %.5f %.5f] (x,y,z,w sırası)\n",
                qe.w(), qe.x(), qe.y(), qe.z(), qe.coeffs()(0), qe.coeffs()(1), qe.coeffs()(2), qe.coeffs()(3));

    // Gimbal lock
    Mat3 Ra = rpy_to_R(0.3, M_PI / 2, 0.5), Rb = rpy_to_R(0.1, M_PI / 2, 0.3);
    Mat3 E = Mat3::Zero(); E(2, 1) = 1e-10; E(2, 2) = -1e-10;
    Vec3 r1 = R_to_rpy(Ra), r2 = R_to_rpy(Ra + E);
    std::printf("\ngimbal lock: |Ra - Rb| = %.1e; R->rpy = (%.5f %.5f %.5f), 1e-10 gürültüyle (%.5f %.5f %.5f)\n",
                (Ra - Rb).cwiseAbs().maxCoeff(), r1(0), r1(1), r1(2), r2(0), r2(1), r2(2));

    // Yönelim integrasyonu
    Vec3 wb(0.5, -0.3, 1.0); double dt = 0.01; int N = 1000;
    Mat3 Rt = exp_so3(wb * 10.0), Reu = Mat3::Identity(), Rex = Mat3::Identity();
    Vec4 qn(1, 0, 0, 0), wq; wq << 0, wb;
    for (int k = 0; k < N; ++k) {
        Reu = Reu + Reu * skew(wb) * dt;
        Rex = Rex * exp_so3(wb * dt);
        qn = qn + 0.5 * quat_mul(qn, wq) * dt; qn.normalize();
    }
    std::printf("\n10 s, dt=0.01:\n  naif Euler: ortogonallik hatası %.2e\n  exp ile: açı hatası %.2e, ortogonallik %.2e\n  kuaterniyon (normlu): açı hatası %.2e\n",
                orth_err(Reu), ang_err(Rex, Rt), orth_err(Rex), ang_err(quat_to_R(qn), Rt));
    return 0;
}
