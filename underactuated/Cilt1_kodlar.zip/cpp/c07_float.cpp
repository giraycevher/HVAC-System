// c07_float.cpp — yüzen tabanlı düzlemsel bacak: M(q), g(q), statik temas kuvvetleri (Python ile aynı model)
#include <Eigen/Dense>
#include <array>
#include <cmath>
#include <cstdio>
#include <functional>
using Eigen::Vector2d; using Eigen::VectorXd; using Eigen::MatrixXd;
using Vec6 = Eigen::Matrix<double, 6, 1>;

constexpr double g = 9.81, m_t = 1.2, m_th = 0.3, m_sh = 0.2, m_ft = 0.1;
constexpr double L_t = 0.30, L_th = 0.20, L_sh = 0.20, HEEL = -0.03, TOE = 0.07, FCOM = 0.02;
const double I_[4] = {m_t * L_t * L_t / 12, m_th * L_th * L_th / 12, m_sh * L_sh * L_sh / 12, m_ft * 0.01 / 12};
const double m_[4] = {m_t, m_th, m_sh, m_ft};

Vector2d down(double p) { return Vector2d(std::sin(p), -std::cos(p)); }
Vector2d fwd(double p) { return Vector2d(std::cos(p), std::sin(p)); }

struct Kin { std::array<Vector2d, 4> com; std::array<double, 4> ang; Vector2d heel, toe; };
Kin kin(const Vec6& q) {
    Kin k; Vector2d hip(q(0), q(1)); double th = q(2), p1 = th + q(3), p2 = p1 + q(4), p3 = p2 + q(5);
    Vector2d knee = hip + L_th * down(p1), ankle = knee + L_sh * down(p2);
    k.com = {hip + 0.5 * L_t * Vector2d(-std::sin(th), std::cos(th)), hip + 0.5 * L_th * down(p1),
             knee + 0.5 * L_sh * down(p2), ankle + FCOM * fwd(p3)};
    k.ang = {th, p1, p2, p3};
    k.heel = ankle + HEEL * fwd(p3); k.toe = ankle + TOE * fwd(p3);
    return k;
}
// Genel sayısal Jacobian: f: R^6 -> R^m
MatrixXd jac(const std::function<VectorXd(const Vec6&)>& f, const Vec6& q, double h = 1e-7) {
    VectorXd f0 = f(q); MatrixXd J(f0.size(), 6);
    for (int i = 0; i < 6; ++i) { Vec6 e = Vec6::Unit(i) * h; J.col(i) = (f(q + e) - f(q - e)) / (2 * h); }
    return J;
}
MatrixXd mass_matrix(const Vec6& q) {
    MatrixXd M = MatrixXd::Zero(6, 6);
    for (int b = 0; b < 4; ++b) {
        MatrixXd Jv = jac([b](const Vec6& s) { return VectorXd(kin(s).com[b]); }, q);
        MatrixXd Jw = jac([b](const Vec6& s) { VectorXd v(1); v(0) = kin(s).ang[b]; return v; }, q);
        M += m_[b] * Jv.transpose() * Jv + I_[b] * Jw.transpose() * Jw;
    }
    return M;
}
VectorXd gravity(const Vec6& q) {
    auto V = [](const Vec6& s) { Kin k = kin(s); VectorXd v(1); v(0) = 0; for (int b = 0; b < 4; ++b) v(0) += m_[b] * g * k.com[b].y(); return v; };
    return jac(V, q).row(0).transpose();
}
MatrixXd Jc(const Vec6& q) {
    return jac([](const Vec6& s) { Kin k = kin(s); VectorXd v(3); v << k.heel, k.toe.y(); return v; }, q);
}
Vec6 standing_q(double thb, double qh, double qk) {
    Vec6 q; q << 0, 0, thb, qh, qk, -(thb + qh + qk);
    Vector2d ankle = kin(q).heel - HEEL * fwd(0.0); q(0) -= ankle.x(); q(1) -= ankle.y(); return q;
}

int main() {
    struct Case { const char* name; double thb, qh, qk; };
    for (const Case& c : {Case{"dik duruş", 0.0, -0.3, 0.6}, Case{"geriye eğik +0.35", 0.35, -0.3, 0.6}, Case{"öne eğik -0.35", -0.35, -0.3, 0.6}}) {
        Vec6 q = standing_q(c.thb, c.qh, c.qk);
        MatrixXd M = mass_matrix(q), J = Jc(q); VectorXd G = gravity(q);
        VectorXd lam = J.leftCols(3).transpose().partialPivLu().solve(G.head(3));      // taban satırları: g_b = J_bᵀ λ
        VectorXd tau = G.tail(3) - J.rightCols(3).transpose() * lam;
        bool ok = lam(1) >= 0 && lam(2) >= 0;
        std::printf("%-18s M00=%.4f  λz topuk=%+.3f burun=%+.3f N  τ=[%+.4f %+.4f %+.4f]  %s\n", c.name, M(0, 0),
                    lam(1), lam(2), tau(0), tau(1), tau(2), ok ? "DENGEDE" : "DEVRİLİR");
    }
    return 0;
}
