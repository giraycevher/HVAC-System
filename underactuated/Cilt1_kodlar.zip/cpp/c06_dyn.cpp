// c06_dyn.cpp — düzlemsel RNEA, Lagrange ile karşılaştırma, RK4 enerji korunumu, hız ölçümü
#include <Eigen/Dense>
#include <chrono>
#include <cmath>
#include <cstdio>
#include <random>
using Eigen::Vector2d; using Eigen::Matrix2d;

constexpr double g = 9.81;
constexpr double L[2] = {0.2, 0.2}, ms[2] = {0.30, 0.20};
constexpr double lc[2] = {0.1, 0.1}, Is[2] = {0.30 * 0.04 / 12, 0.20 * 0.04 / 12};

inline Vector2d perp(const Vector2d& v) { return Vector2d(-v.y(), v.x()); }
inline double cross2(const Vector2d& r, const Vector2d& f) { return r.x() * f.y() - r.y() * f.x(); }

Vector2d rnea(const Vector2d& q, const Vector2d& qd, const Vector2d& qdd, double grav = g) {
    double a[2] = {q(0), q(0) + q(1)}, w[2] = {qd(0), qd(0) + qd(1)}, al[2] = {qdd(0), qdd(0) + qdd(1)};
    Vector2d u[2], ac[2], ap(0.0, grav);
    for (int i = 0; i < 2; ++i) {                                     // ileri geçiş
        u[i] = Vector2d(std::sin(a[i]), -std::cos(a[i]));
        Vector2d rc = lc[i] * u[i], rl = L[i] * u[i];
        ac[i] = ap + al[i] * perp(rc) - w[i] * w[i] * rc;
        ap = ap + al[i] * perp(rl) - w[i] * w[i] * rl;
    }
    Vector2d tau, f_next = Vector2d::Zero(); double n_next = 0;
    for (int i = 1; i >= 0; --i) {                                    // geri geçiş
        Vector2d f = ms[i] * ac[i] + f_next;
        double nm = Is[i] * al[i] + cross2(lc[i] * u[i], ms[i] * ac[i]) + n_next + cross2(L[i] * u[i], f_next);
        tau(i) = nm; f_next = f; n_next = nm;
    }
    return tau;
}
Matrix2d M_closed(const Vector2d& q) {
    double c2 = std::cos(q(1)), m11 = Is[0] + Is[1] + ms[0] * lc[0] * lc[0] + ms[1] * (L[0] * L[0] + lc[1] * lc[1] + 2 * L[0] * lc[1] * c2);
    double m12 = Is[1] + ms[1] * (lc[1] * lc[1] + L[0] * lc[1] * c2), m22 = Is[1] + ms[1] * lc[1] * lc[1];
    Matrix2d M; M << m11, m12, m12, m22; return M;
}
Vector2d lagrange_tau(const Vector2d& q, const Vector2d& qd, const Vector2d& qdd) {
    double h = -ms[1] * L[0] * lc[1] * std::sin(q(1));
    Matrix2d C; C << h * qd(1), h * (qd(0) + qd(1)), -h * qd(0), 0;
    Vector2d gv(ms[0] * g * lc[0] * std::sin(q(0)) + ms[1] * g * (L[0] * std::sin(q(0)) + lc[1] * std::sin(q(0) + q(1))),
                ms[1] * g * lc[1] * std::sin(q(0) + q(1)));
    return M_closed(q) * qdd + C * qd + gv;
}
double energy(const Vector2d& q, const Vector2d& qd) {
    double a1 = q(0), a2 = q(0) + q(1);
    return 0.5 * qd.dot(M_closed(q) * qd) + g * (ms[0] * (-lc[0] * std::cos(a1)) + ms[1] * (-L[0] * std::cos(a1) - lc[1] * std::cos(a2)));
}
using State = Eigen::Vector4d;
State f(const State& s) {
    Vector2d q = s.head<2>(), qd = s.tail<2>();
    Vector2d qdd = M_closed(q).ldlt().solve(-rnea(q, qd, Vector2d::Zero()));   // τ = 0
    State ds; ds << qd, qdd; return ds;
}

int main() {
    std::mt19937 gen(1); std::normal_distribution<double> N01;
    double mx = 0;
    for (int k = 0; k < 100; ++k) {
        Vector2d q(N01(gen), N01(gen)), qd(N01(gen), N01(gen)), qdd(N01(gen), N01(gen));
        mx = std::max(mx, (rnea(q, qd, qdd) - lagrange_tau(q, qd, qdd)).cwiseAbs().maxCoeff());
    }
    std::printf("RNEA vs Lagrange (100 rastgele durum): max fark %.2e N·m\n", mx);

    for (double dt : {1e-3, 1e-4}) {
        State s; s << 1.2, 0.5, 0, 0; double E0 = energy(s.head<2>(), s.tail<2>());
        int n = (int)std::lround(10.0 / dt);
        for (int k = 0; k < n; ++k) {
            State k1 = f(s), k2 = f(s + dt / 2 * k1), k3 = f(s + dt / 2 * k2), k4 = f(s + dt * k3);
            s += dt / 6 * (k1 + 2 * k2 + 2 * k3 + k4);
        }
        std::printf("RK4 dt=%.0e: enerji hatası %+.3e J\n", dt, energy(s.head<2>(), s.tail<2>()) - E0);
    }

    Vector2d q(0.3, 0.4), qd(0.1, 0.2), qdd(0.5, 0.6), acc = Vector2d::Zero();
    const int n_call = 2000000;
    auto t0 = std::chrono::steady_clock::now();
    for (int k = 0; k < n_call; ++k) { qdd(0) += 1e-12; acc += rnea(q, qd, qdd); }   // derleyici döngüyü silmesin diye
    double us = std::chrono::duration<double, std::micro>(std::chrono::steady_clock::now() - t0).count() / n_call;
    std::printf("C++ RNEA (2 uzuv): %.3f µs/çağrı (kontrol toplamı %.3f)\n", us, acc(0));
    return 0;
}
