// c05_ik.cpp — analitik ve sayısal (Newton / DLS) ters kinematik
#include "robkit.hpp"
#include <cstdio>
#include <random>
#include <stdexcept>
using namespace rk;
using Eigen::Vector3d;

const double l1 = 0.2, l2 = 0.2;
Vec6 screw(const Vec3& w, const Vec3& q) { Vec6 S; S << w, -w.cross(q); return S; }
const std::vector<Vec6> S = {screw(Vec3::UnitX(), Vec3::Zero()), screw(Vec3::UnitY(), Vec3::Zero()),
                             screw(Vec3::UnitY(), Vec3(0, 0, -l1))};
const Mat4 M = homog(Mat3::Identity(), Vec3(0, 0, -l1 - l2));
Vec3 foot(const Vector3d& q) { return fk_poe(S, M, q).topRightCorner<3, 1>(); }
Mat3 Jp(const Vector3d& q) { Jac Js = space_jacobian(S, q); return Js.bottomRows<3>() - skew(foot(q)) * Js.topRows<3>(); }

Vector3d ik_analytic(const Vec3& p, int knee_sign = +1) {
    double x = p(0), y = p(1), z = p(2);
    double q1 = std::atan2(y, -z), zs = -std::hypot(y, z);
    double D = (x * x + zs * zs - l1 * l1 - l2 * l2) / (2 * l1 * l2);
    if (std::abs(D) > 1) throw std::domain_error("ulaşılamaz hedef");
    double q3 = knee_sign * std::acos(D);
    double q2 = std::atan2(-x, -zs) - std::atan2(l2 * std::sin(q3), l1 + l2 * std::cos(q3));
    return Vector3d(q1, q2, q3);
}

struct IkResult { Vector3d q; int iters; double err; };
IkResult ik_numeric(const Vec3& p, Vector3d q, double lam, int iters = 100, double tol = 1e-10) {
    for (int k = 0; k < iters; ++k) {
        Vec3 e = p - foot(q);
        if (e.norm() < tol) return {q, k, e.norm()};
        Mat3 J = Jp(q);
        Vec3 dq = (lam > 0) ? Vec3(J.transpose() * (J * J.transpose() + lam * lam * Mat3::Identity()).ldlt().solve(e))
                            : Vec3(J.completeOrthogonalDecomposition().solve(e));
        q += dq;
    }
    return {q, iters, (p - foot(q)).norm()};
}

int main() {
    std::mt19937 gen(0);
    std::uniform_real_distribution<double> u1(-0.4, 0.4), u2(-1.2, 0.6), u3(0.05, 2.2);
    double maxerr = 0;
    for (int i = 0; i < 1000; ++i) {
        Vector3d qt(u1(gen), u2(gen), u3(gen));
        maxerr = std::max(maxerr, (foot(ik_analytic(foot(qt))) - foot(qt)).norm());
    }
    std::printf("analitik IK, 1000 rastgele hedef: max hata %.2e m\n", maxerr);
    Vec3 p(0.05, 0.03, -0.33);
    Vector3d qa = ik_analytic(p, +1), qb = ik_analytic(p, -1);
    std::printf("diz öne: [%.5f %.5f %.5f], diz arkaya: [%.5f %.5f %.5f]\n", qa(0), qa(1), qa(2), qb(0), qb(1), qb(2));
    for (double lam : {0.0, 0.01, 0.05}) {
        auto r = ik_numeric(p, Vector3d(0, -0.2, 0.4), lam);
        std::printf("λ=%.2f: %3d iterasyon, hata %.1e\n", lam, r.iters, r.err);
    }
    Vec3 pf(0.1, 0.0, -0.4387);
    for (double lam : {0.0, 0.05}) {
        auto r = ik_numeric(pf, Vector3d(0, -0.2, 0.4), lam);
        std::printf("ulaşılamaz hedef, λ=%.2f: hata %.4f m, |q| = %.2f\n", lam, r.err, r.q.norm());
    }
    try { ik_analytic(pf); } catch (const std::domain_error& ex) { std::printf("analitik IK istisna: %s\n", ex.what()); }
    return 0;
}
