// c08_tests.cpp — robkit için küçük bir birim test seti (çerçevesiz; Cilt 2'de GoogleTest'e taşınacak)
#include "robkit.hpp"
#include <cstdio>
#include <random>
using namespace rk;

static int n_pass = 0, n_fail = 0;
#define CHECK_NEAR(a, b, tol, name)                                                    \
    do { double _e = std::abs((a) - (b));                                               \
         if (_e <= (tol)) ++n_pass;                                                     \
         else { ++n_fail; std::printf("BAŞARISIZ: %s (hata %.2e > %.0e)\n", name, _e, tol); } } while (0)

int main() {
    std::mt19937 gen(42); std::uniform_real_distribution<double> U(-3.0, 3.0);
    for (int t = 0; t < 200; ++t) {
        Vec3 w(U(gen), U(gen), U(gen));
        if (w.norm() > 3.1) w *= 3.1 / w.norm();                         // log'un tek değerli olduğu bölge: |w| < π
        Mat3 R = exp_so3(w);
        CHECK_NEAR((R.transpose() * R - Mat3::Identity()).norm(), 0.0, 1e-12, "R ortogonal");
        CHECK_NEAR(R.determinant(), 1.0, 1e-12, "det R = 1");
        CHECK_NEAR((log_so3(R) - w).norm(), 0.0, 1e-9, "log(exp(w)) = w");
        CHECK_NEAR((quat_to_R(R_to_quat(R)) - R).norm(), 0.0, 1e-12, "quat gidiş-dönüş");
        Vec3 rpy(U(gen) / 2, U(gen) / 2.2, U(gen));                      // pitch |.| < π/2 (gimbal lock dışı)
        CHECK_NEAR((R_to_rpy(rpy_to_R(rpy(0), rpy(1), rpy(2))) - rpy).norm(), 0.0, 1e-9, "rpy gidiş-dönüş");
    }
    // Bacak: PoE = zincir, Jacobian = sonlu fark
    std::vector<Vec6> S(3);
    S[0] << 1, 0, 0, 0, 0, 0; S[1] << 0, 1, 0, 0, 0, 0; S[2] << 0, 1, 0, 0.2, 0, 0;
    Mat4 M = homog(Mat3::Identity(), Vec3(0, 0, -0.4));
    for (int t = 0; t < 100; ++t) {
        Eigen::Vector3d q(U(gen) / 4, U(gen) / 2, U(gen) / 2);
        Mat4 T = fk_poe(S, M, q);
        Mat4 Tc = homog(rot_x(q(0)), Vec3::Zero()) * homog(rot_y(q(1)), Vec3::Zero()) * homog(Mat3::Identity(), Vec3(0, 0, -0.2)) *
                  homog(rot_y(q(2)), Vec3::Zero()) * homog(Mat3::Identity(), Vec3(0, 0, -0.2));
        CHECK_NEAR((T - Tc).norm(), 0.0, 1e-12, "PoE = zincir");
        Jac Js = space_jacobian(S, q); const double h = 1e-6;
        for (int i = 0; i < 3; ++i) {
            Eigen::Vector3d e = Eigen::Vector3d::Unit(i) * h;
            Mat4 Td = (fk_poe(S, M, q + e) - fk_poe(S, M, q - e)) / (2 * h);
            Mat4 V = Td * inv_T(T); Vec6 Vs; Vs << unskew(V.topLeftCorner<3, 3>()), V.topRightCorner<3, 1>();
            CHECK_NEAR((Vs - Js.col(i)).norm(), 0.0, 1e-8, "J_s sütunu = sonlu fark");
        }
    }
    std::printf("%d test geçti, %d test başarısız\n", n_pass, n_fail);
    return n_fail == 0 ? 0 : 1;
}
