// c04_jac.cpp — ayak Jacobian'ı, sonlu fark kontrolü, statik eklem torkları
#include "robkit.hpp"
#include <cstdio>
using namespace rk;
using Eigen::Vector3d;

const double l1 = 0.2, l2 = 0.2;
Vec6 screw(const Vec3& w, const Vec3& q) { Vec6 S; S << w, -w.cross(q); return S; }
const std::vector<Vec6> S = {screw(Vec3::UnitX(), Vec3::Zero()), screw(Vec3::UnitY(), Vec3::Zero()),
                             screw(Vec3::UnitY(), Vec3(0, 0, -l1))};
const Mat4 M = homog(Mat3::Identity(), Vec3(0, 0, -l1 - l2));

Vec3 foot(const Vector3d& q) { return fk_poe(S, M, q).topRightCorner<3, 1>(); }
Mat3 foot_jacobian(const Vector3d& q) {
    Jac Js = space_jacobian(S, q);
    return Js.bottomRows<3>() - skew(foot(q)) * Js.topRows<3>();     // J_v - [p] J_ω
}

int main() {
    Vector3d q(0.2, -0.5, 0.9);
    Mat3 Jp = foot_jacobian(q), Jfd;
    const double h = 1e-6;
    for (int i = 0; i < 3; ++i) {
        Vector3d e = Vector3d::Unit(i);
        Jfd.col(i) = (foot(q + h * e) - foot(q - h * e)) / (2 * h);
    }
    std::printf("J_p satır 1: [%.5f %.5f %.5f]; sonlu farkla max fark %.1e\n", Jp(0, 0), Jp(0, 1), Jp(0, 2),
                (Jp - Jfd).cwiseAbs().maxCoeff());

    const double m = 2.0, g = 9.81; Vec3 F(0, 0, m * g / 2);
    for (double qk : {0.2, 0.6, 1.0, 1.4}) {
        Vector3d qq(0.0, -qk / 2, qk);
        Vec3 tau = -foot_jacobian(qq).transpose() * F;
        std::printf("diz=%.1f rad: τ = [%.4f %.4f %.4f] N·m, |τ_diz| = %.1f kg·cm\n", qk, tau(0), tau(1), tau(2),
                    std::abs(tau(2)) / 9.81 * 100);
    }
    return 0;
}
