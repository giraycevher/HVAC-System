// robkit.hpp — robkit.py'nin C++/Eigen karşılığı (sadece başlık dosyası; #include "robkit.hpp" yeterli).
// Konvansiyonlar Python ile aynı: kuaterniyon [w,x,y,z], RPY = ZYX, twist S = [ω; v].
#pragma once
#include <Eigen/Dense>
#include <cmath>
#include <vector>

namespace rk {
using Mat3 = Eigen::Matrix3d;  using Vec3 = Eigen::Vector3d;
using Mat4 = Eigen::Matrix4d;  using Vec4 = Eigen::Vector4d;
using Mat6 = Eigen::Matrix<double, 6, 6>;  using Vec6 = Eigen::Matrix<double, 6, 1>;
using Jac  = Eigen::Matrix<double, 6, Eigen::Dynamic>;

inline Mat3 skew(const Vec3& w) {
    Mat3 S; S << 0, -w(2), w(1),  w(2), 0, -w(0),  -w(1), w(0), 0; return S;
}
inline Vec3 unskew(const Mat3& S) { return Vec3(S(2, 1), S(0, 2), S(1, 0)); }

inline Mat3 exp_so3(const Vec3& w) {                       // Rodrigues
    double th = w.norm();
    if (th < 1e-12) return Mat3::Identity() + skew(w);
    Mat3 K = skew(w / th);
    return Mat3::Identity() + std::sin(th) * K + (1 - std::cos(th)) * K * K;
}

inline Vec3 log_so3(const Mat3& R) {
    double c = std::clamp((R.trace() - 1) / 2, -1.0, 1.0), th = std::acos(c);
    if (th < 1e-9) return unskew(R - R.transpose()) / 2;
    if (M_PI - th < 1e-6) {                                   // 180 derece civarı
        int k; R.diagonal().maxCoeff(&k);
        double a = std::sqrt(std::max((R(k, k) + 1) / 2, 0.0));
        Vec3 w = R.col(k) / (2 * a); w(k) = a;
        return th * w.normalized();
    }
    return th / (2 * std::sin(th)) * unskew(R - R.transpose());
}

inline Mat3 rot_x(double a) { Mat3 R; R << 1, 0, 0, 0, std::cos(a), -std::sin(a), 0, std::sin(a), std::cos(a); return R; }
inline Mat3 rot_y(double a) { Mat3 R; R << std::cos(a), 0, std::sin(a), 0, 1, 0, -std::sin(a), 0, std::cos(a); return R; }
inline Mat3 rot_z(double a) { Mat3 R; R << std::cos(a), -std::sin(a), 0, std::sin(a), std::cos(a), 0, 0, 0, 1; return R; }
inline Mat3 rpy_to_R(double r, double p, double y) { return rot_z(y) * rot_y(p) * rot_x(r); }
inline Vec3 R_to_rpy(const Mat3& R) {
    return Vec3(std::atan2(R(2, 1), R(2, 2)), std::asin(std::clamp(-R(2, 0), -1.0, 1.0)), std::atan2(R(1, 0), R(0, 0)));
}

// ---- kuaterniyon [w,x,y,z] (Eigen::Quaterniond yerine açık formül: Python ile birebir) ----
inline Vec4 quat_mul(const Vec4& a, const Vec4& b) {
    Vec3 v1 = a.tail<3>(), v2 = b.tail<3>();
    Vec4 r; r(0) = a(0) * b(0) - v1.dot(v2);
    r.tail<3>() = a(0) * v2 + b(0) * v1 + v1.cross(v2);
    return r;
}
inline Mat3 quat_to_R(Vec4 q) {
    q.normalize(); double w = q(0), x = q(1), y = q(2), z = q(3);
    Mat3 R;
    R << 1 - 2 * (y * y + z * z), 2 * (x * y - w * z), 2 * (x * z + w * y),
         2 * (x * y + w * z), 1 - 2 * (x * x + z * z), 2 * (y * z - w * x),
         2 * (x * z - w * y), 2 * (y * z + w * x), 1 - 2 * (x * x + y * y);
    return R;
}
inline Vec4 R_to_quat(const Mat3& R) {                     // Shepperd
    Vec4 q; double t = R.trace();
    if (t > 0) {
        double s = 2 * std::sqrt(t + 1);
        q << s / 4, (R(2, 1) - R(1, 2)) / s, (R(0, 2) - R(2, 0)) / s, (R(1, 0) - R(0, 1)) / s;
    } else {
        int i; R.diagonal().maxCoeff(&i); int j = (i + 1) % 3, k = (i + 2) % 3;
        double s = 2 * std::sqrt(1 + R(i, i) - R(j, j) - R(k, k));
        q(0) = (R(k, j) - R(j, k)) / s; q(1 + i) = s / 4;
        q(1 + j) = (R(j, i) + R(i, j)) / s; q(1 + k) = (R(k, i) + R(i, k)) / s;
    }
    return q(0) >= 0 ? q : Vec4(-q);
}
inline Vec4 quat_exp(const Vec3& w) {
    double th = w.norm(); Vec4 q;
    if (th < 1e-12) { q << 1, w / 2; return q; }
    q << std::cos(th / 2), std::sin(th / 2) * w / th; return q;
}

// ---- SE(3) ----
inline Mat4 homog(const Mat3& R, const Vec3& p) {
    Mat4 T = Mat4::Identity(); T.topLeftCorner<3, 3>() = R; T.topRightCorner<3, 1>() = p; return T;
}
inline Mat4 inv_T(const Mat4& T) {
    Mat3 R = T.topLeftCorner<3, 3>(); Vec3 p = T.topRightCorner<3, 1>();
    return homog(R.transpose(), -R.transpose() * p);
}
inline Mat4 exp_se3(const Vec6& S, double th) {
    Vec3 w = S.head<3>(), v = S.tail<3>();
    if (w.norm() < 1e-12) return homog(Mat3::Identity(), v * th);
    Mat3 K = skew(w);
    Mat3 G = Mat3::Identity() * th + (1 - std::cos(th)) * K + (th - std::sin(th)) * K * K;
    return homog(exp_so3(w * th), G * v);
}
inline Mat6 adjoint(const Mat4& T) {
    Mat3 R = T.topLeftCorner<3, 3>(); Vec3 p = T.topRightCorner<3, 1>();
    Mat6 A = Mat6::Zero();
    A.topLeftCorner<3, 3>() = R; A.bottomRightCorner<3, 3>() = R; A.bottomLeftCorner<3, 3>() = skew(p) * R;
    return A;
}
inline Mat4 fk_poe(const std::vector<Vec6>& S, const Mat4& M, const Eigen::VectorXd& q) {
    Mat4 T = Mat4::Identity();
    for (size_t i = 0; i < S.size(); ++i) T = T * exp_se3(S[i], q(i));
    return T * M;
}
inline Jac space_jacobian(const std::vector<Vec6>& S, const Eigen::VectorXd& q) {
    Jac J(6, q.size()); Mat4 T = Mat4::Identity();
    for (int i = 0; i < q.size(); ++i) { J.col(i) = adjoint(T) * S[i]; T = T * exp_se3(S[i], q(i)); }
    return J;
}
}  // namespace rk
