// c03_fk.cpp — PoE ile ileri kinematik, çerçeve zinciri ve twist/adjoint kontrolü
#include "robkit.hpp"
#include <cstdio>
using namespace rk;

Vec6 screw(const Vec3& w, const Vec3& q) { Vec6 S; S << w, -w.cross(q); return S; }

int main() {
    const double l1 = 0.2, l2 = 0.2;
    std::vector<Vec6> S = {screw(Vec3::UnitX(), Vec3::Zero()), screw(Vec3::UnitY(), Vec3::Zero()),
                           screw(Vec3::UnitY(), Vec3(0, 0, -l1))};
    Mat4 M = homog(Mat3::Identity(), Vec3(0, 0, -l1 - l2));
    Eigen::Vector3d q(0.2, -0.5, 0.9);
    Mat4 T = fk_poe(S, M, q);
    // Zincir ile: Rx(q1) Ry(q2) Tz(-l1) Ry(q3) Tz(-l2)
    Mat4 Tc = homog(rot_x(q(0)), Vec3::Zero()) * homog(rot_y(q(1)), Vec3::Zero()) *
              homog(Mat3::Identity(), Vec3(0, 0, -l1)) * homog(rot_y(q(2)), Vec3::Zero()) *
              homog(Mat3::Identity(), Vec3(0, 0, -l2));
    Vec3 p = T.topRightCorner<3, 1>();
    std::printf("ayak konumu (PoE): [%.5f %.5f %.5f], zincirle fark %.1e\n", p(0), p(1), p(2), (T - Tc).cwiseAbs().maxCoeff());

    Mat4 Twb = homog(rpy_to_R(0.05, -0.1, 0.3), Vec3(1.0, 0.5, 0.45));
    Mat4 Tbh = homog(Mat3::Identity(), Vec3(0.1, -0.08, -0.05));
    Vec3 pw = (Twb * Tbh * T).topRightCorner<3, 1>();
    std::printf("dünyada ayak konumu: [%.5f %.5f %.5f]\n", pw(0), pw(1), pw(2));

    // Twist: sonlu farkla Ṫ, sonra V_s = Ṫ T^-1, V_b = T^-1 Ṫ, kontrol: Ad_T V_b = V_s
    Eigen::Vector3d qd(0.4, -1.0, 1.5); double h = 1e-6;
    Mat4 Td = (fk_poe(S, M, q + h * qd) - fk_poe(S, M, q - h * qd)) / (2 * h);
    Mat4 Vs_m = Td * inv_T(T), Vb_m = inv_T(T) * Td;
    Vec6 Vs, Vb;
    Vs << unskew(Vs_m.topLeftCorner<3, 3>()), Vs_m.topRightCorner<3, 1>();
    Vb << unskew(Vb_m.topLeftCorner<3, 3>()), Vb_m.topRightCorner<3, 1>();
    std::printf("V_s = [%.5f %.5f %.5f %.5f %.5f %.5f]\n", Vs(0), Vs(1), Vs(2), Vs(3), Vs(4), Vs(5));
    std::printf("|Ad_T V_b - V_s| = %.1e\n", (adjoint(T) * Vb - Vs).cwiseAbs().maxCoeff());
    return 0;
}
