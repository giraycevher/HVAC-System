// c01_linalg.cpp — Python sürümüyle aynı hesaplar, Eigen ile.
// Derleme: g++ -std=c++17 -O2 -I /usr/include/eigen3 c01_linalg.cpp -o c01_linalg
#include <Eigen/Dense>
#include <cmath>
#include <cstdio>
#include <iostream>
using Eigen::MatrixXd; using Eigen::VectorXd; using Eigen::Vector2d; using Eigen::Vector3d;

const double L[3] = {0.20, 0.20, 0.08};

Eigen::Matrix<double, 2, 3> foot_jacobian(const Vector3d& q) {
    double a[3] = {q(0), q(0) + q(1), q(0) + q(1) + q(2)};        // mutlak açılar
    Eigen::Matrix<double, 2, 3> J = Eigen::Matrix<double, 2, 3>::Zero();
    for (int i = 0; i < 3; ++i)
        for (int k = i; k < 3; ++k) {                                 // i. eklem k>=i uzuvlarını döndürür
            J(0, i) += L[k] * std::cos(a[k]);
            J(1, i) += L[k] * std::sin(a[k]);
        }
    return J;
}

int main() {
    Eigen::IOFormat F(4, 0, ", ", "\n", "[", "]");
    Vector3d q(0.3, -0.6, 0.4);
    auto J = foot_jacobian(q);
    std::cout << "J =\n" << J.format(F) << "\n";
    Eigen::JacobiSVD<MatrixXd> svd(J, Eigen::ComputeFullU | Eigen::ComputeFullV);
    VectorXd s = svd.singularValues();
    std::printf("tekil değerler: [%.4f %.4f]  koşul sayısı: %.3f\n", s(0), s(1), s(0) / s(1));
    VectorXd n = svd.matrixV().col(2);                                // null uzayı (işareti Python'dan farklı olabilir)
    std::printf("null uzayı n = [%.4f %.4f %.4f], |J n| = %.1e\n", n(0), n(1), n(2), (J * n).norm());

    Vector2d v(0.1, 0.0);
    MatrixXd Jp = J.completeOrthogonalDecomposition().pseudoInverse();
    VectorXd qd = Jp * v;
    std::printf("pinv çözüm q̇ = [%.4f %.4f %.4f], |q̇| = %.4f\n", qd(0), qd(1), qd(2), qd.norm());

    std::printf("\n2 uzuvlu bacak: tekillik yakınında pinv ve DLS (ayak yukarı 0.1 m/s)\n");
    for (double q2 : {-1.0, -0.3, -0.1, -0.01}) {
        Eigen::Matrix2d J2;
        J2 << L[0] + L[1] * std::cos(q2), L[1] * std::cos(q2),
              L[1] * std::sin(q2),         L[1] * std::sin(q2);       // q1 = 0
        Vector2d vd(0.0, 0.1);
        Vector2d qp = J2.inverse() * vd;                               // kare ve tekil değil: pinv = ters
        double lam = 0.01;
        Vector2d qdls = J2.transpose() * (J2 * J2.transpose() + lam * lam * Eigen::Matrix2d::Identity()).ldlt().solve(vd);
        std::printf("  q2=%6.2f: |q̇| pinv = %10.4f, |q̇| DLS = %7.4f, DLS hız hatası = %.4f\n",
                    q2, qp.norm(), qdls.norm(), (J2 * qdls - vd).norm());
    }

    // En küçük kareler: servo kalibrasyonu
    const int N = 11; MatrixXd A(N, 2); VectorXd y(N);
    for (int i = 0; i < N; ++i) {
        double pwm = 1000.0 + 100.0 * i;
        A(i, 0) = pwm - 1500.0; A(i, 1) = 1.0;
        y(i) = 0.09 * (pwm - 1500.0) + 2.0 + 0.8 * std::sin(7.3 * i);
    }
    VectorXd x = A.colPivHouseholderQr().solve(y);                     // QR: lstsq'ya denk
    double rms = std::sqrt((A * x - y).squaredNorm() / N);
    std::printf("\nservo kalibrasyonu: eğim = %.5f derece/µs, ofset = %.4f derece, RMS artık = %.4f derece\n", x(0), x(1), rms);

    for (int n_ : {6, 10, 12}) {
        MatrixXd H(n_, n_);
        for (int i = 0; i < n_; ++i) for (int j = 0; j < n_; ++j) H(i, j) = 1.0 / (i + j + 1);
        VectorXd xt = VectorXd::Ones(n_), b = H * xt;
        double e_lu = (H.partialPivLu().solve(b) - xt).norm();
        double e_inv = (H.inverse() * b - xt).norm();
        Eigen::JacobiSVD<MatrixXd> sv(H); double c = sv.singularValues()(0) / sv.singularValues()(n_ - 1);
        std::printf("Hilbert n=%2d: cond = %.2e, hata LU = %.1e, hata inverse = %.1e\n", n_, c, e_lu, e_inv);
    }
    return 0;
}
