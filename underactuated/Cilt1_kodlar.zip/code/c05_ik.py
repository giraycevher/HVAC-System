import numpy as np
from robkit import fk_poe, space_jacobian, homog, skew
np.set_printoptions(precision=5, suppress=True)

l1, l2 = 0.2, 0.2
def screw(w, qp): w = np.array(w, float); return np.concatenate([w, -np.cross(w, qp)])
Slist = [screw([1, 0, 0], [0, 0, 0]), screw([0, 1, 0], [0, 0, 0]), screw([0, 1, 0], [0, 0, -l1])]
M = homog(np.eye(3), [0, 0, -l1 - l2])
foot = lambda q: fk_poe(Slist, M, q)[:3, 3]
def Jp(q): Js = space_jacobian(Slist, q); return Js[3:] - skew(foot(q))@Js[:3]

def ik_analytic(p, knee_sign=+1):
    """Kapalı form IK. p = ayak konumu (kalça çerçevesi). knee_sign=+1: diz öne bükük (q3>0)."""
    x, y, z = p
    q1 = np.arctan2(y, -z)                               # roll: y-z düzleminde bacağı hizala
    zs = -np.hypot(y, z)                                 # roll sonrası sagital düzlemde ayak yüksekliği
    D = (x*x + zs*zs - l1*l1 - l2*l2)/(2*l1*l2)          # kosinüs teoremi
    if abs(D) > 1:
        raise ValueError(f"ulaşılamaz hedef: |p| = {np.linalg.norm(p):.4f} > {l1 + l2}")
    q3 = knee_sign*np.arccos(D)
    q2 = np.arctan2(-x, -zs) - np.arctan2(l2*np.sin(q3), l1 + l2*np.cos(q3))
    return np.array([q1, q2, q3])

def ik_numeric(p, q0, lam=0.0, iters=100, tol=1e-10):
    """Newton (lam=0) veya sönümlü en küçük kareler (lam>0) ile sayısal IK"""
    q = np.array(q0, float)
    for k in range(iters):
        e = p - foot(q)
        if np.linalg.norm(e) < tol: return q, k, np.linalg.norm(e)
        J = Jp(q)
        dq = J.T@np.linalg.solve(J@J.T + lam**2*np.eye(3), e) if lam > 0 else np.linalg.lstsq(J, e, rcond=None)[0]
        q = q + dq
    return q, iters, np.linalg.norm(p - foot(q))

# (1) Analitik IK: rastgele (ama tekrar üretilebilir) 1000 hedef
rng = np.random.default_rng(0); errs = []
for _ in range(1000):
    qt = np.array([rng.uniform(-0.4, 0.4), rng.uniform(-1.2, 0.6), rng.uniform(0.05, 2.2)])
    errs.append(np.linalg.norm(foot(ik_analytic(foot(qt))) - foot(qt)))
print(f"analitik IK, 1000 rastgele hedef: max konum hatası {max(errs):.2e} m")
p = np.array([0.05, 0.03, -0.33])
qa, qb = ik_analytic(p, +1), ik_analytic(p, -1)
print("hedef", p, "-> diz öne:", qa, " diz arkaya:", qb, " (iki çözüm)")
print("  FK kontrol:", foot(qa), foot(qb))

# (2) Sayısal IK: Newton vs DLS
for name, lam in [("Newton (pinv)", 0.0), ("DLS λ=0.01", 0.01), ("DLS λ=0.05", 0.05)]:
    q, k, e = ik_numeric(p, [0, -0.2, 0.4], lam=lam)
    print(f"{name:>14}: {k:3d} iterasyon, hata {e:.1e}, q = {q}")
# Ulaşılamaz hedef (bacak boyu 0.4 m, hedef 0.45 m uzakta)
pf = np.array([0.1, 0.0, -0.4387])
print(f"\nulaşılamaz hedef |p| = {np.linalg.norm(pf):.4f} m:")
for name, lam in [("Newton (pinv)", 0.0), ("DLS λ=0.05", 0.05)]:
    q, k, e = ik_numeric(pf, [0, -0.2, 0.4], lam=lam, iters=100)
    print(f"{name:>14}: 100 iterasyon sonra hata {e:.4f} m, |q| = {np.linalg.norm(q):.2f}, diz = {q[2]:.4f} rad")
try: ik_analytic(pf)
except ValueError as ex: print("analitik IK:", ex)

# (3) SB-1 için: ayak yerde sabit, kalça 5 cm alçalıp 3 cm öne gidiyor (çömelme + öne kayma)
t = np.linspace(0, 1, 6); p0 = np.array([0.0, 0.0, -0.38])
print("\nçömelme yörüngesi (ayak kalça çerçevesinde; kalça aşağı/öne gidince ayak göreli olarak yukarı/geri gider):")
for ti in t:
    s = 3*ti**2 - 2*ti**3                                 # yumuşak başlangıç/bitiş (kübik)
    pt = p0 + np.array([-0.03*s, 0, 0.05*s]); qt = ik_analytic(pt)
    print(f"  t={ti:.1f}: ayak {pt.round(4)} -> q = {qt.round(4)}")

# %% plot
from figstyle import plt, save
tt = np.linspace(0, 1, 101); Q = np.array([ik_analytic(p0 + np.array([-0.03*(3*a**2-2*a**3), 0, 0.05*(3*a**2-2*a**3)])) for a in tt])
fig, ax = plt.subplots(1, 2, figsize=(8.0, 3.2))
ax[0].plot(tt, Q[:, 1], label="kalça pitch"); ax[0].plot(tt, Q[:, 2], label="diz"); ax[0].set_xlabel("t (normalize)"); ax[0].set_ylabel("açı [rad]"); ax[0].set_title("Çömelme: eklem yörüngeleri"); ax[0].legend(fontsize=7)
hist = {}
for name, lam in [("Newton", 0.0), ("DLS λ=0.05", 0.05)]:
    q = np.array([0, -0.2, 0.4]); h = []
    for k in range(40):
        e = pf - foot(q); h.append(np.linalg.norm(e)); J = Jp(q)
        q = q + (J.T@np.linalg.solve(J@J.T + lam**2*np.eye(3), e) if lam > 0 else np.linalg.lstsq(J, e, rcond=None)[0])
    ax[1].semilogy(h, label=name)
ax[1].axhline(np.linalg.norm(pf) - 0.4, c="k", ls="--", lw=1, label="ulaşılabilir en iyi (0.05 m)")
ax[1].set_xlabel("iterasyon"); ax[1].set_ylabel("|hata| [m]"); ax[1].set_title("Ulaşılamaz hedef"); ax[1].legend(fontsize=7)
save("c05_ik")
