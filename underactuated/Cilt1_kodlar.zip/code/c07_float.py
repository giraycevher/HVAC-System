import numpy as np
np.set_printoptions(precision=4, suppress=True)
g = 9.81
# Düzlemsel tek bacaklı "SB-1 yarısı": gövde + uyluk + baldır + ayak. Genelleştirilmiş koordinatlar:
# q = [x, z, θ_b | q_kalça, q_diz, q_bilek]  (ilk 3: yüzen taban, aktüatörsüz; son 3: motorlu eklemler)
m_t, m_th, m_sh, m_ft = 1.2, 0.3, 0.2, 0.1                   # kütleler [kg]
L_t, L_th, L_sh = 0.30, 0.20, 0.20; HEEL, TOE, FCOM = -0.03, 0.07, 0.02
I_t, I_th, I_sh, I_ft = m_t*L_t**2/12, m_th*L_th**2/12, m_sh*L_sh**2/12, m_ft*0.10**2/12
down = lambda p: np.array([np.sin(p), -np.cos(p)])          # bacak uzvu yönü (φ=0: aşağı)
fwd = lambda p: np.array([np.cos(p), np.sin(p)])            # ayak yönü (φ=0: yatay ileri)

def bodies(q):
    """Her cisim için (kütle, atalet, kütle merkezi konumu, mutlak açı) ve temas noktaları"""
    x, z, th = q[:3]; hip = np.array([x, z])
    ph1 = th + q[3]; ph2 = ph1 + q[4]; ph3 = ph2 + q[5]
    knee = hip + L_th*down(ph1); ankle = knee + L_sh*down(ph2)
    B = [(m_t, I_t, hip + 0.5*L_t*np.array([-np.sin(th), np.cos(th)]), th),
         (m_th, I_th, hip + 0.5*L_th*down(ph1), ph1),
         (m_sh, I_sh, knee + 0.5*L_sh*down(ph2), ph2),
         (m_ft, I_ft, ankle + FCOM*fwd(ph3), ph3)]
    contacts = [ankle + HEEL*fwd(ph3), ankle + TOE*fwd(ph3)]
    return B, contacts

def jac(fun, q, h=1e-7):
    """f(q)'nin q'ya göre Jacobian'ı (merkezi sonlu fark). f vektör döndürür."""
    return np.column_stack([(fun(q + h*e) - fun(q - h*e))/(2*h) for e in np.eye(len(q))])

def mass_matrix(q):
    """M = Σ m J_vᵀJ_v + I J_ωᵀJ_ω  (her cismin kütle merkezi doğrusal ve açısal hız Jacobian'ları)"""
    M = np.zeros((6, 6))
    for k in range(4):
        Jv = jac(lambda s: bodies(s)[0][k][2], q); Jw = jac(lambda s: np.array([bodies(s)[0][k][3]]), q)
        m, I = bodies(q)[0][k][:2]; M += m*Jv.T@Jv + I*Jw.T@Jw
    return M
def potential(q): return sum(b[0]*g*b[2][1] for b in bodies(q)[0])
def gravity(q): return jac(lambda s: np.array([potential(s)]), q)[0]                # g(q) = ∂V/∂q
def Jc(q): return jac(lambda s: np.concatenate([bodies(s)[1][0], bodies(s)[1][1][1:]]), q)   # 3x6: topuk (x,z), burun (z)
# Not: burun x'i eklemek 4. bir kısıt olurdu ama rijit ayakta topuk-burun mesafesi sabit -> bağımlı (rank 3), KKT tekil olur
def com(q): B = bodies(q)[0]; return sum(b[0]*b[2] for b in B)/sum(b[0] for b in B)
def bias(q, qd, h=1e-6):
    """h(q,q̇) = C q̇ + g = Ṁq̇ - ½ ∂(q̇ᵀMq̇)/∂q + g  (sonlu farklarla)"""
    Md = (mass_matrix(q + h*qd) - mass_matrix(q - h*qd))/(2*h)
    dT = np.array([(qd@mass_matrix(q + h*e)@qd - qd@mass_matrix(q - h*e)@qd)/(2*h) for e in np.eye(6)])
    return Md@qd - 0.5*dT + gravity(q)

def standing_q(th_b, q_hip, q_knee):
    """Ayak tabanı yere paralel ve zeminde (z=0), ayak bileği x=0 olacak şekilde taban konumunu hesapla"""
    q_ank = -(th_b + q_hip + q_knee); q = np.array([0, 0, th_b, q_hip, q_knee, q_ank])
    ankle = bodies(q)[1][0] - HEEL*fwd(0.0); q[0] -= ankle[0]; q[1] -= ankle[1]; return q

S = np.hstack([np.zeros((3, 3)), np.eye(3)])                  # seçim matrisi: τ sadece son 3 koordinata etki eder
mtot = m_t + m_th + m_sh + m_ft
for label, (thb, qh, qk) in [("dik duruş", (0.0, -0.3, 0.6)), ("gövde geriye eğik θ_b=+0.35", (0.35, -0.3, 0.6)), ("gövde öne eğik θ_b=-0.35", (-0.35, -0.3, 0.6))]:
    q = standing_q(thb, qh, qk); M = mass_matrix(q); G = gravity(q); J = Jc(q); c = com(q)
    if label == "dik duruş":
        print("M (6x6) =\n", M); print(f"M[0,0] = M[1,1] = toplam kütle? {M[0,0]:.4f}, {M[1,1]:.4f} (gerçek {mtot})")
        print("g(q) =", G, f"  g_z = {G[1]:.4f} = m_toplam·g = {mtot*g:.4f}")
    # Statik denge: g(q) = Sᵀτ + Jcᵀλ.  İlk 3 satır (taban) τ içermez: g_base = Jc_baseᵀ λ  (underactuation!)
    Jb = J[:, :3].T                                             # 3x3
    lam = np.linalg.solve(Jb, G[:3])                            # λ = [topuk_x, topuk_z, burun_z]: 3 denklem, 3 bilinmeyen
    tau = G[3:] - J[:, 3:].T@lam
    heel, toe = bodies(q)[1]; Fz = lam[1] + lam[2]; cop = (heel[0]*lam[1] + toe[0]*lam[2])/Fz
    ok = lam[1] >= 0 and lam[2] >= 0
    print(f"\n{label}: KM x = {c[0]:+.4f} m, destek [{heel[0]:+.3f}, {toe[0]:+.3f}] m;  λ_z topuk = {lam[1]:+.3f} N, burun = {lam[2]:+.3f} N, Σ = {Fz:.3f} N, λ_x = {lam[0]:+.3f} N")
    print(f"   CoP (basınç merkezi) x = {cop:+.4f} m  (statikte = KM x)  ->  {'DENGEDE (iki kuvvet de iter)' if ok else 'İMKANSIZ: bir temas yeri ÇEKMEK zorunda -> robot devrilir'}")
    print(f"   eklem torkları τ = {tau} N·m")

# Dinamik kontrol: dik duruş torklarını uygula, temas kısıtlı ileri dinamik (KKT) ile 0.3 s simüle et
q = standing_q(0.0, -0.3, 0.6); G = gravity(q); J = Jc(q); lam0 = np.linalg.solve(J[:, :3].T, G[:3]); tau0 = G[3:] - J[:, 3:].T@lam0
def kkt(q, qd, tau):
    M = mass_matrix(q); J = Jc(q); h = bias(q, qd); hh = 1e-6
    Jdqd = (Jc(q + hh*qd) - Jc(q - hh*qd))/(2*hh)@qd           # J̇ q̇
    K = np.block([[M, -J.T], [J, np.zeros((3, 3))]]); rhs = np.concatenate([S.T@tau - h, -Jdqd])
    sol = np.linalg.solve(K, rhs); return sol[:6], sol[6:]
for name, dtau in [("denge torkları", np.zeros(3)), ("kalçaya +0.4 N·m fazla", np.array([0.4, 0, 0]))]:
    qq, qd = q.copy(), np.zeros(6); dt = 0.002; first_neg = None
    for k in range(150):
        qdd, lam = kkt(qq, qd, tau0 + dtau)
        if first_neg is None and min(lam[1], lam[2]) < 0: first_neg = k*dt
        qd = qd + dt*qdd; qq = qq + dt*qd
    print(f"\nKKT simülasyonu ({name}), 0.3 s: gövde açısı {qq[2]:+.4f} rad, λ_z (topuk, burun) = ({lam[1]:+.3f}, {lam[2]:+.3f}) N; "
          + ("temas kuvvetleri hep ≥ 0" if first_neg is None else f"t = {first_neg:.3f} s'de bir λ_z < 0: gerçekte ayak burada kalkardı"))
