import numpy as np, time
np.set_printoptions(precision=5, suppress=True)
g = 9.81

# (1) Atalet: kutu şeklinde uyluk (0.04 x 0.04 x 0.20 m, 0.30 kg), kütle merkezi etrafında ve kalça eksenine göre
m, a, b, c = 0.30, 0.04, 0.04, 0.20                      # kütle, x, y, z boyutları
Ic = m/12*np.diag([b*b + c*c, a*a + c*c, a*a + b*b])     # kutu: I_xx = m(b²+c²)/12, ...
r = np.array([0, 0, -0.10])                              # kalça -> kütle merkezi
Ihip = Ic + m*(r@r*np.eye(3) - np.outer(r, r))           # paralel eksen (Steiner) teoremi, tensör hali
print("uyluk kütle merkezinde I_c =", np.diag(Ic), " kg·m²;  kalçada I =", np.diag(Ihip))
print(f"kontrol: ince çubuk yaklaşımı I_y(kalça) = m l²/3 = {m*c*c/3:.6f} (kutu: {Ihip[1,1]:.6f})")

# (2) Düzlemsel 2-uzuvlu bacak (kalça sabit): Lagrange ile kapalı form M, C, g
L = np.array([0.2, 0.2]); ms = np.array([0.30, 0.20]); lc = L/2; Is = ms*L**2/12      # düzgün çubuklar
def M_closed(q):
    c2 = np.cos(q[1]); m11 = Is[0] + Is[1] + ms[0]*lc[0]**2 + ms[1]*(L[0]**2 + lc[1]**2 + 2*L[0]*lc[1]*c2)
    m12 = Is[1] + ms[1]*(lc[1]**2 + L[0]*lc[1]*c2); m22 = Is[1] + ms[1]*lc[1]**2
    return np.array([[m11, m12], [m12, m22]])
def C_closed(q, qd):
    h = -ms[1]*L[0]*lc[1]*np.sin(q[1])
    return np.array([[h*qd[1], h*(qd[0] + qd[1])], [-h*qd[0], 0.0]])
def g_closed(q):
    return np.array([ms[0]*g*lc[0]*np.sin(q[0]) + ms[1]*g*(L[0]*np.sin(q[0]) + lc[1]*np.sin(q[0] + q[1])),
                     ms[1]*g*lc[1]*np.sin(q[0] + q[1])])

# (3) RNEA: düzlemsel, n uzuvlu seri zincir (açılar dikey-aşağıdan; x = Σ l sin a, z = -Σ l cos a)
def rnea(q, qd, qdd, grav=g):
    n = len(q); a = np.cumsum(q); w = np.cumsum(qd); al = np.cumsum(qdd)
    u = np.column_stack([np.sin(a), -np.cos(a)])                 # uzuv yön vektörleri
    perp = lambda v: np.array([-v[1], v[0]])                     # z-ekseni etrafında 90°: ω x r (düzlemde)
    acc_p = np.array([0.0, grav])                                # yerçekimi hilesi: tabanı +g ile yukarı ivmelendir
    ac = []; ap = [acc_p]
    for i in range(n):                                           # ileri geçiş: hız/ivmeler
        rc = lc[i]*u[i]; rl = L[i]*u[i]
        ac.append(ap[i] + al[i]*perp(rc) - w[i]**2*rc)            # kütle merkezi ivmesi
        ap.append(ap[i] + al[i]*perp(rl) - w[i]**2*rl)            # bir sonraki eklemin ivmesi
    tau = np.zeros(n); f_next = np.zeros(2); n_next = 0.0
    cross = lambda r_, f_: r_[0]*f_[1] - r_[1]*f_[0]
    for i in reversed(range(n)):                                 # geri geçiş: kuvvet/momentler
        f = ms[i]*ac[i] + f_next
        nm = Is[i]*al[i] + cross(lc[i]*u[i], ms[i]*ac[i]) + n_next + cross(L[i]*u[i], f_next)
        tau[i] = nm; f_next, n_next = f, nm
    return tau

rng = np.random.default_rng(1); mx = 0
for _ in range(100):
    q, qd, qdd = rng.normal(size=2), rng.normal(size=2), rng.normal(size=2)
    tau_l = M_closed(q)@qdd + C_closed(q, qd)@qd + g_closed(q)
    mx = max(mx, np.abs(rnea(q, qd, qdd) - tau_l).max())
print(f"\nRNEA vs Lagrange (100 rastgele durum): max tork farkı {mx:.2e} N·m")
q = np.array([0.4, 0.7]); qd = np.array([1.0, -2.0])
Mr = np.column_stack([rnea(q, np.zeros(2), e, grav=0) for e in np.eye(2)])       # CRBA'nın en basit hali: M'nin sütunları
print("M (RNEA sütunlarıyla) =\n", Mr, "\nM (kapalı form) =\n", M_closed(q))
print("g(q) = RNEA(q,0,0) =", rnea(q, np.zeros(2), np.zeros(2)), " kapalı form:", g_closed(q))
hq = 1e-6; Mdot = (M_closed(q + hq*qd) - M_closed(q - hq*qd))/(2*hq); N = Mdot - 2*C_closed(q, qd)
print("Ṁ - 2C ters simetrik mi? (N + Nᵀ) max:", np.abs(N + N.T).max())

# (4) İleri dinamik ve integratörler: serbest salınan bacak (τ = 0), enerji korunumu
def fwd(q, qd, tau): return np.linalg.solve(M_closed(q), tau - rnea(q, qd, np.zeros(2)))     # q̈ = M⁻¹(τ - h)
def energy(q, qd):
    a = np.cumsum(q); z1 = -lc[0]*np.cos(a[0]); z2 = -L[0]*np.cos(a[0]) - lc[1]*np.cos(a[1])
    return 0.5*qd@M_closed(q)@qd + g*(ms[0]*z1 + ms[1]*z2)
def simulate(method, dt, T=10.0):
    q, qd = np.array([1.2, 0.5]), np.zeros(2); E0 = energy(q, qd)
    for _ in range(int(round(T/dt))):
        if method == "euler":
            qdd = fwd(q, qd, 0); q, qd = q + dt*qd, qd + dt*qdd
        elif method == "semi":
            qd = qd + dt*fwd(q, qd, 0); q = q + dt*qd
        else:
            f = lambda s: np.concatenate([s[2:], fwd(s[:2], s[2:], 0)]); s = np.concatenate([q, qd])
            k1 = f(s); k2 = f(s + dt/2*k1); k3 = f(s + dt/2*k2); k4 = f(s + dt*k3); s = s + dt/6*(k1 + 2*k2 + 2*k3 + k4); q, qd = s[:2], s[2:]
    return energy(q, qd) - E0
print("\nserbest bacak, q0=(1.2, 0.5), 10 s, enerji hatası [J] (başlangıç enerjisi", round(energy(np.array([1.2, .5]), np.zeros(2)), 5), "J):")
for dt in [1e-3, 1e-4]:
    print(f"  dt={dt:.0e}: açık Euler {simulate('euler', dt):+.3e}, yarı-örtük Euler {simulate('semi', dt):+.3e}, RK4 {simulate('rk4', dt):+.3e}")

# (5) Hız: RNEA çağrısı başına süre
q, qd, qdd = np.array([0.3, 0.4]), np.array([0.1, 0.2]), np.array([0.5, 0.6]); n_call = 20000
t0 = time.perf_counter()
for _ in range(n_call): rnea(q, qd, qdd)
print(f"\nPython RNEA (2 uzuv): {1e6*(time.perf_counter() - t0)/n_call:.1f} µs/çağrı")
