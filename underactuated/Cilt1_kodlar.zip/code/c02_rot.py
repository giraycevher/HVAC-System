import numpy as np
from robkit import (skew, exp_so3, log_so3, rpy_to_R, R_to_rpy, quat_mul, quat_to_R, R_to_quat, quat_exp)
np.set_printoptions(precision=5, suppress=True)

# (1) Gösterimler arası dönüşüm ve tutarlılık
rpy = np.array([0.1, 0.2, 0.3])                                  # roll, pitch, yaw [rad]
R = rpy_to_R(*rpy)
print("R =\n", R)
print("RᵀR - I  max:", np.abs(R.T@R - np.eye(3)).max(), "  det R =", np.linalg.det(R))
q = R_to_quat(R); w = log_so3(R)
print("kuaterniyon [w x y z] =", q, " |q| =", np.linalg.norm(q))
print("eksen-açı: açı =", np.linalg.norm(w), "rad, eksen =", w/np.linalg.norm(w))
print("geri dönüşüm hataları: quat->R", np.abs(quat_to_R(q) - R).max(), " exp(log R)", np.abs(exp_so3(w) - R).max(), " R->rpy", np.abs(R_to_rpy(R) - rpy).max())
print("-q aynı dönmeyi verir mi?", np.allclose(quat_to_R(-q), R), "(çift örtü: q ve -q)")

# (2) Gimbal lock: pitch = 90 derecede roll ve yaw ayırt edilemez
Ra = rpy_to_R(0.3, np.pi/2, 0.5); Rb = rpy_to_R(0.1, np.pi/2, 0.3); Rc = rpy_to_R(0.0, np.pi/2, 0.8)
print(f"\ngimbal lock: |R(0.3,90°,0.5) - R(0.1,90°,0.3)| = {np.abs(Ra-Rb).max():.1e}  (aynı!),  |R(0.3,90°,0.5) - R(0,90°,0.8)| = {np.abs(Ra-Rc).max():.3f}")
E = 1e-10*np.array([[0, 0, 0], [0, 0, 0], [0, 1, -1]])               # 1e-10 mertebesinde ölçüm/yuvarlama hatası
print("  pitch=90°'de R sadece (yaw - roll)'a bağlı. R->rpy:", R_to_rpy(Ra), " ama R'ye 1e-10 gürültü eklenince:", R_to_rpy(Ra + E))

# (3) Sabit gövde açısal hızıyla yönelim integrasyonu: Ṙ = R [ω]
wb = np.array([0.5, -0.3, 1.0]); dt, T = 0.01, 10.0; N = int(T/dt)
R_true = exp_so3(wb*T)                                             # sabit ω için kesin çözüm
R_eu = np.eye(3); R_ex = np.eye(3); q_n = np.array([1.0, 0, 0, 0]); q_u = q_n.copy()
for k in range(N):
    R_eu = R_eu + R_eu@skew(wb)*dt                                 # naif Euler: SO(3)'ten çıkar
    R_ex = R_ex@exp_so3(wb*dt)                                     # grup üzerinde (geometrik) integrasyon
    q_u = q_u + 0.5*quat_mul(q_u, np.array([0, *wb]))*dt           # kuaterniyon Euler, normalize ETMEDEN
    q_n = q_n + 0.5*quat_mul(q_n, np.array([0, *wb]))*dt; q_n /= np.linalg.norm(q_n)   # ... normalize EDEREK
ang_err = lambda Ra: np.linalg.norm(log_so3(Ra.T@R_true))
orth = lambda Ra: np.abs(Ra.T@Ra - np.eye(3)).max()
print(f"\n10 s, dt=0.01, ω={wb}:")
print(f"  naif Euler R:          açı hatası {ang_err(R_eu):.2e} rad*, ortogonallik hatası {orth(R_eu):.2e}")
print(f"  exp ile (geometrik):   açı hatası {ang_err(R_ex):.2e} rad,  ortogonallik hatası {orth(R_ex):.2e}")
print(f"  kuaterniyon, normsuz:  |q| = {np.linalg.norm(q_u):.5f}, açı hatası {ang_err(quat_to_R(q_u)):.2e} rad (quat_to_R normalize ediyor)")
print(f"  kuaterniyon, normlu:   |q| = {np.linalg.norm(q_n):.5f}, açı hatası {ang_err(quat_to_R(q_n)):.2e} rad")
U, s, Vt = np.linalg.svd(R_eu); print(f"  * naif Euler matrisi artık bir dönme değil: tekil değerleri {s.round(4)} (hepsi 1 olmalı); log'u anlamsız")

# (4) İki yönelim arasında ara değer: slerp vs normalize edilmiş lineer
qa = R_to_quat(rpy_to_R(0, 0, 0)); qb = R_to_quat(rpy_to_R(0.0, 0.0, 2.5))
def slerp(a, b, t):
    c = np.clip(a@b, -1, 1); th = np.arccos(c)
    return (np.sin((1-t)*th)*a + np.sin(t*th)*b)/np.sin(th)
ts = np.linspace(0, 1, 11)
ang = lambda qq: 2*np.arccos(np.clip(abs(qq[0]), -1, 1))
d_sl = np.diff([ang(slerp(qa, qb, t)) for t in ts]); d_ln = np.diff([ang(((1-t)*qa + t*qb)/np.linalg.norm((1-t)*qa + t*qb)) for t in ts])
print(f"\n0'dan 2.5 rad'a yaw geçişi, 10 eşit adım: slerp adımları {d_sl.min():.4f}..{d_sl.max():.4f} rad (sabit), normalize-lineer adımları {d_ln.min():.4f}..{d_ln.max():.4f} rad (değişken)")
