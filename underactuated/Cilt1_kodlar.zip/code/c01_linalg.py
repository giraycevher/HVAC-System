import numpy as np
np.set_printoptions(precision=4, suppress=True)

# Düzlemsel 3 uzuvlu bacak (uyluk, baldır, ayak): eklem açıları q = [kalça, diz, ayak bileği]
# Açılar dikey-aşağı yönden ölçülür: ayak ucu  x = Σ L_k sin(a_k),  z = -Σ L_k cos(a_k),  a_k = q1+...+qk
L = np.array([0.20, 0.20, 0.08])                       # uzuv boyları [m]
def foot_jacobian(q):
    """Ayak ucunun (x, z) hızını eklem hızlarına bağlayan 2x3 Jacobian: v = J q̇"""
    a = np.cumsum(q)                                    # mutlak açılar: q1, q1+q2, q1+q2+q3
    J = np.zeros((2, 3))
    for i in range(3):                                  # i. eklem, kendisinden sonraki tüm uzuvları döndürür
        J[0, i] = sum(L[k]*np.cos(a[k]) for k in range(i, 3))     # dx/dq_i
        J[1, i] = sum(L[k]*np.sin(a[k]) for k in range(i, 3))     # dz/dq_i  (açı dikeyden ölçülüyor)
    return J

q = np.array([0.3, -0.6, 0.4])
J = foot_jacobian(q)
print("J =\n", J)
U, s, Vt = np.linalg.svd(J)                            # J = U diag(s) V^T
print("tekil değerler:", s, " rank:", np.sum(s > 1e-10), " koşul sayısı:", round(s[0]/s[-1], 3))
n = Vt[-1]                                              # V'nin son satırı: null uzayı (2x3 matriste 1 boyutlu)
print("null uzayı vektörü n =", n, "  J n =", J@n, "  (sıfır olmalı)")

# Ters hız problemi: ayak ucu v = (0.1, 0) m/s ile hareket etsin
v = np.array([0.1, 0.0])
qd_pinv = np.linalg.pinv(J)@v                           # en küçük normlu çözüm
qd_null = qd_pinv + 0.5*n                               # null uzayından eklenen hareket
print("pinv çözüm  q̇ =", qd_pinv, " |q̇| =", round(np.linalg.norm(qd_pinv), 4), " J q̇ =", J@qd_pinv)
print("+0.5 n      q̇ =", qd_null, " |q̇| =", round(np.linalg.norm(qd_null), 4), " J q̇ =", J@qd_null, " (aynı ayak hızı, farklı duruş)")

# Tekillik: diz düz (q2 = 0) iken 2 uzuvlu bacak, ayak eksen boyunca hareket edemez
def J2(q1, q2):
    return np.array([[L[0]*np.cos(q1) + L[1]*np.cos(q1 + q2), L[1]*np.cos(q1 + q2)],
                     [L[0]*np.sin(q1) + L[1]*np.sin(q1 + q2), L[1]*np.sin(q1 + q2)]])
print("\n2 uzuvlu bacak, diz açısı -> tekil değerler ve pinv ile gereken eklem hızı (ayak bacak boyunca 0.1 m/s kısalsın)")
for q2 in [-1.0, -0.3, -0.1, -0.01, 0.0]:
    Jq = J2(0.0, q2); s2 = np.linalg.svd(Jq, compute_uv=False)
    vdir = np.array([0.0, 0.1])                                                   # ayak kalçaya doğru (yukarı) 0.1 m/s: bacağı kısalt
    qd_p = np.linalg.pinv(Jq, rcond=1e-15)@vdir
    lam = 0.01; qd_d = Jq.T@np.linalg.solve(Jq@Jq.T + lam**2*np.eye(2), vdir)      # sönümlü en küçük kareler (DLS)
    print(f"  q2={q2:6.2f}: σ = {s2.round(5)}, |q̇| pinv = {np.linalg.norm(qd_p):10.4f} (hız hatası {np.linalg.norm(Jq@qd_p - vdir):.4f}), |q̇| DLS = {np.linalg.norm(qd_d):7.4f}, DLS hız hatası = {np.linalg.norm(Jq@qd_d - vdir):.4f}")

# En küçük kareler: servo kalibrasyonu (PWM darbe genişliği [µs] -> ölçülen açı [derece])
pwm = np.arange(1000.0, 2001.0, 100.0)
noise = 0.8*np.sin(7.3*np.arange(len(pwm)))             # tekrar üretilebilir "gürültü" (C++ ile aynı veri)
angle = 0.09*(pwm - 1500.0) + 2.0 + noise               # gerçek: 0.09 derece/µs, 2 derece ofset
A = np.column_stack([pwm - 1500.0, np.ones_like(pwm)])
x, res, rank, sv = np.linalg.lstsq(A, angle, rcond=None)
print(f"\nservo kalibrasyonu: eğim = {x[0]:.5f} derece/µs, ofset = {x[1]:.4f} derece, RMS artık = {np.sqrt(res[0]/len(pwm)):.4f} derece")
x_ne = np.linalg.solve(A.T@A, A.T@angle)               # normal denklemler (aynı sonuç, daha kötü koşullu)
print(f"normal denklemlerle: {x_ne.round(5)};  cond(A) = {np.linalg.cond(A):.1f}, cond(AᵀA) = {np.linalg.cond(A.T@A):.1f} (karesi)")

# Kötü koşullu sistem: Hilbert matrisi
for n_ in [6, 10, 12]:
    H = np.array([[1.0/(i + j + 1) for j in range(n_)] for i in range(n_)]); xt = np.ones(n_); b = H@xt
    e_solve = np.linalg.norm(np.linalg.solve(H, b) - xt); e_inv = np.linalg.norm(np.linalg.inv(H)@b - xt)
    print(f"Hilbert n={n_:2d}: cond = {np.linalg.cond(H):.2e}, hata solve = {e_solve:.1e}, hata inv = {e_inv:.1e}")
