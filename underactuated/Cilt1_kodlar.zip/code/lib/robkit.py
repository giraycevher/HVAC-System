"""robkit.py — Cilt 1 boyunca büyüyen küçük kinematik kütüphanesi (C++ karşılığı: robkit.hpp).
Konvansiyonlar: kuaterniyon q = [w, x, y, z] (Hamilton, MuJoCo ile aynı); RPY = ZYX: R = Rz(yaw) Ry(pitch) Rx(roll);
twist/vida ekseni S = [ω; v] (önce açısal, sonra doğrusal; Modern Robotics ile aynı)."""
import numpy as np

# ---------------- SO(3) ----------------
def skew(w):
    """w x (.) çapraz çarpım matrisi: skew(w) @ p == np.cross(w, p)"""
    return np.array([[0, -w[2], w[1]], [w[2], 0, -w[0]], [-w[1], w[0], 0]])

def unskew(S):
    return np.array([S[2, 1], S[0, 2], S[1, 0]])

def exp_so3(w):
    """Rodrigues: R = exp([w]) ; |w| = dönme açısı, w/|w| = eksen"""
    th = np.linalg.norm(w)
    if th < 1e-12:
        return np.eye(3) + skew(w)                       # birinci dereceden yaklaşım
    K = skew(w/th)
    return np.eye(3) + np.sin(th)*K + (1 - np.cos(th))*K@K

def log_so3(R):
    """R -> w (eksen*açı), açı [0, pi]"""
    c = np.clip((np.trace(R) - 1)/2, -1.0, 1.0); th = np.arccos(c)
    if th < 1e-9:
        return unskew(R - R.T)/2
    if np.pi - th < 1e-6:                                # 180 derece civarı: sin ~ 0, ayrı formül
        k = np.argmax(np.diag(R)); a = np.sqrt(max((R[k, k] + 1)/2, 0.0)); w = R[:, k]/(2*a); w[k] = a
        return th*w/np.linalg.norm(w)
    return th/(2*np.sin(th))*unskew(R - R.T)

def rot_x(a): c, s = np.cos(a), np.sin(a); return np.array([[1, 0, 0], [0, c, -s], [0, s, c]])
def rot_y(a): c, s = np.cos(a), np.sin(a); return np.array([[c, 0, s], [0, 1, 0], [-s, 0, c]])
def rot_z(a): c, s = np.cos(a), np.sin(a); return np.array([[c, -s, 0], [s, c, 0], [0, 0, 1]])

def rpy_to_R(roll, pitch, yaw):
    return rot_z(yaw)@rot_y(pitch)@rot_x(roll)

def R_to_rpy(R):
    pitch = np.arcsin(np.clip(-R[2, 0], -1.0, 1.0))
    return np.array([np.arctan2(R[2, 1], R[2, 2]), pitch, np.arctan2(R[1, 0], R[0, 0])])

# ---------------- Kuaterniyon [w, x, y, z] ----------------
def quat_mul(a, b):
    w1, v1 = a[0], a[1:]; w2, v2 = b[0], b[1:]
    return np.concatenate([[w1*w2 - v1@v2], w1*v2 + w2*v1 + np.cross(v1, v2)])

def quat_to_R(q):
    w, x, y, z = q/np.linalg.norm(q)
    return np.array([[1 - 2*(y*y + z*z), 2*(x*y - w*z), 2*(x*z + w*y)],
                     [2*(x*y + w*z), 1 - 2*(x*x + z*z), 2*(y*z - w*x)],
                     [2*(x*z - w*y), 2*(y*z + w*x), 1 - 2*(x*x + y*y)]])

def R_to_quat(R):
    """Shepperd yöntemi: en büyük bileşenden başla (sayısal kararlılık); w >= 0 seçilir"""
    t = np.trace(R)
    if t > 0:
        s = 2*np.sqrt(t + 1); q = np.array([s/4, (R[2, 1] - R[1, 2])/s, (R[0, 2] - R[2, 0])/s, (R[1, 0] - R[0, 1])/s])
    else:
        i = np.argmax(np.diag(R)); j, k = (i + 1) % 3, (i + 2) % 3
        s = 2*np.sqrt(1 + R[i, i] - R[j, j] - R[k, k]); q = np.zeros(4)
        q[0] = (R[k, j] - R[j, k])/s; q[1 + i] = s/4; q[1 + j] = (R[j, i] + R[i, j])/s; q[1 + k] = (R[k, i] + R[i, k])/s
    return q if q[0] >= 0 else -q

def quat_exp(w):
    """exp(w/2) kuaterniyonu: |w| açısı kadar w ekseni etrafında dönme"""
    th = np.linalg.norm(w)
    if th < 1e-12:
        return np.array([1.0, *(w/2)])
    return np.concatenate([[np.cos(th/2)], np.sin(th/2)*w/th])

# ---------------- SE(3) ----------------
def homog(R, p):
    T = np.eye(4); T[:3, :3] = R; T[:3, 3] = p; return T

def inv_T(T):
    R, p = T[:3, :3], T[:3, 3]; return homog(R.T, -R.T@p)

def exp_se3(S, th):
    """Vida ekseni S=[ω; v] etrafında th kadar hareket: e^{[S] th} (Modern Robotics 3.88)"""
    w, v = S[:3], S[3:]
    if np.linalg.norm(w) < 1e-12:                        # saf öteleme (prizmatik)
        return homog(np.eye(3), v*th)
    K = skew(w); R = exp_so3(w*th)
    G = np.eye(3)*th + (1 - np.cos(th))*K + (th - np.sin(th))*K@K
    return homog(R, G@v)

def adjoint(T):
    """6x6 Ad_T: bir twist'i {b}'den {s}'ye taşır: V_s = Ad_T V_b"""
    R, p = T[:3, :3], T[:3, 3]; A = np.zeros((6, 6))
    A[:3, :3] = R; A[3:, 3:] = R; A[3:, :3] = skew(p)@R
    return A

# ---------------- Seri zincir (çarpımların üsteli, PoE) ----------------
def fk_poe(Slist, M, q):
    """T(q) = e^{[S1]q1} ... e^{[Sn]qn} M   (uzay çerçevesinde vida eksenleri)"""
    T = np.eye(4)
    for S, qi in zip(Slist, q):
        T = T@exp_se3(S, qi)
    return T@M

def space_jacobian(Slist, q):
    """J_s sütun i = Ad_{e^{[S1]q1}...e^{[S_{i-1}]q_{i-1}}} S_i  (6 x n, satırlar [ω; v])"""
    n = len(q); J = np.zeros((6, n)); T = np.eye(4)
    for i in range(n):
        J[:, i] = adjoint(T)@Slist[i]
        T = T@exp_se3(Slist[i], q[i])
    return J
