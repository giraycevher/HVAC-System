import numpy as np
from robkit import exp_se3, fk_poe, homog, inv_T, rot_x, rot_y, rpy_to_R, skew, adjoint, unskew
np.set_printoptions(precision=5, suppress=True)

# 3-DoF bacak: kalça roll (x ekseni), kalça pitch (y ekseni), diz pitch (y ekseni). Uyluk = baldır = 0.2 m.
l1, l2 = 0.2, 0.2
# Ev (home) konumu: bacak dümdüz aşağıda. Vida eksenleri uzay (kalça) çerçevesinde: S = [ω; v], v = -ω x q
def screw(w, q_point): w = np.array(w, float); return np.concatenate([w, -np.cross(w, q_point)])
Slist = [screw([1, 0, 0], [0, 0, 0]),           # kalça roll ekseni, kalça merkezinden geçer
         screw([0, 1, 0], [0, 0, 0]),           # kalça pitch
         screw([0, 1, 0], [0, 0, -l1])]         # diz pitch, dizden geçer
M = homog(np.eye(3), [0, 0, -l1 - l2])          # ev konumunda ayak çerçevesi
print("vida eksenleri S_i = [ω; v]:"); [print("  ", S) for S in Slist]

def fk_chain(q):
    """Aynı bacak, 'dönme-öteleme' zinciri ile (DH benzeri elle kurulmuş)"""
    T = homog(rot_x(q[0]), np.zeros(3))@homog(rot_y(q[1]), np.zeros(3))
    T = T@homog(np.eye(3), [0, 0, -l1])@homog(rot_y(q[2]), np.zeros(3))@homog(np.eye(3), [0, 0, -l2])
    return T

q = np.array([0.2, -0.5, 0.9])
T1, T2 = fk_poe(Slist, M, q), fk_chain(q)
print("ayak konumu (PoE)   :", T1[:3, 3]); print("ayak konumu (zincir):", T2[:3, 3], "  fark", np.abs(T1 - T2).max())
print("ayak yönelimi (PoE) R =\n", T1[:3, :3])

# İşaret konvansiyonunu sayısal doğrula: pozitif kalça pitch ayağı hangi yöne götürür?
q0 = np.array([0.0, 0.3, 0.0]); p0 = fk_poe(Slist, M, q0)[:3, 3]
print(f"sadece kalça pitch=+0.3: ayak = {p0}  -> y ekseni etrafında + dönme, aşağı bakan bacağı -x yönüne götürür (sağ el kuralı)")

# Gövde -> kalça -> ayak: dünya çerçevesinde ayak konumu
T_wb = homog(rpy_to_R(0.05, -0.1, 0.3), [1.0, 0.5, 0.45])      # gövde pozu (dünyada)
T_bh = homog(np.eye(3), [0.1, -0.08, -0.05])                   # sağ kalça, gövde çerçevesinde
T_wf = T_wb@T_bh@T1
print("dünyada ayak konumu:", T_wf[:3, 3])
print("ayak -> gövde dönüşümü (ters):", (inv_T(T_wb)@T_wf)[:3, 3], " = T_bh*T_hf:", (T_bh@T1)[:3, 3])

# Twist ve adjoint: dq/dt = qd iken ayak çerçevesinin hızı. Uzay twist'i V_s: [V_s] = Ṫ T^{-1}; gövde twist'i V_b: [V_b] = T^{-1} Ṫ
qd = np.array([0.4, -1.0, 1.5]); h = 1e-6
Td = (fk_poe(Slist, M, q + h*qd) - fk_poe(Slist, M, q - h*qd))/(2*h)          # Ṫ sonlu farkla
Vs_m = Td@inv_T(T1); Vb_m = inv_T(T1)@Td
Vs = np.concatenate([unskew(Vs_m[:3, :3]), Vs_m[:3, 3]]); Vb = np.concatenate([unskew(Vb_m[:3, :3]), Vb_m[:3, 3]])
print("uzay twist V_s =", Vs); print("gövde twist V_b =", Vb)
print("Ad_T V_b =", adjoint(T1)@Vb, " (V_s'ye eşit olmalı), fark", np.abs(adjoint(T1)@Vb - Vs).max())
pdot = Td[:3, 3]
print("ayak ucunun doğrusal hızı ṗ =", pdot, " = v_s + ω_s x p:", Vs[3:] + np.cross(Vs[:3], T1[:3, 3]))
