"""robkit.py için birim testler (pytest ile de çalışır: `pytest c08_tests.py`)"""
import numpy as np
from robkit import exp_so3, log_so3, R_to_quat, quat_to_R, rpy_to_R, R_to_rpy, fk_poe, space_jacobian, homog, rot_x, rot_y, inv_T, unskew

rng = np.random.default_rng(42)
S = [np.array([1., 0, 0, 0, 0, 0]), np.array([0, 1., 0, 0, 0, 0]), np.array([0, 1., 0, 0.2, 0, 0])]
M = homog(np.eye(3), [0, 0, -0.4])

def test_so3():
    for _ in range(200):
        w = rng.uniform(-3, 3, 3); w *= min(1, 3.1/np.linalg.norm(w)); R = exp_so3(w)
        assert np.allclose(R.T@R, np.eye(3), atol=1e-12) and abs(np.linalg.det(R) - 1) < 1e-12
        assert np.allclose(log_so3(R), w, atol=1e-9)
        assert np.allclose(quat_to_R(R_to_quat(R)), R, atol=1e-12)
        rpy = rng.uniform(-3, 3, 3)/np.array([2, 2.2, 1]); assert np.allclose(R_to_rpy(rpy_to_R(*rpy)), rpy, atol=1e-9)

def test_leg():
    for _ in range(100):
        q = rng.uniform(-3, 3, 3)/np.array([4, 2, 2]); T = fk_poe(S, M, q)
        Tc = homog(rot_x(q[0]), np.zeros(3))@homog(rot_y(q[1]), np.zeros(3))@homog(np.eye(3), [0, 0, -.2])@homog(rot_y(q[2]), np.zeros(3))@homog(np.eye(3), [0, 0, -.2])
        assert np.allclose(T, Tc, atol=1e-12)
        Js = space_jacobian(S, q); h = 1e-6
        for i in range(3):
            e = np.eye(3)[i]*h; V = (fk_poe(S, M, q + e) - fk_poe(S, M, q - e))/(2*h)@inv_T(T)
            assert np.allclose(np.concatenate([unskew(V[:3, :3]), V[:3, 3]]), Js[:, i], atol=1e-8)

if __name__ == "__main__":
    n = 0
    for f in [test_so3, test_leg]:
        f(); n += 1; print(f"{f.__name__}: geçti")
    print(f"{n} test fonksiyonu geçti")
