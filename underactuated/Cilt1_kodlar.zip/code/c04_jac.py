import numpy as np
from robkit import fk_poe, space_jacobian, homog, skew
np.set_printoptions(precision=5, suppress=True)

l1, l2 = 0.2, 0.2
def screw(w, qp): w = np.array(w, float); return np.concatenate([w, -np.cross(w, qp)])
Slist = [screw([1, 0, 0], [0, 0, 0]), screw([0, 1, 0], [0, 0, 0]), screw([0, 1, 0], [0, 0, -l1])]
M = homog(np.eye(3), [0, 0, -l1 - l2])
foot = lambda q: fk_poe(Slist, M, q)[:3, 3]

def foot_jacobian(q):
    """Ayak ucu doğrusal hız Jacobian'ı (3x3): ṗ = (J_v - [p] J_ω) q̇  (uzay Jacobian'ından)"""
    Js = space_jacobian(Slist, q); p = foot(q)
    return Js[3:] - skew(p)@Js[:3]

q = np.array([0.2, -0.5, 0.9])
Js = space_jacobian(Slist, q); Jp = foot_jacobian(q)
print("uzay Jacobian'ı J_s (6x3, satırlar [ω; v]):\n", Js)
print("ayak doğrusal Jacobian'ı J_p:\n", Jp)
h = 1e-6; Jfd = np.column_stack([(foot(q + h*e) - foot(q - h*e))/(2*h) for e in np.eye(3)])
print("sonlu fark ile karşılaştırma: max fark =", np.abs(Jfd - Jp).max())

print("\ntekillik: diz açısı -> det(J_p), koşul sayısı")
for qk in [1.2, 0.6, 0.2, 0.05, 0.0]:
    Jq = foot_jacobian(np.array([0.0, -qk/2, qk])); s = np.linalg.svd(Jq, compute_uv=False)
    print(f"  diz={qk:4.2f}: det = {np.linalg.det(Jq):+.5f}, σ = {s.round(4)}, κ = {s[0]/max(s[-1], 1e-300):.3g}")

# Statik: 2 kg robot iki ayak üzerinde, gövde yatay. Her ayağa yerden F = (0, 0, m g / 2) etki eder.
m, g = 2.0, 9.81; F_ext = np.array([0, 0, m*g/2])
print(f"\nstatik eklem torkları (τ = -J_pᵀ F_ext, F_ext = yerden ayağa {F_ext[2]:.3f} N yukarı), ayak kalçanın altında tutulursa:")
for qk in [0.2, 0.6, 1.0, 1.4]:
    qq = np.array([0.0, -qk/2, qk])                     # kalça pitch = -diz/2 -> ayak tam kalçanın altında
    tau = -foot_jacobian(qq).T@F_ext; p = foot(qq)
    print(f"  diz={qk:3.1f} rad: ayak {p.round(4)}, τ = {tau.round(4)} N·m  (|τ_diz| = {abs(tau[2]):.3f} N·m = {abs(tau[2])/9.81*100:.1f} kg·cm)")
# Sanal iş kontrolü: eklem gücü = -ayaktaki dış kuvvetin gücü
qd = np.array([0.3, -0.7, 1.1]); tau = -Jp.T@F_ext
print(f"sanal iş: τᵀq̇ = {tau@qd:.6f},  -F_extᵀ ṗ = {-F_ext@(Jp@qd):.6f}")

# %% plot
from figstyle import plt, save
fig, ax = plt.subplots(1, 2, figsize=(8.0, 3.4))
for qk, c in zip([0.3, 0.9, 1.6], ["C0", "C1", "C2"]):
    qq = np.array([0.0, -qk/2, qk]); kn = fk_poe(Slist[:2], homog(np.eye(3), [0, 0, -l1]), qq[:2])[:3, 3]; p = foot(qq)
    ax[0].plot([0, kn[0], p[0]], [0, kn[2], p[2]], "o-", c=c, label=f"diz={qk}")
    J2 = foot_jacobian(qq)[[0, 2]][:, 1:]                  # sagital düzlem: (x, z) ve (kalça pitch, diz)
    U, s, Vt = np.linalg.svd(J2); th = np.linspace(0, 2*np.pi, 80); E = U@np.diag(s)@np.vstack([np.cos(th), np.sin(th)])
    ax[0].plot(p[0] + 0.25*E[0], p[2] + 0.25*E[1], c=c, lw=1)
ax[0].set_aspect("equal"); ax[0].set_xlabel("x [m]"); ax[0].set_ylabel("z [m]"); ax[0].set_title("Hız elipsleri (0.25 ölçekli)"); ax[0].legend(fontsize=7)
qs = np.linspace(0.05, 2.0, 100); tk = [abs((-foot_jacobian(np.array([0, -k/2, k])).T@F_ext)[2]) for k in qs]
ax[1].plot(qs, tk); ax[1].axhspan(0.9, 1.1, color="C3", alpha=0.15, label="MG996R durma torku (yaklaşık)")
ax[1].set_xlabel("diz açısı [rad]"); ax[1].set_ylabel("|τ_diz| [N·m]"); ax[1].set_title("2 kg robot, tek bacağa düşen yük m g/2"); ax[1].legend(fontsize=7)
save("c04_jac")
