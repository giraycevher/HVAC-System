// w3_admm.cpp — ADMM QP çözücü sınıfı (OSQP'nin çekirdek fikri) + LIPM ZMP MPC'si, Eigen ile
#include <Eigen/Dense>
#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstdio>
using Eigen::MatrixXd;
using Eigen::VectorXd;

//   min ½ xᵀPx + qᵀx   s.t.  l ≤ A x ≤ u
class QpAdmm {
public:
    QpAdmm(const MatrixXd& P, const MatrixXd& A, double rho = 0.1, double sigma = 1e-6, double alpha = 1.6)
        : P_(P), A_(A), rho_(rho), sigma_(sigma), alpha_(alpha),
          llt_(P + sigma * MatrixXd::Identity(P.rows(), P.cols()) + rho * A.transpose() * A),   // bir kez ayrıştır
          x_(VectorXd::Zero(P.rows())), z_(VectorXd::Zero(A.rows())), y_(VectorXd::Zero(A.rows())) {}

    int solve(const VectorXd& q, const VectorXd& l, const VectorXd& u, double eps = 1e-5, int max_iter = 4000) {
        z_ = z_.cwiseMax(l).cwiseMin(u);                       // sıcak başlangıç, kısıt kümesine izdüşür
        int it = 1;
        for (; it <= max_iter; ++it) {
            const VectorXd xt = llt_.solve(sigma_ * x_ - q + A_.transpose() * (rho_ * z_ - y_));
            const VectorXd zt = A_ * xt;
            x_ = alpha_ * xt + (1 - alpha_) * x_;
            const VectorXd zr = alpha_ * zt + (1 - alpha_) * z_;
            z_ = (zr + y_ / rho_).cwiseMax(l).cwiseMin(u);
            y_ += rho_ * (zr - z_);
            if (it % 10 == 0) {
                const double rp = (A_ * x_ - z_).cwiseAbs().maxCoeff();
                const double rd = (P_ * x_ + q + A_.transpose() * y_).cwiseAbs().maxCoeff();
                if (rp < eps && rd < eps * 10) break;
            }
        }
        return std::min(it, max_iter);
    }
    const VectorXd& x() const { return x_; }

private:
    MatrixXd P_, A_;
    double rho_, sigma_, alpha_;
    Eigen::LLT<MatrixXd> llt_;
    VectorXd x_, z_, y_;
};

int main() {
    const double g = 9.81, zc = 0.32, w2 = g / zc, dt = 0.05;
    const int N = 32;
    Eigen::Matrix3d Ad; Ad << 1, dt, dt * dt / 2, 0, 1, dt, 0, 0, 1;
    const Eigen::Vector3d Bd(dt * dt * dt / 6, dt * dt / 2, dt);
    const Eigen::RowVector3d C(1, 0, -1 / w2);
    MatrixXd Px(N, 3), Pu = MatrixXd::Zero(N, N);
    Eigen::Matrix3d Ak = Eigen::Matrix3d::Identity();
    for (int i = 0; i < N; ++i) {
        Ak = Ad * Ak; Px.row(i) = C * Ak;
        Eigen::Matrix3d Ap = Eigen::Matrix3d::Identity();
        for (int j = i; j >= 0; --j) { Pu(i, j) = C * Ap * Bd; Ap = Ad * Ap; }   // Pu(i,j) = C Ad^(i-j) Bd
    }
    const double a_j = 1e-6, g_z = 1.0, T_step = 0.4, L_step = 0.08, back = -0.03, front = 0.05;
    const MatrixXd H = a_j * MatrixXd::Identity(N, N) + g_z * Pu.transpose() * Pu;
    auto foot_at = [&](double t) { return L_step * std::min(int(t / T_step), 5); };

    for (double dv : {0.0, 0.30}) {
        QpAdmm qp(H, Pu);
        Eigen::Vector3d s = Eigen::Vector3d::Zero();
        double t = 0, out_max = 0, x = 0, p = 0; int it_sum = 0, it_max = 0, steps = 0;
        auto t0 = std::chrono::steady_clock::now();
        while (t < 3.0 - 1e-9) {
            VectorXd f(N);
            for (int i = 0; i < N; ++i) f(i) = foot_at(t + dt * (i + 1) - dt / 2);
            const VectorXd q = g_z * Pu.transpose() * (Px * s - (f.array() + 0.01).matrix());
            const VectorXd base = Px * s;
            const int it = qp.solve(q, (f.array() + back).matrix() - base, (f.array() + front).matrix() - base);
            it_sum += it; it_max = std::max(it_max, it); ++steps;
            const double p_cmd = C * (Ad * s + Bd * qp.x()(0));
            const double foot = foot_at(t + dt / 2);
            out_max = std::max({out_max, p_cmd - (foot + front), (foot + back) - p_cmd});
            x = s(0); double v = s(1);
            for (int k = 0; k < 50; ++k) {                   // 1 ms adımlarla gerçek LIPM, ZMP ayakta kırpılı
                p = std::clamp(p_cmd, foot + back, foot + front);
                v += w2 * (x - p) * 1e-3; x += v * 1e-3;
            }
            t += dt;
            if (std::abs(t - 0.9) < dt / 2) v += dv;
            s << x, v, w2 * (x - p);
        }
        const double ms = std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - t0).count();
        std::printf("itme %.2f m/s, kısıtlı MPC: ZMP komutu ayak dışına max %.2f cm, son CoM - son ayak = %.2f cm | ADMM iter. ort. %.0f, max %d | 60 MPC adımı toplam %.1f ms\n",
                    dv, std::max(out_max, 0.0) * 100, (x - foot_at(3.0)) * 100, double(it_sum) / steps, it_max, ms);
    }
    return 0;
}
