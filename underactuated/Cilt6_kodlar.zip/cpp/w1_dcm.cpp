// w1_dcm.cpp — DCM adım planı (geriye özyineleme) ve DCM izleme kontrolcüsü; 1 kHz gerçek zamanlı döngüye
// konacak biçimde: her çağrıda O(1) iş, bellek ayırma yok.
#include <algorithm>
#include <array>
#include <cmath>
#include <cstdio>

constexpr double kG = 9.81, kZc = 0.32;
const double kW = std::sqrt(kG / kZc);

template <int NF>
struct DcmPlan {
    std::array<double, NF> feet{}, xi_eos{};
    double T;
    DcmPlan(const std::array<double, NF>& f, double step_time) : feet(f), T(step_time) {
        xi_eos[NF - 1] = feet[NF - 1];                                   // son: ayağın üstünde dur
        for (int i = NF - 2; i >= 0; --i)
            xi_eos[i] = feet[i + 1] + std::exp(-kW * T) * (xi_eos[i + 1] - feet[i + 1]);
    }
    double xi_ini0() const { return feet[0] + std::exp(-kW * T) * (xi_eos[0] - feet[0]); }
    // t anındaki referans DCM ve o anki destek ayağı
    void ref(double t, double& xi, double& foot) const {
        const int i = std::min(int(t / T), NF - 1);
        foot = feet[i];
        xi = foot + std::exp(kW * (t - i * T - T)) * (xi_eos[i] - foot);
    }
};

class DcmController {
public:
    DcmController(double k, double back, double front) : k_(k), back_(back), front_(front) {}
    // ölçülen CoM konumu/hızı -> uygulanacak ZMP (ayak tabanına kırpılmış)
    double zmp(double x, double v, double xi_r, double foot) const {
        const double xi = x + v / kW, xi_r_dot = kW * (xi_r - foot);
        const double p = xi - (xi_r_dot - k_ * (xi - xi_r)) / kW;
        return std::clamp(p, foot + back_, foot + front_);
    }
private:
    double k_, back_, front_;
};

int main() {
    const DcmPlan<7> plan({0.0, 0.08, 0.16, 0.24, 0.32, 0.40, 0.40}, 0.4);
    std::printf("ω = %.3f 1/s\nadım sonu DCM [cm]:", kW);
    for (double v : plan.xi_eos) std::printf(" %.2f", 100 * v);
    std::printf("\n");
    const DcmController ctl(3.0, -0.03, 0.05);
    for (double dv : {0.0, 0.10, 0.20, 0.30}) {
        double x = plan.xi_ini0(), v = 0, err_max = 0, err = 0; const double dt = 1e-3;
        for (int k = 0; k < int(7 * 0.4 / dt); ++k) {
            const double t = k * dt;
            if (std::abs(t - 0.9) < dt / 2) v += dv;
            double xr, foot; plan.ref(t, xr, foot);
            const double p = ctl.zmp(x, v, xr, foot);
            v += kW * kW * (x - p) * dt; x += v * dt;
            err = std::abs(x + v / kW - xr); err_max = std::max(err_max, err);
        }
        if (err > 0.02) std::printf("itme %.2f m/s: DCM ıraksadı -> DÜŞTÜ\n", dv);
        else std::printf("itme %.2f m/s: max DCM hatası %.2f cm, son CoM %.2f cm\n", dv, 100 * err_max, 100 * x);
    }
    return 0;
}
