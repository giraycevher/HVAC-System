import numpy as np

from qp_admm import ADMM                                      # code/lib/qp_admm.py (aşağıda listelendi)

# ---------- LIPM, jerk girişli ayrık model ----------
g, zc = 9.81, 0.32; w2 = g / zc
dt, N = 0.05, 32                                             # 50 ms adım, 1.6 s ufuk
Ad = np.array([[1, dt, dt**2 / 2], [0, 1, dt], [0, 0, 1]]); Bd = np.array([dt**3 / 6, dt**2 / 2, dt])
C = np.array([1, 0, -1 / w2])                                # ZMP = x - ẍ/ω²
Px = np.zeros((N, 3)); Pu = np.zeros((N, N))                 # Z = Px s0 + Pu J  (ufuk boyunca ZMP)
Ak = np.eye(3)
for i in range(N):
    Ak = Ad @ Ak; Px[i] = C @ Ak
    for j in range(i + 1):
        Pu[i, j] = C @ np.linalg.matrix_power(Ad, i - j) @ Bd
a_j, g_z = 1e-6, 1.0                                         # jerk ağırlığı, ZMP takip ağırlığı
H = a_j * np.eye(N) + g_z * Pu.T @ Pu

# Adım planı (w1 ile aynı): 0.4 s'de bir 8 cm, ayak tabanı bileğe göre [-3, +5] cm
T_step, L_step = 0.4, 0.08
def foot_at(t): return L_step * min(int(t / T_step), 5)
back, front = -0.03, 0.05

def run(constrained, push_dv=0.0, push_t=0.9, Tsim=3.0):
    s = np.zeros(3); s[0] = 0.0
    solver = ADMM(H, Pu) if constrained else None
    t = 0.0; log = []; iters = []
    while t < Tsim - 1e-9:
        tk = t + dt * np.arange(1, N + 1)
        f = np.array([foot_at(tt - dt / 2) for tt in tk])      # örnek tt'deki ZMP, (tt-dt, tt] aralığının ayağında
        zref = f + 0.01                                       # ayak tabanının ortası
        q = g_z * Pu.T @ (Px @ s - zref)
        if constrained:
            Jopt, it = solver.solve(q, f + back - Px @ s, f + front - Px @ s); iters.append(it)
        else:
            Jopt = np.linalg.solve(H, -q)
        # gerçek sistem: planın ilk ZMP komutunu uygula; ZMP fiziksel olarak ayak tabanında kalmak zorunda
        s_next = Ad @ s + Bd * Jopt[0]
        p_cmd = C @ s_next; foot = foot_at(t + dt / 2)
        x, v = s[0], s[1]
        for _ in range(50):                                   # 1 ms adımlarla gerçek LIPM
            p = np.clip(p_cmd, foot + back, foot + front)
            acc = w2 * (x - p); v += acc * 1e-3; x += v * 1e-3
        t += dt
        if abs(t - push_t) < dt / 2: v += push_dv
        s = np.array([x, v, w2 * (x - p)])
        log.append((t, x, p_cmd, p, foot))
    return np.array(log), iters

for dv in [0.0, 0.20, 0.30, 0.35]:
    for cons in [False, True]:
        lg, it = run(cons, dv)
        out = np.maximum(lg[:, 2] - (lg[:, 4] + front), (lg[:, 4] + back) - lg[:, 2]).max()
        fell = abs(lg[-1, 1] - foot_at(3.0)) > 0.05
        if fell:
            print(f"itme {dv:.2f} m/s, {'kısıtlı MPC (ADMM)' if cons else 'kısıtsız (kapalı form)'}: DÜŞTÜ"); continue
        print(f"itme {dv:.2f} m/s, {'kısıtlı MPC (ADMM)' if cons else 'kısıtsız (kapalı form)'}: "
              f"ZMP komutu ayak dışına max {max(out, 0) * 100:5.2f} cm, son CoM - son ayak = {100 * (lg[-1, 1] - foot_at(3.0)):5.2f} cm"
              + (f"  | ADMM iter. ort. {np.mean(it):.0f}, max {max(it)}" + (" (bazı adımlarda QP olurlu değil)" if max(it) >= 4000 else "") if cons else ""))

# Doğrulama: tek bir QP'yi SciPy ile çöz, karşılaştır
from scipy.optimize import minimize
s0 = np.array([0.02, 0.15, 0.0]); tk = dt * np.arange(1, N + 1); f = np.array([foot_at(tt - dt / 2) for tt in tk])
q = g_z * Pu.T @ (Px @ s0 - f - 0.01); lo, hi = f + back - Px @ s0, f + front - Px @ s0
xa, it = ADMM(H, Pu).solve(q, lo, hi, eps=1e-7, max_iter=20000)
cons = [{"type": "ineq", "fun": lambda J: Pu @ J - lo, "jac": lambda J: Pu}, {"type": "ineq", "fun": lambda J: hi - Pu @ J, "jac": lambda J: -Pu}]
rs = minimize(lambda J: 0.5 * J @ H @ J + q @ J, np.zeros(N), jac=lambda J: H @ J + q, constraints=cons, method="SLSQP", options={"maxiter": 500, "ftol": 1e-14})
obj = lambda J: 0.5 * J @ H @ J + q @ J
print(f"doğrulama: ADMM amaç {obj(xa):.8f} ({it} iterasyon), SciPy SLSQP amaç {obj(rs.x):.8f}; ZMP farkı max {np.abs(Pu @ (xa - rs.x)).max() * 1000:.3f} mm")
print(f"QP boyutu: {N} değişken, {N} kısıt; H koşul sayısı {np.linalg.cond(H):.1e}")

# %% plot
from figstyle import plt, save
fig, ax = plt.subplots(1, 2, figsize=(6.4, 3.0), sharey=True)
for a, cons, tit in [(ax[0], False, "kısıtsız"), (ax[1], True, "kısıtlı MPC (ADMM)")]:
    lg, _ = run(cons, 0.30)
    a.fill_between(lg[:, 0], 100 * (lg[:, 4] + back), 100 * (lg[:, 4] + front), step="pre", color="#999", alpha=0.25, label="ayak tabanı")
    a.plot(lg[:, 0], 100 * lg[:, 1], label="CoM"); a.plot(lg[:, 0], 100 * lg[:, 2], lw=1, label="ZMP komutu")
    a.axvline(0.9, color="k", ls=":", lw=0.8); a.set_title(tit + ", 0.30 m/s itme", fontsize=9); a.set_xlabel("t [s]")
ax[0].set_ylabel("x [cm]"); ax[0].set_ylim(-5, 55); ax[1].legend(fontsize=7)
save("w3_mpc")
