import numpy as np
from qp_admm import ADMM

# Tüm-gövde kontrolünün (WBC) kalbi: istenen gövde hareketini, SÜRTÜNME KONİSİ içinde kalan temas kuvvetlerine ve
# oradan eklem torklarına çevirmek. Düzlemsel (sagittal) SB-1, çift destek, her ayakta topuk + burun temas noktası.
m, g, zc = 2.5, 9.81, 0.32
def contacts(x_back, x_front):                 # 4 temas noktası: (arka ayak topuk, burun, ön ayak topuk, burun)
    return np.array([x_back - 0.03, x_back + 0.05, x_front - 0.03, x_front + 0.05])

def distribute(c, cdd, Ldot, pts, mu, w_lin=1.0, w_ang=10.0, reg=1e-4):
    """Değişkenler f = [fx1, fz1, ..., fx4, fz4]. Merkezcil (centroidal) dinamik:
         Σ f = m (c̈ - g)        Σ (p_i - c) × f_i = L̇   (düzlemde: (px-cx) fz - (pz-cz) fx, pz = 0)"""
    n = len(pts); Aw = np.zeros((3, 2 * n))
    for i, px in enumerate(pts):
        Aw[0, 2 * i] = 1; Aw[1, 2 * i + 1] = 1
        Aw[2, 2 * i] = -(0 - c[1]); Aw[2, 2 * i + 1] = (px - c[0])
    wdes = np.array([m * cdd[0], m * (cdd[1] + g), Ldot])
    W = np.diag([w_lin, w_lin, w_ang])
    P = Aw.T @ W @ Aw + reg * np.eye(2 * n); q = -Aw.T @ W @ wdes
    # sürtünme konisi (doğrusal): fz ≥ 0,  fx - μ fz ≤ 0,  -fx - μ fz ≤ 0  (her temas için 3 satır)
    A = np.zeros((3 * n, 2 * n)); lo = np.zeros(3 * n); hi = np.zeros(3 * n); BIG = 1e6
    for i in range(n):
        A[3 * i, 2 * i + 1] = 1;                          lo[3 * i], hi[3 * i] = 0, BIG
        A[3 * i + 1, 2 * i] = 1; A[3 * i + 1, 2 * i + 1] = -mu; lo[3 * i + 1], hi[3 * i + 1] = -BIG, 0
        A[3 * i + 2, 2 * i] = 1; A[3 * i + 2, 2 * i + 1] = mu;  lo[3 * i + 2], hi[3 * i + 2] = 0, BIG
    f, it = ADMM(P, A, rho=1.0).solve(q, lo, hi, eps=1e-6, max_iter=20000)
    return f.reshape(-1, 2), Aw @ f - wdes, it

pts = contacts(-0.06, 0.06)
cases = [("ayakta, CoM ortada",            np.array([0.00, zc]), np.array([0, 0]),   0.0, 0.8),
         ("CoM ön ayağın üstünde",          np.array([0.06, zc]), np.array([0, 0]),   0.0, 0.8),
         ("itmeye karşı ileri 3 m/s² ivme", np.array([0.00, zc]), np.array([3.0, 0]), 0.0, 0.8),
         ("aynısı, kaygan zemin μ=0.2",     np.array([0.00, zc]), np.array([3.0, 0]), 0.0, 0.2),
         ("CoM destek dışında (x=0.14)",    np.array([0.14, zc]), np.array([0, 0]),   0.0, 0.8)]
for name, c, cdd, Ld, mu in cases:
    F, err, it = distribute(c, cdd, Ld, pts, mu)
    load = F[:, 1]
    print(f"{name:32s} μ={mu}: dikey yükler [N] = {np.round(load, 2)} | toplam Fx {F[:, 0].sum():5.2f} N | "
          f"wrench hatası {np.round(err, 2)} | ADMM {it} it.")
print(f"Not: istenen Fx = m·c̈ = {m * 3.0:.1f} N; kaygan zeminde en fazla μ·m·g = {0.2 * m * g:.2f} N mümkün.")

# Temas kuvvetinden eklem torkuna:  τ = -Jᵀ f  (ayak yerde, kuvvet yerden ayağa; bacak gövdeyi taşıyor)
# Ön bacak, Cilt 1'deki 2-uzuvlu bacak (uyluk = baldır = 0.2 m), kalçaya göre ayak konumu
l1 = l2 = 0.20
def leg_ik(px, pz):                                       # kalçaya göre ayak (aşağı = -z), diz geriye bükük
    d = np.hypot(px, pz); q2 = np.arccos((d**2 - l1**2 - l2**2) / (2 * l1 * l2))
    q1 = np.arctan2(px, -pz) - np.arctan2(l2 * np.sin(q2), l1 + l2 * np.cos(q2))
    return q1, q2
def leg_jac(q1, q2):                                      # ayak konumu (x, z) = (l1 s1 + l2 s12, -l1 c1 - l2 c12)
    s1, c1, s12, c12 = np.sin(q1), np.cos(q1), np.sin(q1 + q2), np.cos(q1 + q2)
    return np.array([[l1 * c1 + l2 * c12, l2 * c12], [l1 * s1 + l2 * s12, l2 * s12]])
for name, c, cdd, Ld, mu in cases[:3]:
    F, _, _ = distribute(c, cdd, Ld, pts, mu)
    f_front = F[2] + F[3]                                 # ön ayağın toplam kuvveti (yerden ayağa)
    hip = np.array([c[0], zc - 0.02])                     # kalça CoM'un 2 cm altında (sadeleştirme)
    q1, q2 = leg_ik(0.06 - hip[0], 0 - hip[1])
    tau = -leg_jac(q1, q2).T @ f_front
    print(f"{name:32s}: ön bacak q = ({np.degrees(q1):5.1f}°, {np.degrees(q2):5.1f}°), "
          f"τ_kalça = {tau[0]:6.3f}, τ_diz = {tau[1]:6.3f} N·m   (MG996R durma torku ≈ 1.08 N·m)")

# Tasarım sorusu: tek ayak üstünde (tüm ağırlık, ayak kalçanın tam altında) diz torku kalça yüksekliğine nasıl bağlı?
for h in [0.30, 0.34, 0.37, 0.39]:
    q1, q2 = leg_ik(0.0, -h)
    tau = -leg_jac(q1, q2).T @ np.array([0.0, m * g])
    print(f"kalça yüksekliği {h:.2f} m (diz {np.degrees(q2):5.1f}° bükük): τ_kalça {tau[0]:6.3f}, τ_diz {tau[1]:6.3f} N·m")

# %% plot
from figstyle import plt, save
xs = np.linspace(-0.12, 0.14, 40); loads = []
for xc in xs:
    F, err, _ = distribute(np.array([xc, zc]), np.zeros(2), 0.0, pts, 0.8)
    loads.append([F[0, 1] + F[1, 1], F[2, 1] + F[3, 1], np.abs(err).max()])
loads = np.array(loads)
fig, ax = plt.subplots(figsize=(6.4, 2.9))
ax.plot(100 * xs, loads[:, 0], label="arka ayak dikey yük"); ax.plot(100 * xs, loads[:, 1], label="ön ayak dikey yük")
ax.plot(100 * xs, loads[:, 2], "--", label="karşılanamayan wrench (max)")
ax.axvspan(-9, 11, color="#999", alpha=0.15, label="destek poligonu")
ax.set_xlabel("CoM x [cm]"); ax.set_ylabel("N"); ax.legend(fontsize=7); ax.set_title("statik duruşta kuvvet dağılımı (QP + sürtünme konisi)")
save("w4_wbc")
