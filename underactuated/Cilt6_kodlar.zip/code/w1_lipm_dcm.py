import numpy as np

# Doğrusal ters sarkaç (LIPM), SB-1 ölçüleri: kütle merkezi yüksekliği z_c = 0.32 m
g, zc = 9.81, 0.32
w = np.sqrt(g / zc)                        # LIPM doğal frekansı
print(f"ω = sqrt(g/z_c) = {w:.3f} 1/s, zaman sabiti 1/ω = {1000 / w:.0f} ms")

# 1) Sabit ZMP (p=0) ile analitik çözüm: x(t) = x0 cosh(ωt) + (v0/ω) sinh(ωt)
x0, v0 = 0.02, 0.0
for t in [0.1, 0.2, 0.4]:
    print(f"  x0=2 cm, ayak altında beklerse t={t:.1f} s: x = {100 * (x0 * np.cosh(w * t) + v0 / w * np.sinh(w * t)):.2f} cm")

# 2) DCM (capture point) ξ = x + ẋ/ω : ξ̇ = ω (ξ - p)  -> kararsız tek mod; x ise ξ'yi kararlı biçimde izler: ẋ = -ω (x - ξ)
# Adım planı: 8 cm adım, 0.4 s, ileri yürüme (yan salınımı sadeleştirmek için sagittal düzlem)
T, L, nstep = 0.4, 0.08, 6
feet = np.array([0.0] + [L * i for i in range(1, nstep)] + [L * (nstep - 1)])   # son adım ayakları yan yana: dur
# Geriye doğru özyineleme: her adımın sonunda DCM bir sonraki ayağa göre hesaplanır, son DCM son ayağın üstünde
xi_eos = np.zeros(len(feet)); xi_eos[-1] = feet[-1]
for i in range(len(feet) - 2, -1, -1):
    xi_eos[i] = feet[i + 1] + np.exp(-w * T) * (xi_eos[i + 1] - feet[i + 1])
xi_ini = np.r_[feet[0] + np.exp(-w * T) * (xi_eos[0] - feet[0]), xi_eos[:-1]]
print("adım başı DCM [cm]:", (100 * xi_ini).round(2))
print("adım sonu DCM [cm]:", (100 * xi_eos).round(2))

def xi_ref(t):
    i = min(int(t / T), len(feet) - 1); tau = t - i * T
    return feet[i] + np.exp(w * (tau - T)) * (xi_eos[i] - feet[i]), feet[i]

# 3) DCM izleme kontrolcüsü ve simülasyon
foot_back, foot_front = -0.03, 0.05        # ayak bileğine göre ayak tabanı sınırları
def simulate(k, push_t=None, push_dv=0.0, dt=1e-3, tend=None):
    tend = tend or len(feet) * T
    xi_r0 = xi_ini[0]
    x, v = xi_r0, 0.0                       # başlangıçta CoM, DCM ile aynı yerde ve duruyor (ξ = x)
    log = []
    for kk in range(int(tend / dt)):
        t = kk * dt
        if push_t is not None and abs(t - push_t) < dt / 2: v += push_dv
        xr, foot = xi_ref(t); xr_dot = w * (xr - foot)
        xi = x + v / w
        p = xi - (xr_dot - k * (xi - xr)) / w           # istenen DCM hızını üreten ZMP
        p_cl = np.clip(p, foot + foot_back, foot + foot_front)   # ZMP ayak tabanını terk edemez!
        a = w**2 * (x - p_cl); v += a * dt; x += v * dt
        log.append((t, x, xi, xr, p, p_cl, foot))
    return np.array(log)

for k in [0.0, 1.0, 3.0]:
    lg = simulate(k)
    print(f"k={k:.0f}: max |ξ-ξ_ref| = {1000 * np.abs(lg[:, 2] - lg[:, 3]).max():.2f} mm, "
          f"ZMP ayaktan max uzaklık: {100 * np.abs(lg[:, 5] - lg[:, 6]).max():.2f} cm, son CoM {100 * lg[-1, 1]:.2f} cm")
for dv in [0.10, 0.20, 0.30]:
    lg = simulate(3.0, push_t=0.9, push_dv=dv)
    sat = (np.abs(lg[:, 4] - lg[:, 5]) > 1e-9).mean() * 100
    err = np.abs(lg[:, 2] - lg[:, 3])
    if err[-1] > 0.02:
        div = lg[np.argmax(err > 0.10), 0]
        print(f"t=0.9 s'de {dv:.2f} m/s itme: DCM ıraksadı (hata t={div:.2f} s'de 10 cm'yi geçti) -> DÜŞTÜ; adım yeri değişmeliydi")
    else:
        print(f"t=0.9 s'de {dv:.2f} m/s itme: max DCM hatası {100 * err.max():.2f} cm, son hata {100 * err[-1]:.2f} cm, ZMP doyumda %{sat:.1f}")
print(f"ayak bileği stratejisi sınırı (DCM sıçraması v/ω ≤ ayak önü): v ≤ {foot_front * w:.3f} m/s")

# %% plot
from figstyle import plt, save
lg = simulate(3.0, push_t=0.9, push_dv=0.2)
fig, ax = plt.subplots(figsize=(6.4, 3.0))
ax.plot(lg[:, 0], 100 * lg[:, 1], label="CoM x"); ax.plot(lg[:, 0], 100 * lg[:, 2], label="DCM ξ"); ax.plot(lg[:, 0], 100 * lg[:, 3], "--", label="ξ referans")
ax.plot(lg[:, 0], 100 * lg[:, 5], lw=1, label="ZMP (uygulanan)")
ax.fill_between(lg[:, 0], 100 * (lg[:, 6] + foot_back), 100 * (lg[:, 6] + foot_front), color="#999", alpha=0.2, label="ayak tabanı")
ax.axvline(0.9, color="k", lw=0.8, ls=":"); ax.set_xlabel("t [s]"); ax.set_ylabel("x [cm]"); ax.legend(fontsize=7, ncol=2); ax.set_title("DCM izleme, t=0.9 s'de 0.2 m/s itme")
save("w1_lipm_dcm")
