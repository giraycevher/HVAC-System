import numpy as np

# İtmeden kurtulma: ayak bileği stratejisi mi, adım atma mı?  (SB-1: z_c = 0.32 m, ayak önü 5 cm, bacak erimi 20 cm)
g, zc = 9.81, 0.32; w = np.sqrt(g / zc)
front, reach = 0.05, 0.20

# Robot ayakta duruyor (x = 0, ayak 0'da). İtme sonrası hız v -> DCM ξ0 = v/ω.
# Ayak bileği: ZMP en fazla 'front' ileri gidebilir. ξ0 ≤ front ise yerinde durabilir.
print(f"0-adım (ayak bileği) sınırı: v ≤ ω·front = {w * front:.3f} m/s")

# N-adım: her adımda ayak en fazla 'reach' öne konabilir; salınım süresi Ts boyunca ZMP eski ayağın ön kenarında.
# Son ayakta durabilmek için DCM, ayağın en fazla 'front' önünde olmalı. Geriye doğru:
#   ξ(adım anı) - eski ayak ≤ reach + lim  ve  ξ(Ts) = front + (ξ0 - front) e^{ω Ts}
def n_step_vmax(n, Ts):
    lim = front                                                    # 0 adım: ayak bileği
    for _ in range(n):
        lim = front + (reach + lim - front) * np.exp(-w * Ts)    # bir adım daha atılabilirse izin verilen ξ0
    return w * lim
for Ts in [0.15, 0.2, 0.3, 0.4, 0.6]:
    print(f"salınım {Ts:.2f} s (e^(-ωTs)={np.exp(-w * Ts):.3f}): " + ", ".join(f"N={n}: {n_step_vmax(n, Ts):.3f}" for n in range(0, 4)) + " m/s")

# Simülasyon: itme, ayak 0.25 s sonra ya DCM'ye ya da sabit 10 cm öne konuyor
def push_sim(v0, Ts, step_rule="dcm", dt=1e-4, T=2.0):
    x, v = 0.0, v0; foot = 0.0; stepped = False; log = []
    for k in range(int(T / dt)):
        t = k * dt; xi = x + v / w
        if not stepped and t >= Ts:
            target = xi if step_rule == "dcm" else foot + 0.10        # DCM'ye bas ya da sabit 10 cm adım
            foot = foot + np.clip(target - foot, -reach, reach); stepped = True
        # adımdan önce ZMP eski ayağın ön kenarında; sonra ξ̇ = -ω(ξ - ayak) isteyen ZMP: p = ξ + (ξ - ayak)
        p = np.clip(2 * xi - foot, foot - 0.03, foot + front) if stepped else foot + front
        a = w**2 * (x - p); v += a * dt; x += v * dt
        log.append((t, x, xi, p, foot))
    return np.array(log)
for v0, rule in [(0.4, "sabit"), (0.5, "sabit"), (0.5, "dcm"), (0.6, "dcm")]:
    lg = push_sim(v0, 0.25, rule)
    final_xi_err = lg[-1, 2] - lg[-1, 4]
    ok = abs(final_xi_err) < 0.01
    print(f"itme {v0} m/s, adım kuralı '{rule}': ayak {100 * lg[-1, 4]:.1f} cm'ye kondu -> "
          + (f"DURDU (CoM {100 * lg[-1, 1]:.1f} cm)" if ok else "DÜŞTÜ (DCM ayaktan kaçtı)"))
print(f"teori, salınım 0.25 s, 1 adım: v ≤ {n_step_vmax(1, 0.25):.3f} m/s")

# %% plot
from figstyle import plt, save
fig, ax = plt.subplots(figsize=(6.4, 3.0))
Ts = np.linspace(0.1, 0.7, 50)
for n in range(0, 4):
    ax.plot(Ts, [n_step_vmax(n, t) for t in Ts], label=f"{n}-adım")
ax.set_xlabel("salınım (adım) süresi [s]"); ax.set_ylabel("kurtarılabilir en büyük itme hızı [m/s]"); ax.legend(fontsize=7)
ax.set_title("N-adım yakalanabilirlik, SB-1 (ayak önü 5 cm, erim 20 cm)")
save("w2_capture")
