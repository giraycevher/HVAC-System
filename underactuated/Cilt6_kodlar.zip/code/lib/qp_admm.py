"""qp_admm.py — kendi QP çözücümüz (ADMM, OSQP'nin temel algoritması). Cilt 6 Bölüm 3 ve 4."""
import numpy as np

#   min ½ xᵀPx + qᵀx   s.t.  l ≤ A x ≤ u
class ADMM:
    def __init__(self, P, A, rho=0.1, sigma=1e-6, alpha=1.6):
        self.P, self.A, self.rho, self.sigma, self.alpha = P, A, rho, sigma, alpha
        K = P + sigma * np.eye(P.shape[0]) + rho * A.T @ A
        self.L = np.linalg.cholesky(K)                       # bir kez ayrıştır, her iterasyonda iki üçgen çözüm
        self.x = np.zeros(P.shape[0]); self.z = np.zeros(A.shape[0]); self.y = np.zeros(A.shape[0])
    def solve(self, q, l, u, eps=1e-5, max_iter=4000):
        P, A, r, s, a = self.P, self.A, self.rho, self.sigma, self.alpha
        x, z, y = self.x, np.clip(self.z, l, u), self.y       # sıcak başlangıç (warm start)
        for it in range(1, max_iter + 1):
            rhs = s * x - q + A.T @ (r * z - y)
            xt = np.linalg.solve(self.L.T, np.linalg.solve(self.L, rhs))
            zt = A @ xt
            x = a * xt + (1 - a) * x
            zr = a * zt + (1 - a) * z
            z = np.clip(zr + y / r, l, u)                    # kısıt kümesine izdüşüm: sadece kırpma!
            y = y + r * (zr - z)
            if it % 10 == 0:
                rp = np.abs(A @ x - z).max(); rd = np.abs(P @ x + q + A.T @ y).max()
                if rp < eps and rd < eps * 10: break
        self.x, self.z, self.y = x, z, y
        return x, it

